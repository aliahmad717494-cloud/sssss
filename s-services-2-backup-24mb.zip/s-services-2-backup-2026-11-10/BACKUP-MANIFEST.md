# S SERVICES — Backup Manifest

**Source artifact:** s-services-2 (Muse AI / Hatch TypeScript space)
**Live version backed up:** v15 — build 09ebe19b-1fa6-4048-a815-846fab4acc3a
**Backup date/time:** 10 November 2026, 01:42 PKT (Asia/Karachi)
**Source-tree fingerprint (prior inspection):** cf22d1df99dd6de610ff3ac2c6b91ec45a226556628b77e2d2ae1b7902e07afd
**Live app.db SHA-256 at backup time:** 5eb4f48ee49a8e4b685e8e020b33d20f2187bab5074e2cc0370973e94b7c421c
**Backup root:** s-services-2-backup-2026-11-10/

**Total files listed:** 148
**Total bytes:** 38942552 (37.14 MB)

## Verification results (measured during backup, 10 Nov 2026)

- Freeze check: no build running for s-services-2; live version v15; share.shared=false (not published).
- Copy method: read-only rsync -a of the source tree (excluding node_modules, .bun-cache, audits/ — see README.md), plus a file-level cp of app.db; live app.db SHA-256 before and after copy identical.
- Database: PRAGMA integrity_check = ok on the copied database; app-dump.sql (268 lines) restored cleanly into a scratch SQLite file and opened; PRAGMA integrity_check = ok on the restored copy.
- Server actions: 45 defineAction( call sites in server/src/actions.ts (+1 import line).
- File inventory diff vs source tree (excluding the three deliberate exclusions and the added database/ + README.md + BACKUP-MANIFEST.md): NO DIFFERENCES.

## Per-table row counts (read from the restored scratch copy)

| Table | Rows |
|---|---|
| services | 42 (20 electrical, 22 plumbing; all published; 42 distinct slugs) |
| settings | 12 |
| staff_users | 1 (admin, 494motors@gmail.com, active; password hash format pbkdf2$210000$ intact) |
| sessions | 2 (staff) |
| activity_log | 3 |
| customers | 0 |
| bookings | 0 |
| quote_requests | 0 |
| quotations | 0 |
| invoices | 0 |
| offers | 0 |
| offer_assignments | 0 |
| messages | 0 |
| notifications | 0 |
| projects | 0 |
| reviews | 0 |
| service_areas | 0 |
| technicians | 0 |
| __drizzle_migrations | 4 |

Expected counts matched exactly; no discrepancies found. No records were modified, deleted, reset or recreated.

## Files (path | bytes | SHA-256)

```
      3352  0a0d4f47173d21bf3fce806c5d44bb8da8dbb058452903d1cb4dca93d8f514cf  .harness/app-map.md
       285  72a4d84edbe2eee9af164eca5b124e275a90ab06bff3d6b7b739a2d7d2749a48  .harness/icon_pool_selection.json
       340  c3a65e21a56740e128a57f9122f7487e1bfcadb48fd49ac4eecfe03559e04b9e  .harness/last_audit.json
        49  3fe46524a27630559b48ed489fd710bf878eb733813aeb1dafa05450de7f5508  .harness/last_build.json
      6965  b5f7dbbaa1e00bf245bec1d4993d322cc3335da4cf368ef2fc528bad1b73b074  .harness/plan.json
       367  5e89a347ab04c5e173475259aa0d53226d843b0819180d459bb72529f40234b3  .harness/probe-ui/session.json
       264  2713a762bd75a4b5556dfb57bbad126d071abf1ac65ec32e9a42e525cdde84a0  .harness/probe-ui/summary.json
       406  fd7c50f8441cb819f4b0165c512e6c56118f2f38f25a863142bc5d706afa582f  .harness/server_build.json
    962979  edb782d60a0372c33e853cc6c93a839cecd246d27984623c251c192e071b2b1e  .space-build/assets/craft-electrical-1fkrm3nz.mp4
     78233  555dd5155e5550082169eda2f72869b17f59b5d9fc3ebfb6d96d23bb86d22920  .space-build/assets/craft-electrical-82jjer8z.jpg
     63498  6bb07620954431f22bd0e17d334bfa32fac8919fe34624b967d60e7718a05dda  .space-build/assets/craft-plumbing-a3zhdmj8.jpg
    928701  4d356795fcad3094beb8fb99fae551bb1d1e2faf7f8fc0ec1196a72384c39ea2  .space-build/assets/craft-plumbing-wrnw0eac.mp4
    146348  5931a76a81e4093c78b157564595e38328d6512a82b9d747928c2115fa993e9b  .space-build/assets/electrical-inspection-t83trc4g.webp
     58394  d2800937518faec878c73784ee195716779f4076768ffade9d72ef1bff243193  .space-build/assets/ev-wallbox-x0jn38e8.webp
   1301613  5479e43ecd48efa429204f68f49ba234a6c354d2d7429229f9d0015d65a8bb5f  .space-build/assets/hatch-maps-3ge1fx5t.bin
     69918  768b9ff0c135536afbbee9f20232ac261e8b2b89ce60a29f838024be9dd172e3  .space-build/assets/hatch-maps-css-hh6yk8h1.bin
    504828  03fd070aa983240f2f6f4e8d39e2bf08b615c147d9f2eba4806b0c5bf113f5c6  .space-build/assets/heating-5ppfc2fh.jpg
     92766  f7f9bfa4494d68f393826b3a2c258fa037770f751521aa542dcf1ed72454ee03  .space-build/assets/hero-electrical-4rpksvfm.jpg
     89380  709a54873a015148ac5eb18e1b5fc080c1bd9a2e9c71a8358011c64616c0dd32  .space-build/assets/hero-plumbing-mw6c23sn.jpg
    651989  539a60a42f2fe79c6ab8e087988ed38ff6d106f8214ea8a8c98a5ae5fadc0197  .space-build/assets/hero-video-electrical-2gctzhyw.mp4
    736439  c23982ab3fff1b66349f962cbf820b2bc2fce9c28ccf99560290ee453deeda53  .space-build/assets/hero-video-plumbing-bxr9qxgj.mp4
   1395191  db3ca2d056a652d9b0ae731d1ff21b54567cc5c5185af58ad53c13da1190366e  .space-build/assets/index-aqbg0kyk.js
     50193  9059cc941bb419333c27950b8818c9f7f4097eb2005fe58354c023bcf334755d  .space-build/assets/index-hjd9ja6y.css
     92010  6bde8e74a171c284f493cd4ead746a0103699189335617f3673b991eb2539940  .space-build/assets/kitchen-plumbing-01gxw0wc.jpg
    136051  1e4bfb1c3b2210b1b322805dad3cad84923322c09e1a7f03caac90decd4b3960  .space-build/assets/pipe-work-bmwxvxhk.jpg
    106396  a4f5c046c72ace7d1d22537e1bed9ad1e4ef22b37d73c37907aabf8bb592700b  .space-build/assets/solar-z1p03rej.webp
      6890  ec1b5ce3f7933c9200ec96b9b000f474d41ad4dd91ae847fe2f61d024c31ff68  .space-build/index.html
       210  89a456c747c85a671d2a1d2c5d48afd11e92f4208b5013a2c8e8534fdd916a3e  .space-build/manifest.json
    962979  edb782d60a0372c33e853cc6c93a839cecd246d27984623c251c192e071b2b1e  .space-build-cvm/assets/craft-electrical-1fkrm3nz.mp4
     78233  555dd5155e5550082169eda2f72869b17f59b5d9fc3ebfb6d96d23bb86d22920  .space-build-cvm/assets/craft-electrical-82jjer8z.jpg
     63498  6bb07620954431f22bd0e17d334bfa32fac8919fe34624b967d60e7718a05dda  .space-build-cvm/assets/craft-plumbing-a3zhdmj8.jpg
    928701  4d356795fcad3094beb8fb99fae551bb1d1e2faf7f8fc0ec1196a72384c39ea2  .space-build-cvm/assets/craft-plumbing-wrnw0eac.mp4
    146348  5931a76a81e4093c78b157564595e38328d6512a82b9d747928c2115fa993e9b  .space-build-cvm/assets/electrical-inspection-t83trc4g.webp
     58394  d2800937518faec878c73784ee195716779f4076768ffade9d72ef1bff243193  .space-build-cvm/assets/ev-wallbox-x0jn38e8.webp
   1301613  5479e43ecd48efa429204f68f49ba234a6c354d2d7429229f9d0015d65a8bb5f  .space-build-cvm/assets/hatch-maps-3ge1fx5t.bin
     69918  768b9ff0c135536afbbee9f20232ac261e8b2b89ce60a29f838024be9dd172e3  .space-build-cvm/assets/hatch-maps-css-hh6yk8h1.bin
    504828  03fd070aa983240f2f6f4e8d39e2bf08b615c147d9f2eba4806b0c5bf113f5c6  .space-build-cvm/assets/heating-5ppfc2fh.jpg
     92766  f7f9bfa4494d68f393826b3a2c258fa037770f751521aa542dcf1ed72454ee03  .space-build-cvm/assets/hero-electrical-4rpksvfm.jpg
     89380  709a54873a015148ac5eb18e1b5fc080c1bd9a2e9c71a8358011c64616c0dd32  .space-build-cvm/assets/hero-plumbing-mw6c23sn.jpg
    651989  539a60a42f2fe79c6ab8e087988ed38ff6d106f8214ea8a8c98a5ae5fadc0197  .space-build-cvm/assets/hero-video-electrical-2gctzhyw.mp4
    736439  c23982ab3fff1b66349f962cbf820b2bc2fce9c28ccf99560290ee453deeda53  .space-build-cvm/assets/hero-video-plumbing-bxr9qxgj.mp4
     92010  6bde8e74a171c284f493cd4ead746a0103699189335617f3673b991eb2539940  .space-build-cvm/assets/kitchen-plumbing-01gxw0wc.jpg
    136051  1e4bfb1c3b2210b1b322805dad3cad84923322c09e1a7f03caac90decd4b3960  .space-build-cvm/assets/pipe-work-bmwxvxhk.jpg
    106396  a4f5c046c72ace7d1d22537e1bed9ad1e4ef22b37d73c37907aabf8bb592700b  .space-build-cvm/assets/solar-z1p03rej.webp
   1922281  55f85adc391dca4454025066c3cda98e0198d78ffb67b4a0f53ae0b51f00fbd0  .space-build-cvm/index.html
       296  f5e3bc05d477a321eb427f29a8ffc32544e8c3a37892597eba831878617830d0  .space-build-cvm/manifest.json
         6  702b023f619f27aa4a5072fb02876fa6a5eb0164ac60222b51bdf40a018836b7  .xmds-icon
      1068  91dcc9f60559d38057b72738fa0e666e8a43f96b522bc50c21065813b32fd194  AGENTS.md
     41871  3bce0056a1c41e6fbd32d7858ffffb6dfc1e60a6ab8d9cc92383b290ac151cea  DATA-PLAN.md
      7431  d0d0bd91981d41ab3301abfc4afcd0862976022a44d1f6e24eac214452d46dab  README.md
    135168  5eb4f48ee49a8e4b685e8e020b33d20f2187bab5074e2cc0370973e94b7c421c  app.db
     21154  8f884f8035a44da8ac679372a774bed9afc33b017111b7fd1e5ac16b6755d053  bun.lock
       497  77c99038fe2cbbdb274e3b324fc20cd0a02a3d3c1db2674d8703e0d2c8b7145e  bunfig.toml
    336243  4ae5bf8caa9566696b5a6f0ee7ebcd5117016f12e8dd5835f7ef1797bb6dac0b  client/.tsbuildinfo.client
       361  e828666e5d505cbc481c7ddddd0d16000832fc26faf4177f3e312db2fdf1c4cc  client/build.mjs
    962979  edb782d60a0372c33e853cc6c93a839cecd246d27984623c251c192e071b2b1e  client/dist/assets/craft-electrical-1fkrm3nz.mp4
     78233  555dd5155e5550082169eda2f72869b17f59b5d9fc3ebfb6d96d23bb86d22920  client/dist/assets/craft-electrical-82jjer8z.jpg
     63498  6bb07620954431f22bd0e17d334bfa32fac8919fe34624b967d60e7718a05dda  client/dist/assets/craft-plumbing-a3zhdmj8.jpg
    928701  4d356795fcad3094beb8fb99fae551bb1d1e2faf7f8fc0ec1196a72384c39ea2  client/dist/assets/craft-plumbing-wrnw0eac.mp4
    146348  5931a76a81e4093c78b157564595e38328d6512a82b9d747928c2115fa993e9b  client/dist/assets/electrical-inspection-t83trc4g.webp
     58394  d2800937518faec878c73784ee195716779f4076768ffade9d72ef1bff243193  client/dist/assets/ev-wallbox-x0jn38e8.webp
   1301613  5479e43ecd48efa429204f68f49ba234a6c354d2d7429229f9d0015d65a8bb5f  client/dist/assets/hatch-maps-3ge1fx5t.bin
     69918  768b9ff0c135536afbbee9f20232ac261e8b2b89ce60a29f838024be9dd172e3  client/dist/assets/hatch-maps-css-hh6yk8h1.bin
    504828  03fd070aa983240f2f6f4e8d39e2bf08b615c147d9f2eba4806b0c5bf113f5c6  client/dist/assets/heating-5ppfc2fh.jpg
     92766  f7f9bfa4494d68f393826b3a2c258fa037770f751521aa542dcf1ed72454ee03  client/dist/assets/hero-electrical-4rpksvfm.jpg
     89380  709a54873a015148ac5eb18e1b5fc080c1bd9a2e9c71a8358011c64616c0dd32  client/dist/assets/hero-plumbing-mw6c23sn.jpg
    651989  539a60a42f2fe79c6ab8e087988ed38ff6d106f8214ea8a8c98a5ae5fadc0197  client/dist/assets/hero-video-electrical-2gctzhyw.mp4
    736439  c23982ab3fff1b66349f962cbf820b2bc2fce9c28ccf99560290ee453deeda53  client/dist/assets/hero-video-plumbing-bxr9qxgj.mp4
   1395191  db3ca2d056a652d9b0ae731d1ff21b54567cc5c5185af58ad53c13da1190366e  client/dist/assets/index-aqbg0kyk.js
     50193  9059cc941bb419333c27950b8818c9f7f4097eb2005fe58354c023bcf334755d  client/dist/assets/index-hjd9ja6y.css
     92010  6bde8e74a171c284f493cd4ead746a0103699189335617f3673b991eb2539940  client/dist/assets/kitchen-plumbing-01gxw0wc.jpg
    136051  1e4bfb1c3b2210b1b322805dad3cad84923322c09e1a7f03caac90decd4b3960  client/dist/assets/pipe-work-bmwxvxhk.jpg
    106396  a4f5c046c72ace7d1d22537e1bed9ad1e4ef22b37d73c37907aabf8bb592700b  client/dist/assets/solar-z1p03rej.webp
      6890  ec1b5ce3f7933c9200ec96b9b000f474d41ad4dd91ae847fe2f61d024c31ff68  client/dist/index.html
    962979  edb782d60a0372c33e853cc6c93a839cecd246d27984623c251c192e071b2b1e  client/dist-cvm/assets/craft-electrical-1fkrm3nz.mp4
     78233  555dd5155e5550082169eda2f72869b17f59b5d9fc3ebfb6d96d23bb86d22920  client/dist-cvm/assets/craft-electrical-82jjer8z.jpg
     63498  6bb07620954431f22bd0e17d334bfa32fac8919fe34624b967d60e7718a05dda  client/dist-cvm/assets/craft-plumbing-a3zhdmj8.jpg
    928701  4d356795fcad3094beb8fb99fae551bb1d1e2faf7f8fc0ec1196a72384c39ea2  client/dist-cvm/assets/craft-plumbing-wrnw0eac.mp4
    146348  5931a76a81e4093c78b157564595e38328d6512a82b9d747928c2115fa993e9b  client/dist-cvm/assets/electrical-inspection-t83trc4g.webp
     58394  d2800937518faec878c73784ee195716779f4076768ffade9d72ef1bff243193  client/dist-cvm/assets/ev-wallbox-x0jn38e8.webp
   1301613  5479e43ecd48efa429204f68f49ba234a6c354d2d7429229f9d0015d65a8bb5f  client/dist-cvm/assets/hatch-maps-3ge1fx5t.bin
     69918  768b9ff0c135536afbbee9f20232ac261e8b2b89ce60a29f838024be9dd172e3  client/dist-cvm/assets/hatch-maps-css-hh6yk8h1.bin
    504828  03fd070aa983240f2f6f4e8d39e2bf08b615c147d9f2eba4806b0c5bf113f5c6  client/dist-cvm/assets/heating-5ppfc2fh.jpg
     92766  f7f9bfa4494d68f393826b3a2c258fa037770f751521aa542dcf1ed72454ee03  client/dist-cvm/assets/hero-electrical-4rpksvfm.jpg
     89380  709a54873a015148ac5eb18e1b5fc080c1bd9a2e9c71a8358011c64616c0dd32  client/dist-cvm/assets/hero-plumbing-mw6c23sn.jpg
    651989  539a60a42f2fe79c6ab8e087988ed38ff6d106f8214ea8a8c98a5ae5fadc0197  client/dist-cvm/assets/hero-video-electrical-2gctzhyw.mp4
    736439  c23982ab3fff1b66349f962cbf820b2bc2fce9c28ccf99560290ee453deeda53  client/dist-cvm/assets/hero-video-plumbing-bxr9qxgj.mp4
     92010  6bde8e74a171c284f493cd4ead746a0103699189335617f3673b991eb2539940  client/dist-cvm/assets/kitchen-plumbing-01gxw0wc.jpg
    136051  1e4bfb1c3b2210b1b322805dad3cad84923322c09e1a7f03caac90decd4b3960  client/dist-cvm/assets/pipe-work-bmwxvxhk.jpg
    106396  a4f5c046c72ace7d1d22537e1bed9ad1e4ef22b37d73c37907aabf8bb592700b  client/dist-cvm/assets/solar-z1p03rej.webp
   1922281  55f85adc391dca4454025066c3cda98e0198d78ffb67b4a0f53ae0b51f00fbd0  client/dist-cvm/index.html
      6796  01c98ce8216b6592f617b17968194dd27c07dc11094230856c4ef4ab59dc7d31  client/index.html
     82052  b3e999198284c0bf01bbd64ed6408812fb43997eb3537e2dd912ad6950f62b51  client/src/App.tsx
    175590  f7c61e6feed2879040e05a15449504645c0596c6680e07dd429d1955081f5432  client/src/admin.tsx
       935  b37eff4d0ae161ae983d7fe49eab48f352dd64b832deb93d6298d7e689885f69  client/src/api.ts
    110783  21791f9253d1cfd91c853810e230bcaf91cea85fa8c5464dd251d13a14a5c386  client/src/assets/.thumbnails/media-generation-services-craft-electrical-0-b2a4b8a5-c6a1-4296-8af2-7b7f1263911b.jpg
     83090  fd4b31ad2b9778ab95478349c1f39aa108d1f4db668e84295d25eb731d7c7cc6  client/src/assets/.thumbnails/media-generation-services-craft-plumbing-0-471fe562-2216-41f3-8cea-d1ca95854c4a.jpg
     78233  555dd5155e5550082169eda2f72869b17f59b5d9fc3ebfb6d96d23bb86d22920  client/src/assets/craft-electrical.jpg
    962979  edb782d60a0372c33e853cc6c93a839cecd246d27984623c251c192e071b2b1e  client/src/assets/craft-electrical.mp4
     63498  6bb07620954431f22bd0e17d334bfa32fac8919fe34624b967d60e7718a05dda  client/src/assets/craft-plumbing.jpg
    928701  4d356795fcad3094beb8fb99fae551bb1d1e2faf7f8fc0ec1196a72384c39ea2  client/src/assets/craft-plumbing.mp4
    146348  5931a76a81e4093c78b157564595e38328d6512a82b9d747928c2115fa993e9b  client/src/assets/electrical-inspection.webp
     58394  d2800937518faec878c73784ee195716779f4076768ffade9d72ef1bff243193  client/src/assets/ev-wallbox.webp
     69918  768b9ff0c135536afbbee9f20232ac261e8b2b89ce60a29f838024be9dd172e3  client/src/assets/hatch-maps-css.bin
   1301613  5479e43ecd48efa429204f68f49ba234a6c354d2d7429229f9d0015d65a8bb5f  client/src/assets/hatch-maps.bin
    504828  03fd070aa983240f2f6f4e8d39e2bf08b615c147d9f2eba4806b0c5bf113f5c6  client/src/assets/heating.jpg
     92766  f7f9bfa4494d68f393826b3a2c258fa037770f751521aa542dcf1ed72454ee03  client/src/assets/hero-electrical.jpg
     89380  709a54873a015148ac5eb18e1b5fc080c1bd9a2e9c71a8358011c64616c0dd32  client/src/assets/hero-plumbing.jpg
    651989  539a60a42f2fe79c6ab8e087988ed38ff6d106f8214ea8a8c98a5ae5fadc0197  client/src/assets/hero-video-electrical.mp4
    736439  c23982ab3fff1b66349f962cbf820b2bc2fce9c28ccf99560290ee453deeda53  client/src/assets/hero-video-plumbing.mp4
     92010  6bde8e74a171c284f493cd4ead746a0103699189335617f3673b991eb2539940  client/src/assets/kitchen-plumbing.jpg
       457  7c37ccfcb26c7c3e5aff064c18eb7138a6592591f22f4ffebacaa6a5e8c0b593  client/src/assets/media-generation-services-craft-electrical-1794245497.json
       457  db20b4de050935b9d15d6975c5c1d9545362b6aff103e8cafa544621c8bacfb3  client/src/assets/media-generation-services-craft-plumbing-1794245496.json
    136051  1e4bfb1c3b2210b1b322805dad3cad84923322c09e1a7f03caac90decd4b3960  client/src/assets/pipe-work.jpg
    106396  a4f5c046c72ace7d1d22537e1bed9ad1e4ef22b37d73c37907aabf8bb592700b  client/src/assets/solar.webp
     20108  784b99d8999ade3a2bfd6dbdbcb865594d1e64da1f390858dafd39b3f4700bed  client/src/catalog.ts
     13082  65d3550d6e264164d71bacc06d1485a2da93eaa491306b3c5df6e95b3ebd4bfb  client/src/forms.tsx
      1615  a4e28444f42e8d742993e52ee6520028d5fa94224dbbdde5c7eb29df30cae65e  client/src/globals.d.ts
     51651  a4ad4fb8032a43ba8ae3791d81fc44cb85e35d7cac449e0769320dd56a7f50f1  client/src/i18n.ts
      5408  6fbc1539669e50513e03b8b3c7865fddf0ed6153a46bc0f56b20b90fc2c95d83  client/src/main.tsx
      6961  a2e9c9ec09a47576c0faf78e290ec46dc680ce7f54f995ddb8c493899c044a38  client/src/map-helpers.mjs
     24188  4934c40b70cc4309cea0d3dc7ad790a8fc2695c0d37f10bee7bc24cfd85c4601  client/src/portal.tsx
     40198  c6b368ec3df8a9173effa2fb7cb87d1bfeb9e7842d7ba89961bb79ce767405ce  client/src/scrolly-i18n.ts
     35220  f98fba69aea190737cb902a5091136c672465cbc02614a2ebc061234d22e7c42  client/src/scrolly.tsx
    104769  2cc3c6e55dd48a7e0bcf6faceececa351e037519eed23df5c67d0064561ede63  client/src/service-i18n.ts
      7494  013a747efab1f67a99589fc13e3726d0e9c1e9c668fab8f71eb064d8e6d73bbc  client/src/service-map.tsx
      2503  b1f7fe35bd4e8fcc3474fa8a55792ed6994f56a129f6cc10bf96efd7ccbf47e6  client/src/storage.ts
      8986  3ff926e9298149c28905cc87e05776eaf4148ce5fabc66b871d235a925f6d384  client/src/theme.css
     29316  71a5092c0ba97befcf3d8111bf5129ce0997a8f18e7fd9324bf31c8906246a82  client/src/upgrade-i18n.ts
       430  d9cc6609a832013b9cdb0d81c0c997a426e20b94c93fee3fa1472916bb42c971  client/tsconfig.json
     13845  1d40c7e451dfc613852569acc77b3c64418e70efb8aba260cb4dabf84744c643  database/app-dump.sql
    135168  5eb4f48ee49a8e4b685e8e020b33d20f2187bab5074e2cc0370973e94b7c421c  database/app.db
       118  f80c5bf6f7a9bf54eda650a2ac2fcc4390051e8c56a52d5be51e5cbf641b7ba9  drizzle/0001_initial.sql
      5208  2c12dbb1d94a5ee2c336379591319c451c4656ef90e2b24c07d9363f709cec2f  drizzle/0002_s_services_platform_tables.sql
       728  9f13ffaeca8330e9c4ae6b21ffe984a24bfe0c26f2dc9d76b112b4b0cf4ccb98  drizzle/0003_staff_and_customer_auth.sql
       654  06b8212d0d882ff959aafdb41e03de90b69f9e3c276b6c61a4ffc7c414619bff  drizzle/0004_offers_and_promotions.sql
       652  1f4f1a8d5047960f8f27a6d86ef9eb4d1cba2954e2b0528e2ae2aab3742cde5a  drizzle/meta/_journal.json
     24146  9863bcc3e41858e698ed1f646a745c2f34c34e450991442a299c931ef819a238  icon.webp
      1050  fb6ddb516dfe9b538e1532a784ef41daea86bd4f1e64e48886b162d2d5b19560  package.json
    137454  aa3fe4c1816bf0f8f8c473dc891e6b8941e653d7cc6e50f81101a583bbdafb8f  server/.tsbuildinfo.server
    264829  c280c6d927877a34ff8dd6a34f5f106c959b20108ff76688ae1102079330b593  server/dist/actions.js
     32799  4c00cec66bcf4236cbb503bcb1fd4f284176cad6bb7aa78373395f38512e42d7  server/dist/actions.meta.json
     92709  3f80854366537f6553a547da871bcd65a6a86717f7403f74e6eb99ca17c6ee70  server/src/actions.ts
      6007  d6e68118a9260313d1df0db979b73dbb4bd70eaddbac17d18a891eb718fff3a3  server/src/catalog.ts
     10793  aa6b9efcee3b54a0792d2bd1a40c6d5848bb4d295a49f4ed3d45e01d1862b828  server/src/schema.ts
       343  5698f6c130a85287640ab69e8ea859d49aba21266333a68494afc52e92c335a5  server/tsconfig.json
       167  ca9b0d19d48291e48db88ee1062b60c7c01ef03d2e0749d292b5efb544e3266a  space.json
       635  1000b5fb48cee172a53a1ad37c821330b3f48b227f4fc580070b393e1d80ba1f  tsconfig.base.json
```

Note: BACKUP-MANIFEST.md itself is not listed above (a file cannot contain its own hash). Verify with: `sha256sum -c` against the hash list, or compare individual files.
