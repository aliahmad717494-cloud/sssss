export type CatalogService = {
  slug: string;
  category: "electrical" | "plumbing";
  nameIt: string;
  nameEn: string;
};

export const CATALOG: CatalogService[] = [
  // Electrical (order from the brief)
  { slug: "residential-electrical-installation", category: "electrical", nameIt: "Installazione Elettrica Residenziale", nameEn: "Residential Electrical Installation" },
  { slug: "commercial-electrical-systems", category: "electrical", nameIt: "Impianti Elettrici Commerciali", nameEn: "Commercial Electrical Systems" },
  { slug: "industrial-electrical-installations", category: "electrical", nameIt: "Installazioni Elettriche Industriali", nameEn: "Industrial Electrical Installations" },
  { slug: "electrical-repairs", category: "electrical", nameIt: "Riparazioni Elettriche", nameEn: "Electrical Repairs" },
  { slug: "emergency-electrical-services", category: "electrical", nameIt: "Servizi Elettrici di Emergenza", nameEn: "Emergency Electrical Services" },
  { slug: "electrical-panel-installation", category: "electrical", nameIt: "Installazione Quadro Elettrico", nameEn: "Electrical Panel Installation" },
  { slug: "circuit-breaker-replacement", category: "electrical", nameIt: "Sostituzione Interruttori Magnetotermici", nameEn: "Circuit Breaker Replacement" },
  { slug: "lighting-installation", category: "electrical", nameIt: "Installazione Illuminazione", nameEn: "Lighting Installation" },
  { slug: "led-lighting-solutions", category: "electrical", nameIt: "Soluzioni di Illuminazione LED", nameEn: "LED Lighting Solutions" },
  { slug: "indoor-outdoor-lighting", category: "electrical", nameIt: "Illuminazione Interna ed Esterna", nameEn: "Indoor and Outdoor Lighting" },
  { slug: "wiring-rewiring", category: "electrical", nameIt: "Cablaggio e Ricablaggio", nameEn: "Wiring and Rewiring" },
  { slug: "electrical-fault-detection", category: "electrical", nameIt: "Ricerca Guasti Elettrici", nameEn: "Electrical Fault Detection" },
  { slug: "electrical-maintenance", category: "electrical", nameIt: "Manutenzione Elettrica", nameEn: "Electrical Maintenance" },
  { slug: "smart-home-installation", category: "electrical", nameIt: "Installazione Smart Home", nameEn: "Smart Home Installation" },
  { slug: "home-automation", category: "electrical", nameIt: "Domotica e Automazione Domestica", nameEn: "Home Automation" },
  { slug: "security-cctv-installation", category: "electrical", nameIt: "Installazione Sicurezza e Videosorveglianza", nameEn: "Security and CCTV Installation" },
  { slug: "solar-panel-installation", category: "electrical", nameIt: "Installazione Pannelli Solari", nameEn: "Solar Panel Installation" },
  { slug: "ev-charger-installation", category: "electrical", nameIt: "Installazione Caricatore per Veicoli Elettrici", nameEn: "EV Charger Installation" },
  { slug: "electrical-inspection", category: "electrical", nameIt: "Ispezione e Verifica Elettrica", nameEn: "Electrical Inspection" },
  { slug: "energy-efficiency-solutions", category: "electrical", nameIt: "Soluzioni di Efficienza Energetica", nameEn: "Energy Efficiency Solutions" },
  // Plumbing (order from the brief)
  { slug: "residential-plumbing", category: "plumbing", nameIt: "Idraulica Residenziale", nameEn: "Residential Plumbing" },
  { slug: "commercial-plumbing", category: "plumbing", nameIt: "Idraulica Commerciale", nameEn: "Commercial Plumbing" },
  { slug: "industrial-plumbing", category: "plumbing", nameIt: "Idraulica Industriale", nameEn: "Industrial Plumbing" },
  { slug: "emergency-plumbing", category: "plumbing", nameIt: "Idraulica di Emergenza", nameEn: "Emergency Plumbing" },
  { slug: "water-leak-detection", category: "plumbing", nameIt: "Ricerca Perdite d'Acqua", nameEn: "Water Leak Detection" },
  { slug: "pipe-installation", category: "plumbing", nameIt: "Installazione Tubazioni", nameEn: "Pipe Installation" },
  { slug: "pipe-repair", category: "plumbing", nameIt: "Riparazione Tubazioni", nameEn: "Pipe Repair" },
  { slug: "drain-cleaning", category: "plumbing", nameIt: "Pulizia Scarichi", nameEn: "Drain Cleaning" },
  { slug: "blocked-drain-removal", category: "plumbing", nameIt: "Disostruzione Scarichi", nameEn: "Blocked Drain Removal" },
  { slug: "bathroom-plumbing", category: "plumbing", nameIt: "Idraulica Bagno", nameEn: "Bathroom Plumbing" },
  { slug: "kitchen-plumbing", category: "plumbing", nameIt: "Idraulica Cucina", nameEn: "Kitchen Plumbing" },
  { slug: "bathroom-renovation", category: "plumbing", nameIt: "Ristrutturazione Bagno", nameEn: "Bathroom Renovation" },
  { slug: "water-heater-installation", category: "plumbing", nameIt: "Installazione Scaldabagno", nameEn: "Water Heater Installation" },
  { slug: "boiler-installation-maintenance", category: "plumbing", nameIt: "Installazione e Manutenzione Caldaie", nameEn: "Boiler Installation and Maintenance" },
  { slug: "heating-systems", category: "plumbing", nameIt: "Impianti di Riscaldamento", nameEn: "Heating Systems" },
  { slug: "water-pressure-problems", category: "plumbing", nameIt: "Problemi di Pressione dell'Acqua", nameEn: "Water Pressure Problems" },
  { slug: "sanitary-installation", category: "plumbing", nameIt: "Installazione Sanitari", nameEn: "Sanitary Installation" },
  { slug: "tap-faucet-installation", category: "plumbing", nameIt: "Installazione Rubinetteria", nameEn: "Tap and Faucet Installation" },
  { slug: "toilet-repair-installation", category: "plumbing", nameIt: "Riparazione e Installazione WC", nameEn: "Toilet Repair and Installation" },
  { slug: "water-supply-systems", category: "plumbing", nameIt: "Impianti di Adduzione Idrica", nameEn: "Water Supply Systems" },
  { slug: "plumbing-inspection", category: "plumbing", nameIt: "Ispezione Idraulica", nameEn: "Plumbing Inspection" },
  { slug: "preventive-maintenance", category: "plumbing", nameIt: "Manutenzione Preventiva", nameEn: "Preventive Maintenance" },
];

export const TIME_SLOTS = [
  "08:00",
  "09:30",
  "11:00",
  "12:30",
  "14:00",
  "15:30",
  "17:00",
];
