import { defineAction, z, type ActionsModule, type Ctx } from "@hatch/space-sdk";
import { and, asc, desc, eq, ne } from "drizzle-orm";
import * as schema from "./schema";
import { CATALOG, TIME_SLOTS } from "./catalog";

type Db = ReturnType<Ctx["db"]>;

const okResponse = z.object({ ok: z.literal(true) });

function ref(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${rand}`;
}

async function log(db: Db, action: string, detail: string) {
  await db.insert(schema.activityLog).values({ action, detail });
}

async function notify(
  db: Db,
  title: string,
  body: string,
  email: string | null,
) {
  await db.insert(schema.notifications).values({ title, body, email });
}

async function upsertCustomer(
  db: Db,
  name: string,
  email: string,
  phone: string,
  address: string,
  language: string,
) {
  const existing = await db
    .select()
    .from(schema.customers)
    .where(eq(schema.customers.email, email))
    .limit(1);
  if (existing.length === 0) {
    await db
      .insert(schema.customers)
      .values({ name, email, phone, address, language });
  }
}

async function settingsMap(db: Db): Promise<Record<string, string>> {
  const rows = await db.select().from(schema.settings);
  const out: Record<string, string> = {};
  for (const r of rows) out[r.key] = r.value;
  return out;
}

/* ---------- Authentication: staff back office + customer accounts ----
   Passwords: PBKDF2-HMAC-SHA256 (WebCrypto) with a per-account random
   salt, stored as "pbkdf2$<iterations>$<salt b64>$<hash b64>".
   Sessions: 256-bit random bearer tokens; only the SHA-256 hash of a
   token is ever stored. Every admin action calls requireStaff, so
   authorization is enforced on the server — the client only chooses
   which screens to render for the role it was given at login. */

const PBKDF2_ITERATIONS = 210_000;
const SESSION_MS = 1000 * 60 * 60 * 24 * 30; // 30 days
/* The one email address the site owner authorized as administrator
   (supplied by the owner for the Admin Panel, Report 23). It gates
   ONLY the one-time first-admin setup (staffBootstrap); afterwards,
   staff accounts are managed in Admin → Staff Access. It is an email
   address, not a credential — no password is ever stored in code. */
const AUTHORIZED_ADMIN_EMAIL = "494motors@gmail.com";

function b64encode(bytes: Uint8Array): string {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
}
function b64decode(s: string): Uint8Array {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function pbkdf2(
  password: string,
  salt: Uint8Array,
  iterations: number,
): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations, hash: "SHA-256" },
    key,
    256,
  );
  return new Uint8Array(bits);
}
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await pbkdf2(password, salt, PBKDF2_ITERATIONS);
  return `pbkdf2$${PBKDF2_ITERATIONS}$${b64encode(salt)}$${b64encode(hash)}`;
}
async function verifyPassword(
  password: string,
  stored: string,
): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 4 || parts[0] !== "pbkdf2") return false;
  const iterations = Number(parts[1]);
  if (!Number.isFinite(iterations) || iterations < 1000) return false;
  try {
    const salt = b64decode(parts[2] ?? "");
    const expected = b64decode(parts[3] ?? "");
    const actual = await pbkdf2(password, salt, iterations);
    if (actual.length !== expected.length) return false;
    let diff = 0;
    for (let i = 0; i < actual.length; i++)
      diff |= (actual[i] ?? 0) ^ (expected[i] ?? 0);
    return diff === 0;
  } catch {
    return false;
  }
}
async function sha256Hex(input: string): Promise<string> {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(input),
  );
  return [...new Uint8Array(digest)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}
async function createSession(
  db: Db,
  kind: "staff" | "customer",
  email: string,
  staffId: number | null,
): Promise<string> {
  const raw = b64encode(crypto.getRandomValues(new Uint8Array(32)));
  await db.insert(schema.sessions).values({
    tokenHash: await sha256Hex(raw),
    kind,
    email,
    staffId,
    expiresAt: Date.now() + SESSION_MS,
  });
  return raw;
}
type SessionDbRow = typeof schema.sessions.$inferSelect;
async function getSession(
  db: Db,
  token: string,
): Promise<SessionDbRow | null> {
  if (!token) return null;
  const tokenHash = await sha256Hex(token);
  const rows = await db
    .select()
    .from(schema.sessions)
    .where(eq(schema.sessions.tokenHash, tokenHash))
    .limit(1);
  const s = rows[0];
  if (!s) return null;
  if (s.expiresAt < Date.now()) {
    await db
      .delete(schema.sessions)
      .where(eq(schema.sessions.tokenHash, tokenHash));
    return null;
  }
  return s;
}
type StaffDbRow = typeof schema.staffUsers.$inferSelect;
async function requireStaff(
  db: Db,
  token: string,
  roles: readonly string[],
): Promise<StaffDbRow> {
  const s = await getSession(db, token);
  if (!s || s.kind !== "staff" || s.staffId == null)
    throw new Error("UNAUTHORIZED");
  const rows = await db
    .select()
    .from(schema.staffUsers)
    .where(eq(schema.staffUsers.id, s.staffId))
    .limit(1);
  const u = rows[0];
  if (!u || u.active !== 1) throw new Error("UNAUTHORIZED");
  if (!roles.includes(u.role)) throw new Error("FORBIDDEN");
  return u;
}
async function hasCustomerSession(
  db: Db,
  token: string,
  email: string,
): Promise<boolean> {
  const s = await getSession(db, token);
  return !!s && s.kind === "customer" && s.email === email.toLowerCase();
}

const authResponse = z.object({
  ok: z.boolean(),
  error: z.string(),
  token: z.string(),
  name: z.string(),
  role: z.string(),
  technician_id: z.number().nullable(),
});
const authFail = (error: string): z.infer<typeof authResponse> => ({
  ok: false,
  error,
  token: "",
  name: "",
  role: "",
  technician_id: null,
});

const serviceRow = z.object({
  slug: z.string(),
  category: z.string(),
  name_it: z.string(),
  name_en: z.string(),
  sort: z.number(),
  published: z.boolean(),
  base_price_cents: z.number().nullable(),
});

const bookingRow = z.object({
  id: z.number(),
  ref: z.string(),
  service_slug: z.string(),
  category: z.string(),
  property_type: z.string(),
  description: z.string(),
  customer_name: z.string(),
  customer_email: z.string(),
  customer_phone: z.string(),
  address: z.string(),
  city: z.string(),
  postal_code: z.string(),
  date: z.string(),
  slot: z.string(),
  language: z.string(),
  is_emergency: z.boolean(),
  status: z.string(),
  technician_id: z.number().nullable(),
  internal_notes: z.string(),
  work_notes: z.string(),
  photo_name: z.string(),
  created_at: z.string(),
});

type BookingDbRow = typeof schema.bookings.$inferSelect;
function mapBooking(r: BookingDbRow): z.infer<typeof bookingRow> {
  return {
    id: r.id,
    ref: r.ref,
    service_slug: r.serviceSlug,
    category: r.category,
    property_type: r.propertyType,
    description: r.description,
    customer_name: r.customerName,
    customer_email: r.customerEmail,
    customer_phone: r.customerPhone,
    address: r.address,
    city: r.city,
    postal_code: r.postalCode,
    date: r.date,
    slot: r.slot,
    language: r.language,
    is_emergency: r.isEmergency === 1,
    status: r.status,
    technician_id: r.technicianId,
    internal_notes: r.internalNotes,
    work_notes: r.workNotes,
    photo_name: r.photoName,
    created_at: r.createdAt.toISOString(),
  };
}

const quoteRequestRow = z.object({
  id: z.number(),
  ref: z.string(),
  service_slug: z.string(),
  description: z.string(),
  property_type: z.string(),
  measurements: z.string(),
  address: z.string(),
  city: z.string(),
  customer_name: z.string(),
  customer_email: z.string(),
  customer_phone: z.string(),
  language: z.string(),
  status: z.string(),
  photo_name: z.string(),
  created_at: z.string(),
});

type QrDbRow = typeof schema.quoteRequests.$inferSelect;
function mapQr(r: QrDbRow): z.infer<typeof quoteRequestRow> {
  return {
    id: r.id,
    ref: r.ref,
    service_slug: r.serviceSlug,
    description: r.description,
    property_type: r.propertyType,
    measurements: r.measurements,
    address: r.address,
    city: r.city,
    customer_name: r.customerName,
    customer_email: r.customerEmail,
    customer_phone: r.customerPhone,
    language: r.language,
    status: r.status,
    photo_name: r.photoName,
    created_at: r.createdAt.toISOString(),
  };
}

const quotationRow = z.object({
  id: z.number(),
  ref: z.string(),
  quote_request_id: z.number().nullable(),
  customer_name: z.string(),
  customer_email: z.string(),
  title: z.string(),
  labour_cents: z.number(),
  materials_cents: z.number(),
  service_cents: z.number(),
  discount_cents: z.number(),
  total_cents: z.number(),
  currency: z.string(),
  expiry_date: z.string(),
  status: z.string(),
  created_at: z.string(),
});

type QDbRow = typeof schema.quotations.$inferSelect;
function mapQ(r: QDbRow): z.infer<typeof quotationRow> {
  return {
    id: r.id,
    ref: r.ref,
    quote_request_id: r.quoteRequestId,
    customer_name: r.customerName,
    customer_email: r.customerEmail,
    title: r.title,
    labour_cents: r.labourCents,
    materials_cents: r.materialsCents,
    service_cents: r.serviceCents,
    discount_cents: r.discountCents,
    total_cents:
      r.labourCents + r.materialsCents + r.serviceCents - r.discountCents,
    currency: r.currency,
    expiry_date: r.expiryDate,
    status: r.status,
    created_at: r.createdAt.toISOString(),
  };
}

const invoiceRow = z.object({
  id: z.number(),
  ref: z.string(),
  quotation_id: z.number().nullable(),
  customer_name: z.string(),
  customer_email: z.string(),
  amount_cents: z.number(),
  currency: z.string(),
  status: z.string(),
  due_date: z.string(),
  created_at: z.string(),
});

type IDbRow = typeof schema.invoices.$inferSelect;
function mapI(r: IDbRow): z.infer<typeof invoiceRow> {
  return {
    id: r.id,
    ref: r.ref,
    quotation_id: r.quotationId,
    customer_name: r.customerName,
    customer_email: r.customerEmail,
    amount_cents: r.amountCents,
    currency: r.currency,
    status: r.status,
    due_date: r.dueDate,
    created_at: r.createdAt.toISOString(),
  };
}

const areaRow = z.object({
  id: z.number(),
  country: z.string(),
  region: z.string(),
  city: z.string(),
  postal_codes: z.string(),
  electrical: z.boolean(),
  plumbing: z.boolean(),
  emergency: z.boolean(),
  active: z.boolean(),
  surcharge_cents: z.number(),
});

const techRow = z.object({
  id: z.number(),
  name: z.string(),
  email: z.string(),
  phone: z.string(),
  specialty: z.string(),
  role: z.string(),
  active: z.boolean(),
});

/* ---------- Offers & promotions (Report 22) ----------
   Reusable promotions, distinct from a quotation's one-off discount.
   An offer is "live" when it is enabled and today falls inside its
   [starts_at, expires_at] window (empty bounds are open). Visibility:
   public offers go to everyone; clients/selected offers are released
   only by getPortal/adminGetAll, never by the public getState. */
const offerRow = z.object({
  id: z.number(),
  title: z.string(),
  description: z.string(),
  discount_type: z.string(),
  discount_value: z.number(),
  scope: z.string(),
  service_slug: z.string(),
  active: z.boolean(),
  starts_at: z.string(),
  expires_at: z.string(),
  created_at: z.string(),
  assigned_emails: z.array(z.string()),
});

type OfferDbRow = typeof schema.offers.$inferSelect;
function mapOffer(
  r: OfferDbRow,
  assigned: string[],
): z.infer<typeof offerRow> {
  return {
    id: r.id,
    title: r.title,
    description: r.description,
    discount_type: r.discountType,
    discount_value: r.discountValue,
    scope: r.scope,
    service_slug: r.serviceSlug,
    active: r.active === 1,
    starts_at: r.startsAt,
    expires_at: r.expiresAt,
    created_at: r.createdAt.toISOString(),
    assigned_emails: assigned,
  };
}

function todayStr(): string {
  return new Date().toISOString().slice(0, 10);
}
function offerIsLive(r: OfferDbRow, today: string): boolean {
  if (r.active !== 1) return false;
  if (r.startsAt && r.startsAt > today) return false;
  if (r.expiresAt && r.expiresAt < today) return false;
  return true;
}
async function assignmentsByOffer(
  db: Db,
): Promise<Map<number, string[]>> {
  const rows = await db.select().from(schema.offerAssignments);
  const m = new Map<number, string[]>();
  for (const r of rows) {
    const list = m.get(r.offerId) ?? [];
    list.push(r.customerEmail);
    m.set(r.offerId, list);
  }
  return m;
}

export const Actions = {
  populateCatalog: defineAction({
    description:
      "Seeds the 42-service catalogue from the S SERVICES brief and default settings, only when empty; never overwrites admin edits.",
    request: z.object({}),
    response: z.object({
      services_inserted: z.number(),
      already_present: z.boolean(),
    }),
    async handler(ctx) {
      const db = ctx.db<typeof schema>();
      const existing = await db.select().from(schema.services);
      if (existing.length > 0) {
        return { services_inserted: 0, already_present: true };
      }
      for (let i = 0; i < CATALOG.length; i++) {
        const s = CATALOG[i];
        if (!s) continue;
        await db.insert(schema.services).values({
          slug: s.slug,
          category: s.category,
          nameIt: s.nameIt,
          nameEn: s.nameEn,
          sort: i,
          published: 1,
        });
      }
      const defaults: Record<string, string> = {
        default_theme: "electric",
        default_language: "it",
        default_currency: "EUR",
        company_phone: "",
        company_whatsapp: "",
        company_email: "",
        company_address: "",
        company_hours: "",
        contact_availability: "",
        /* Interactive service-area map. The starting values are a
           clearly-labelled DEMO location (Rome) — map_is_demo stays
           "1" until an administrator saves the company's real base
           and switches the demo flag off in Settings. */
        map_name: "Roma",
        map_address: "Roma, Italia",
        map_lat: "41.9028",
        map_lng: "12.4964",
        map_radius_km: "25",
        map_is_demo: "1",
        emergency_enabled: "",
        emergency_note: "",
        hero_video_url: "",
        hero_video_url_2: "",
        hero_video_mode: "builtin",
        float_call_enabled: "1",
        float_whatsapp_enabled: "1",
        float_whatsapp_message: "",
        about_it: "",
        about_en: "",
      };
      for (const [key, value] of Object.entries(defaults)) {
        await db
          .insert(schema.settings)
          .values({ key, value })
          .onConflictDoNothing();
      }
      await log(db, "catalog.populate", `${CATALOG.length} services seeded`);
      return { services_inserted: CATALOG.length, already_present: false };
    },
  }),

  getState: defineAction({
    description:
      "Returns the public platform state: published services, active service areas, projects, approved reviews, active technicians and public settings.",
    request: z.object({}),
    response: z.object({
      services: z.array(serviceRow),
      areas: z.array(areaRow),
      projects: z.array(
        z.object({
          id: z.number(),
          title: z.string(),
          category: z.string(),
          location: z.string(),
          description: z.string(),
          is_demo: z.boolean(),
        }),
      ),
      reviews: z.array(
        z.object({
          id: z.number(),
          customer_name: z.string(),
          service_slug: z.string(),
          rating: z.number(),
          body: z.string(),
          created_at: z.string(),
        }),
      ),
      technicians: z.array(
        z.object({
          id: z.number(),
          name: z.string(),
          specialty: z.string(),
          role: z.string(),
        }),
      ),
      settings: z.record(z.string(), z.string()),
      slots: z.array(z.string()),
      offers: z.array(offerRow),
    }),
    async handler(ctx) {
      const db = ctx.db<typeof schema>();
      const services = await db
        .select()
        .from(schema.services)
        .orderBy(asc(schema.services.sort));
      const areas = await db
        .select()
        .from(schema.serviceAreas)
        .where(eq(schema.serviceAreas.active, 1))
        .orderBy(asc(schema.serviceAreas.country), asc(schema.serviceAreas.city));
      const projects = await db
        .select()
        .from(schema.projects)
        .orderBy(desc(schema.projects.id));
      const reviews = await db
        .select()
        .from(schema.reviews)
        .where(eq(schema.reviews.approved, 1))
        .orderBy(desc(schema.reviews.id));
      const techs = await db
        .select()
        .from(schema.technicians)
        .where(eq(schema.technicians.active, 1));
      const all = await settingsMap(db);
      const pub: Record<string, string> = {};
      for (const k of [
        "default_theme",
        "default_language",
        "default_currency",
        "company_phone",
        "company_whatsapp",
        "company_email",
        "company_address",
        "company_hours",
        "contact_availability",
        "map_name",
        "map_address",
        "map_lat",
        "map_lng",
        "map_radius_km",
        "map_is_demo",
        "emergency_enabled",
        "emergency_note",
        "hero_video_url",
        "hero_video_url_2",
        "hero_video_mode",
        "float_call_enabled",
        "float_whatsapp_enabled",
        "float_whatsapp_message",
        "about_it",
        "about_en",
        /* Website management (Report 23): branding + editable content
           managed in Admin → Settings → Website Settings. Empty values
           fall back to the built-in translated defaults client-side. */
        "site_name",
        "site_tagline",
        "site_logo",
        "site_favicon",
        "hero_title",
        "hero_sub",
        "footer_text",
        "social_facebook",
        "social_instagram",
        "social_youtube",
        "social_linkedin",
      ]) {
        pub[k] = all[k] ?? "";
      }
      /* Service-area map fallback: until an administrator saves real
         coordinates in Settings, the public map shows the clearly
         labelled DEMO location (Rome, 25 km) — never presented as the
         company's real base. Once real coordinates are saved they are
         published verbatim and the demo flag is whatever the admin
         set (Settings turns it off when real values are saved). */
      {
        const lat = Number.parseFloat(pub["map_lat"] ?? "");
        const lng = Number.parseFloat(pub["map_lng"] ?? "");
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
          pub["map_name"] = pub["map_name"] || "Roma";
          pub["map_address"] = pub["map_address"] || "Roma, Italia";
          pub["map_lat"] = "41.9028";
          pub["map_lng"] = "12.4964";
          pub["map_radius_km"] = pub["map_radius_km"] || "25";
          pub["map_is_demo"] = "1";
        } else if (!pub["map_radius_km"]) {
          pub["map_radius_km"] = "25";
        }
      }
      return {
        services: services.map((s) => ({
          slug: s.slug,
          category: s.category,
          name_it: s.nameIt,
          name_en: s.nameEn,
          sort: s.sort,
          published: s.published === 1,
          base_price_cents: s.basePriceCents,
        })),
        areas: areas.map((a) => ({
          id: a.id,
          country: a.country,
          region: a.region,
          city: a.city,
          postal_codes: a.postalCodes,
          electrical: a.electrical === 1,
          plumbing: a.plumbing === 1,
          emergency: a.emergency === 1,
          active: a.active === 1,
          surcharge_cents: a.surchargeCents,
        })),
        projects: projects.map((p) => ({
          id: p.id,
          title: p.title,
          category: p.category,
          location: p.location,
          description: p.description,
          is_demo: p.isDemo === 1,
        })),
        reviews: reviews.map((r) => ({
          id: r.id,
          customer_name: r.customerName,
          service_slug: r.serviceSlug,
          rating: r.rating,
          body: r.body,
          created_at: r.createdAt.toISOString(),
        })),
        technicians: techs.map((t) => ({
          id: t.id,
          name: t.name,
          specialty: t.specialty,
          role: t.role,
        })),
        settings: pub,
        slots: TIME_SLOTS,
        offers: await (async () => {
          /* Public state carries ONLY live public offers — clients-only
             and selected-client offers are never exposed to anonymous
             visitors; they are released by getPortal per account. */
          const today = todayStr();
          const rows = await db
            .select()
            .from(schema.offers)
            .orderBy(desc(schema.offers.id));
          return rows
            .filter((o) => o.scope === "public" && offerIsLive(o, today))
            .map((o) => mapOffer(o, []));
        })(),
      };
    },
  }),

  getBookedSlots: defineAction({
    description:
      "Returns the time slots already taken by active bookings on a given date, for double-booking prevention.",
    request: z.object({ date: z.string().min(4) }),
    response: z.object({ taken: z.array(z.string()) }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.bookings)
        .where(
          and(
            eq(schema.bookings.date, args.date),
            ne(schema.bookings.status, "cancelled"),
          ),
        );
      return { taken: rows.map((r) => r.slot).filter((s) => s !== "") };
    },
  }),

  createBooking: defineAction({
    description:
      "Creates a booking or emergency request; rejects the request if the chosen date and time slot are already held by an active booking.",
    request: z.object({
      service_slug: z.string().min(1),
      property_type: z.string().default("residential"),
      description: z.string().default(""),
      customer_name: z.string().min(2),
      customer_email: z.string().email(),
      customer_phone: z.string().default(""),
      address: z.string().default(""),
      city: z.string().default(""),
      postal_code: z.string().default(""),
      date: z.string().default(""),
      slot: z.string().default(""),
      language: z.string().default("it"),
      is_emergency: z.boolean().default(false),
      photo_name: z.string().default(""),
    }),
    response: z.object({
      ok: z.boolean(),
      ref: z.string(),
      error: z.string(),
    }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const svc = await db
        .select()
        .from(schema.services)
        .where(eq(schema.services.slug, args.service_slug))
        .limit(1);
      const service = svc[0];
      if (!service) return { ok: false, ref: "", error: "service_not_found" };
      if (!args.is_emergency && args.date && args.slot) {
        const clash = await db
          .select()
          .from(schema.bookings)
          .where(
            and(
              eq(schema.bookings.date, args.date),
              eq(schema.bookings.slot, args.slot),
              ne(schema.bookings.status, "cancelled"),
            ),
          )
          .limit(1);
        if (clash.length > 0)
          return { ok: false, ref: "", error: "slot_taken" };
      }
      const r = ref(args.is_emergency ? "EMG" : "BK");
      await db.insert(schema.bookings).values({
        ref: r,
        serviceSlug: args.service_slug,
        category: service.category,
        propertyType: args.property_type,
        description: args.description,
        customerName: args.customer_name,
        customerEmail: args.customer_email,
        customerPhone: args.customer_phone,
        address: args.address,
        city: args.city,
        postalCode: args.postal_code,
        date: args.date,
        slot: args.slot,
        language: args.language,
        isEmergency: args.is_emergency ? 1 : 0,
        photoName: args.photo_name,
        status: "new",
      });
      await upsertCustomer(
        db,
        args.customer_name,
        args.customer_email,
        args.customer_phone,
        args.address,
        args.language,
      );
      await notify(
        db,
        args.is_emergency ? "Emergency request" : "Booking confirmed",
        `${r} · ${service.nameEn} · ${args.date} ${args.slot}`.trim(),
        args.customer_email,
      );
      await notify(
        db,
        args.is_emergency ? "New emergency request" : "New booking",
        `${r} from ${args.customer_name} (${args.customer_email})`,
        null,
      );
      await log(db, "booking.create", r);
      ctx.invalidateQueries();
      return { ok: true, ref: r, error: "" };
    },
  }),

  createQuoteRequest: defineAction({
    description:
      "Creates a quotation request from a customer; a priced quotation is only produced later by the admin, never automatically.",
    request: z.object({
      service_slug: z.string().min(1),
      description: z.string().min(3),
      property_type: z.string().default("residential"),
      measurements: z.string().default(""),
      address: z.string().default(""),
      city: z.string().default(""),
      customer_name: z.string().min(2),
      customer_email: z.string().email(),
      customer_phone: z.string().default(""),
      language: z.string().default("it"),
      photo_name: z.string().default(""),
    }),
    response: z.object({
      ok: z.boolean(),
      ref: z.string(),
      error: z.string(),
    }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const svc = await db
        .select()
        .from(schema.services)
        .where(eq(schema.services.slug, args.service_slug))
        .limit(1);
      if (svc.length === 0)
        return { ok: false, ref: "", error: "service_not_found" };
      const r = ref("QR");
      await db.insert(schema.quoteRequests).values({
        ref: r,
        serviceSlug: args.service_slug,
        description: args.description,
        propertyType: args.property_type,
        measurements: args.measurements,
        address: args.address,
        city: args.city,
        customerName: args.customer_name,
        customerEmail: args.customer_email,
        customerPhone: args.customer_phone,
        language: args.language,
        photoName: args.photo_name,
        status: "new",
      });
      await upsertCustomer(
        db,
        args.customer_name,
        args.customer_email,
        args.customer_phone,
        args.address,
        args.language,
      );
      await notify(
        db,
        "Quotation request received",
        `${r} — our team will review your project and prepare a quotation.`,
        args.customer_email,
      );
      await notify(db, "New quotation request", `${r} from ${args.customer_name}`, null);
      await log(db, "quote_request.create", r);
      ctx.invalidateQueries();
      return { ok: true, ref: r, error: "" };
    },
  }),

  submitMessage: defineAction({
    description: "Stores a contact or support message from the public forms.",
    request: z.object({
      kind: z.enum(["contact", "support"]).default("contact"),
      name: z.string().min(2),
      email: z.string().email(),
      subject: z.string().default(""),
      body: z.string().min(3),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await db.insert(schema.messages).values({
        kind: args.kind,
        name: args.name,
        email: args.email,
        subject: args.subject,
        body: args.body,
      });
      await notify(db, "New message", `${args.subject || args.kind} from ${args.name}`, null);
      await log(db, "message.submit", args.email);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  submitReview: defineAction({
    description:
      "Stores a customer review as pending; it becomes public only after admin approval.",
    request: z.object({
      customer_name: z.string().min(2),
      service_slug: z.string().default(""),
      rating: z.number().min(1).max(5),
      body: z.string().min(3),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await db.insert(schema.reviews).values({
        customerName: args.customer_name,
        serviceSlug: args.service_slug,
        rating: args.rating,
        body: args.body,
        approved: 0,
      });
      await log(db, "review.submit", args.customer_name);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  getPortal: defineAction({
    description:
      "Returns one customer's own bookings, quotation requests, quotations, invoices and notifications. Accounts that have claimed a password require a valid customer session token; legacy passwordless accounts are still looked up by email.",
    request: z.object({
      email: z.string().email(),
      token: z.string().default(""),
    }),
    response: z.object({
      found: z.boolean(),
      requires_login: z.boolean(),
      customer: z
        .object({
          name: z.string(),
          email: z.string(),
          phone: z.string(),
          address: z.string(),
          language: z.string(),
          currency: z.string(),
        })
        .nullable(),
      bookings: z.array(bookingRow),
      quote_requests: z.array(quoteRequestRow),
      quotations: z.array(quotationRow),
      invoices: z.array(invoiceRow),
      notifications: z.array(
        z.object({
          id: z.number(),
          title: z.string(),
          body: z.string(),
          created_at: z.string(),
        }),
      ),
      offers: z.array(offerRow),
    }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const email = args.email.toLowerCase();
      const cust = await db
        .select()
        .from(schema.customers)
        .where(eq(schema.customers.email, email))
        .limit(1);
      /* A claimed account (password set) only releases its records to a
         valid customer session for the same email. */
      if (cust[0]?.passwordHash) {
        const okSess = await hasCustomerSession(db, args.token, email);
        if (!okSess) {
          return {
            found: false,
            requires_login: true,
            customer: null,
            bookings: [],
            quote_requests: [],
            quotations: [],
            invoices: [],
            notifications: [],
            offers: [],
          };
        }
      }
      const bookings = await db
        .select()
        .from(schema.bookings)
        .where(eq(schema.bookings.customerEmail, email))
        .orderBy(desc(schema.bookings.id));
      const qrs = await db
        .select()
        .from(schema.quoteRequests)
        .where(eq(schema.quoteRequests.customerEmail, email))
        .orderBy(desc(schema.quoteRequests.id));
      const qs = await db
        .select()
        .from(schema.quotations)
        .where(eq(schema.quotations.customerEmail, email))
        .orderBy(desc(schema.quotations.id));
      const invs = await db
        .select()
        .from(schema.invoices)
        .where(eq(schema.invoices.customerEmail, email))
        .orderBy(desc(schema.invoices.id));
      const notifs = await db
        .select()
        .from(schema.notifications)
        .where(eq(schema.notifications.email, email))
        .orderBy(desc(schema.notifications.id))
        .limit(30);
      const c = cust[0];
      return {
        found: !!c || bookings.length > 0 || qrs.length > 0,
        requires_login: false,
        customer: c
          ? {
              name: c.name,
              email: c.email,
              phone: c.phone,
              address: c.address,
              language: c.language,
              currency: c.currency,
            }
          : null,
        bookings: bookings.map(mapBooking),
        quote_requests: qrs.map(mapQr),
        quotations: qs
          .filter((q) => q.status !== "draft")
          .map(mapQ),
        invoices: invs.map(mapI),
        notifications: notifs.map((n) => ({
          id: n.id,
          title: n.title,
          body: n.body,
          created_at: n.createdAt.toISOString(),
        })),
        offers: await (async () => {
          /* Offers that apply to THIS customer only: live public
             offers, live offers for all registered clients, and live
             selected offers assigned to this exact email. Another
             client's selected offers are never included. */
          const today = todayStr();
          const rows = await db
            .select()
            .from(schema.offers)
            .orderBy(desc(schema.offers.id));
          const byOffer = await assignmentsByOffer(db);
          return rows
            .filter((o) => offerIsLive(o, today))
            .filter(
              (o) =>
                o.scope === "public" ||
                o.scope === "clients" ||
                (byOffer.get(o.id) ?? []).includes(email),
            )
            .map((o) => mapOffer(o, []));
        })(),
      };
    },
  }),

  updateCustomerProfile: defineAction({
    description:
      "Updates a customer's own profile details (name, phone, address, language, currency) identified by email.",
    request: z.object({
      email: z.string().email(),
      name: z.string().min(2),
      phone: z.string().default(""),
      address: z.string().default(""),
      language: z.string().default("it"),
      currency: z.string().default("EUR"),
      token: z.string().default(""),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const email = args.email.toLowerCase();
      const cust = await db
        .select()
        .from(schema.customers)
        .where(eq(schema.customers.email, email))
        .limit(1);
      if (cust[0]?.passwordHash) {
        const okSess = await hasCustomerSession(db, args.token, email);
        if (!okSess) throw new Error("UNAUTHORIZED");
      }
      await db
        .update(schema.customers)
        .set({
          name: args.name,
          phone: args.phone,
          address: args.address,
          language: args.language,
          currency: args.currency,
        })
        .where(eq(schema.customers.email, args.email.toLowerCase()));
      await log(db, "customer.update", args.email);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  respondQuotation: defineAction({
    description:
      "Lets a customer accept or reject a sent quotation addressed to their email.",
    request: z.object({
      id: z.number().int(),
      email: z.string().email(),
      accept: z.boolean(),
      token: z.string().default(""),
    }),
    response: z.object({ ok: z.boolean(), error: z.string() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const rows = await db
        .select()
        .from(schema.quotations)
        .where(eq(schema.quotations.id, args.id))
        .limit(1);
      const q = rows[0];
      if (!q) return { ok: false, error: "not_found" };
      if (q.customerEmail !== args.email.toLowerCase())
        return { ok: false, error: "not_yours" };
      /* Claimed accounts must be signed in to accept/reject. */
      const cust = await db
        .select()
        .from(schema.customers)
        .where(eq(schema.customers.email, q.customerEmail))
        .limit(1);
      if (cust[0]?.passwordHash) {
        const okSess = await hasCustomerSession(
          db,
          args.token,
          q.customerEmail,
        );
        if (!okSess) return { ok: false, error: "login_required" };
      }
      if (q.status !== "sent") return { ok: false, error: "not_sent" };
      await db
        .update(schema.quotations)
        .set({ status: args.accept ? "accepted" : "rejected" })
        .where(eq(schema.quotations.id, args.id));
      await notify(
        db,
        `Quotation ${args.accept ? "accepted" : "rejected"}`,
        `${q.ref} by ${q.customerName}`,
        null,
      );
      await log(db, "quotation.respond", q.ref);
      ctx.invalidateQueries();
      return { ok: true, error: "" };
    },
  }),

  staffAuthStatus: defineAction({
    description:
      "Reports whether the back office still needs its one-time first-admin setup (true only while no staff account exists), plus the owner-authorized administrator email that the one-time setup accepts.",
    request: z.object({}),
    response: z.object({
      setup_required: z.boolean(),
      authorized_email: z.string(),
    }),
    async handler(ctx) {
      const db = ctx.db<typeof schema>();
      const rows = await db.select().from(schema.staffUsers).limit(1);
      return {
        setup_required: rows.length === 0,
        authorized_email: AUTHORIZED_ADMIN_EMAIL,
      };
    },
  }),

  staffVerifySession: defineAction({
    description:
      "Verifies a staff session token with the server and returns the account's current name, email and role. The Admin Login page calls this before rendering any dashboard content: a token stored in the browser is never trusted on its own. Returns ok:false (without throwing) for an unknown, expired, revoked or non-staff token.",
    request: z.object({ token: z.string() }),
    response: z.object({
      ok: z.boolean(),
      name: z.string(),
      email: z.string(),
      role: z.string(),
      technician_id: z.number().nullable(),
    }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      try {
        const me = await requireStaff(db, args.token, [
          "admin",
          "manager",
          "technician",
        ]);
        return {
          ok: true,
          name: me.name,
          email: me.email,
          role: me.role,
          technician_id: me.technicianId,
        };
      } catch (e) {
        const msg = e instanceof Error ? e.message : "";
        if (msg === "UNAUTHORIZED" || msg === "FORBIDDEN")
          return {
            ok: false,
            name: "",
            email: "",
            role: "",
            technician_id: null,
          };
        throw e;
      }
    },
  }),

  staffBootstrap: defineAction({
    description:
      "One-time setup: creates the FIRST staff account (role admin) and returns a session. Refused once any staff account exists.",
    request: z.object({
      name: z.string().min(2),
      email: z.string().email(),
      password: z.string().min(10),
    }),
    response: authResponse,
    async handler(ctx, args): Promise<z.infer<typeof authResponse>> {
      const db = ctx.db<typeof schema>();
      const existing = await db.select().from(schema.staffUsers).limit(1);
      if (existing.length > 0) return authFail("setup_closed");
      const email = args.email.toLowerCase();
      /* The owner designated ONE authorized administrator email for
         this site (supplied by the owner, Report 23). The one-time
         setup accepts only that address, so a stranger who reaches
         the Admin Login page before the owner cannot claim the first
         admin account. Clients can never become admins: public
         registration only ever creates customer records. */
      if (email !== AUTHORIZED_ADMIN_EMAIL)
        return authFail("unauthorized_email");
      const [row] = await db
        .insert(schema.staffUsers)
        .values({
          name: args.name,
          email,
          passwordHash: await hashPassword(args.password),
          role: "admin",
          active: 1,
        })
        .returning();
      if (!row) return authFail("create_failed");
      const token = await createSession(db, "staff", email, row.id);
      await log(db, "staff.bootstrap", email);
      ctx.invalidateQueries();
      return {
        ok: true,
        error: "",
        token,
        name: row.name,
        role: row.role,
        technician_id: null,
      };
    },
  }),

  staffLogin: defineAction({
    description:
      "Staff sign-in for the private back office (dedicated Admin Login page — the back office has no URL route). Verifies the PBKDF2 password hash server-side and returns a session token plus the account's role.",
    request: z.object({
      email: z.string().email(),
      password: z.string().min(1),
    }),
    response: authResponse,
    async handler(ctx, args): Promise<z.infer<typeof authResponse>> {
      const db = ctx.db<typeof schema>();
      const email = args.email.toLowerCase();
      const rows = await db
        .select()
        .from(schema.staffUsers)
        .where(eq(schema.staffUsers.email, email))
        .limit(1);
      const u = rows[0];
      if (!u || u.active !== 1) return authFail("invalid_credentials");
      const okPw = await verifyPassword(args.password, u.passwordHash);
      if (!okPw) return authFail("invalid_credentials");
      const token = await createSession(db, "staff", email, u.id);
      await log(db, "staff.login", `${email} (${u.role})`);
      return {
        ok: true,
        error: "",
        token,
        name: u.name,
        role: u.role,
        technician_id: u.technicianId,
      };
    },
  }),

  staffLogout: defineAction({
    description: "Ends a staff session (deletes the stored session hash).",
    request: z.object({ token: z.string() }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const tokenHash = await sha256Hex(args.token);
      await db
        .delete(schema.sessions)
        .where(eq(schema.sessions.tokenHash, tokenHash));
      return { ok: true };
    },
  }),

  staffChangePassword: defineAction({
    description:
      "Staff self-service password change: any signed-in staff member (admin, manager or technician) verifies their current password and sets a new one (min. 10). All OTHER sessions of that account are ended; the current session stays valid.",
    request: z.object({
      token: z.string().min(1),
      current_password: z.string().min(1),
      new_password: z.string().min(10),
    }),
    response: z.object({ ok: z.boolean(), error: z.string() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const me = await requireStaff(db, args.token, [
        "admin",
        "manager",
        "technician",
      ]);
      const okPw = await verifyPassword(args.current_password, me.passwordHash);
      if (!okPw) return { ok: false, error: "invalid_current_password" };
      await db
        .update(schema.staffUsers)
        .set({ passwordHash: await hashPassword(args.new_password) })
        .where(eq(schema.staffUsers.id, me.id));
      /* End every other session of this staff account; keep the one
         making the change so the user is not signed out mid-task. */
      const myHash = await sha256Hex(args.token);
      const mine = await db
        .select()
        .from(schema.sessions)
        .where(eq(schema.sessions.staffId, me.id));
      for (const s of mine) {
        if (s.tokenHash !== myHash)
          await db
            .delete(schema.sessions)
            .where(eq(schema.sessions.tokenHash, s.tokenHash));
      }
      await log(db, "staff.change_password", me.email);
      ctx.invalidateQueries();
      return { ok: true, error: "" };
    },
  }),

  customerRegister: defineAction({
    description:
      "Creates a customer account with a password, or claims an existing passwordless customer record (created by a booking/quote) by setting its first password. Returns a customer session.",
    request: z.object({
      name: z.string().min(2),
      email: z.string().email(),
      password: z.string().min(8),
      phone: z.string().default(""),
      language: z.string().default("it"),
      currency: z.string().default("EUR"),
    }),
    response: authResponse,
    async handler(ctx, args): Promise<z.infer<typeof authResponse>> {
      const db = ctx.db<typeof schema>();
      const email = args.email.toLowerCase();
      const rows = await db
        .select()
        .from(schema.customers)
        .where(eq(schema.customers.email, email))
        .limit(1);
      const existing = rows[0];
      const passwordHash = await hashPassword(args.password);
      if (existing) {
        if (existing.passwordHash) return authFail("account_exists");
        await db
          .update(schema.customers)
          .set({
            passwordHash,
            name: args.name || existing.name,
            phone: args.phone || existing.phone,
          })
          .where(eq(schema.customers.id, existing.id));
      } else {
        await db.insert(schema.customers).values({
          name: args.name,
          email,
          phone: args.phone,
          language: args.language,
          currency: args.currency,
          passwordHash,
        });
      }
      const token = await createSession(db, "customer", email, null);
      await log(db, "customer.register", email);
      ctx.invalidateQueries();
      return {
        ok: true,
        error: "",
        token,
        name: args.name,
        role: "customer",
        technician_id: null,
      };
    },
  }),

  customerLogin: defineAction({
    description:
      "Customer sign-in for the Client Portal. Only works for accounts that have claimed a password; verifies the PBKDF2 hash server-side and returns a session token.",
    request: z.object({
      email: z.string().email(),
      password: z.string().min(1),
    }),
    response: authResponse,
    async handler(ctx, args): Promise<z.infer<typeof authResponse>> {
      const db = ctx.db<typeof schema>();
      const email = args.email.toLowerCase();
      const rows = await db
        .select()
        .from(schema.customers)
        .where(eq(schema.customers.email, email))
        .limit(1);
      const c = rows[0];
      if (!c) return authFail("invalid_credentials");
      if (!c.passwordHash) return authFail("no_password_set");
      const okPw = await verifyPassword(args.password, c.passwordHash);
      if (!okPw) return authFail("invalid_credentials");
      const token = await createSession(db, "customer", email, null);
      await log(db, "customer.login", email);
      return {
        ok: true,
        error: "",
        token,
        name: c.name,
        role: "customer",
        technician_id: null,
      };
    },
  }),

  customerLogout: defineAction({
    description: "Ends a customer session (deletes the stored session hash).",
    request: z.object({ token: z.string() }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const tokenHash = await sha256Hex(args.token);
      await db
        .delete(schema.sessions)
        .where(eq(schema.sessions.tokenHash, tokenHash));
      return { ok: true };
    },
  }),

  customerRequestReset: defineAction({
    description:
      "Password-reset request: the platform has no mail channel, so the request is delivered to the back office as an admin notification; an admin sets a temporary password (Admin → Customers) and contacts the customer. Always answers ok so it cannot be used to probe which emails have accounts.",
    request: z.object({ email: z.string().email() }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const email = args.email.toLowerCase();
      const rows = await db
        .select()
        .from(schema.customers)
        .where(eq(schema.customers.email, email))
        .limit(1);
      if (rows[0]?.passwordHash) {
        await notify(
          db,
          "Password reset requested",
          `${email} asked for a password reset. Set a temporary password in Admin → Customers and contact the customer.`,
          null,
        );
        await log(db, "customer.reset_request", email);
      }
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  customerChangePassword: defineAction({
    description:
      "Changes the signed-in customer's password after verifying the current one against the stored hash.",
    request: z.object({
      token: z.string().min(1),
      current_password: z.string().min(1),
      new_password: z.string().min(8),
    }),
    response: z.object({ ok: z.boolean(), error: z.string() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const s = await getSession(db, args.token);
      if (!s || s.kind !== "customer")
        return { ok: false, error: "unauthorized" };
      const rows = await db
        .select()
        .from(schema.customers)
        .where(eq(schema.customers.email, s.email))
        .limit(1);
      const c = rows[0];
      if (!c?.passwordHash) return { ok: false, error: "no_password_set" };
      const okPw = await verifyPassword(
        args.current_password,
        c.passwordHash,
      );
      if (!okPw) return { ok: false, error: "wrong_current_password" };
      await db
        .update(schema.customers)
        .set({ passwordHash: await hashPassword(args.new_password) })
        .where(eq(schema.customers.id, c.id));
      await log(db, "customer.password_change", s.email);
      return { ok: true, error: "" };
    },
  }),

  adminGetAll: defineAction({
    description:
      "Returns the back-office dataset for the signed-in staff account: admins see everything including settings and staff accounts, managers see operations without settings/staff accounts, technicians see only their own assigned jobs. Requires a valid staff session token.",
    request: z.object({ token: z.string().min(1) }),
    response: z.object({
      bookings: z.array(bookingRow),
      quote_requests: z.array(quoteRequestRow),
      quotations: z.array(quotationRow),
      invoices: z.array(invoiceRow),
      customers: z.array(
        z.object({
          id: z.number(),
          name: z.string(),
          email: z.string(),
          phone: z.string(),
          address: z.string(),
          language: z.string(),
          currency: z.string(),
          has_password: z.boolean(),
          created_at: z.string(),
        }),
      ),
      technicians: z.array(techRow),
      areas: z.array(areaRow),
      services: z.array(serviceRow),
      projects: z.array(
        z.object({
          id: z.number(),
          title: z.string(),
          category: z.string(),
          location: z.string(),
          description: z.string(),
          is_demo: z.boolean(),
        }),
      ),
      reviews: z.array(
        z.object({
          id: z.number(),
          customer_name: z.string(),
          service_slug: z.string(),
          rating: z.number(),
          body: z.string(),
          approved: z.boolean(),
          created_at: z.string(),
        }),
      ),
      messages: z.array(
        z.object({
          id: z.number(),
          kind: z.string(),
          name: z.string(),
          email: z.string(),
          subject: z.string(),
          body: z.string(),
          created_at: z.string(),
        }),
      ),
      notifications: z.array(
        z.object({
          id: z.number(),
          title: z.string(),
          body: z.string(),
          email: z.string().nullable(),
          is_read: z.boolean(),
          created_at: z.string(),
        }),
      ),
      activity: z.array(
        z.object({
          id: z.number(),
          action: z.string(),
          detail: z.string(),
          created_at: z.string(),
        }),
      ),
      staff_users: z.array(
        z.object({
          id: z.number(),
          name: z.string(),
          email: z.string(),
          role: z.string(),
          technician_id: z.number().nullable(),
          active: z.boolean(),
          created_at: z.string(),
        }),
      ),
      settings: z.record(z.string(), z.string()),
      stats: z.object({
        total_bookings: z.number(),
        new_requests: z.number(),
        pending_quotations: z.number(),
        confirmed: z.number(),
        completed: z.number(),
        customers: z.number(),
        revenue_cents: z.number(),
        outstanding_cents: z.number(),
      }),
      offers: z.array(offerRow),
    }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const me = await requireStaff(db, args.token, [
        "admin",
        "manager",
        "technician",
      ]);
      const bookings = await db
        .select()
        .from(schema.bookings)
        .orderBy(desc(schema.bookings.id));
      const qrs = await db
        .select()
        .from(schema.quoteRequests)
        .orderBy(desc(schema.quoteRequests.id));
      const qs = await db
        .select()
        .from(schema.quotations)
        .orderBy(desc(schema.quotations.id));
      const invs = await db
        .select()
        .from(schema.invoices)
        .orderBy(desc(schema.invoices.id));
      const customers = await db
        .select()
        .from(schema.customers)
        .orderBy(desc(schema.customers.id));
      const techs = await db.select().from(schema.technicians);
      const areas = await db.select().from(schema.serviceAreas);
      const services = await db
        .select()
        .from(schema.services)
        .orderBy(asc(schema.services.sort));
      const projects = await db
        .select()
        .from(schema.projects)
        .orderBy(desc(schema.projects.id));
      const reviews = await db
        .select()
        .from(schema.reviews)
        .orderBy(desc(schema.reviews.id));
      const messages = await db
        .select()
        .from(schema.messages)
        .orderBy(desc(schema.messages.id));
      const notifs = await db
        .select()
        .from(schema.notifications)
        .orderBy(desc(schema.notifications.id))
        .limit(60);
      const activity = await db
        .select()
        .from(schema.activityLog)
        .orderBy(desc(schema.activityLog.id))
        .limit(80);
      /* Server-side role scoping: a technician session only ever
         receives its own assigned jobs — never customer lists, finance,
         messages or settings. Managers receive the operations data but
         not site settings or staff accounts. */
      const isTech = me.role === "technician";
      const vBookings = isTech
        ? bookings.filter((b) => b.technicianId === me.technicianId)
        : bookings;
      const vQrs = isTech ? [] : qrs;
      const vQs = isTech ? [] : qs;
      const vInvs = isTech ? [] : invs;
      const vCustomers = isTech ? [] : customers;
      const vProjects = isTech ? [] : projects;
      const vReviews = isTech ? [] : reviews;
      const vMessages = isTech ? [] : messages;
      const vNotifs = isTech ? [] : notifs;
      const vActivity = isTech ? [] : activity;
      const staffRows =
        me.role === "admin"
          ? await db
              .select()
              .from(schema.staffUsers)
              .orderBy(asc(schema.staffUsers.id))
          : [];
      const revenue = vInvs
        .filter((i) => i.status === "paid")
        .reduce((s, i) => s + i.amountCents, 0);
      const outstanding = vInvs
        .filter((i) => i.status === "unpaid" || i.status === "overdue")
        .reduce((s, i) => s + i.amountCents, 0);
      return {
        bookings: vBookings.map(mapBooking),
        quote_requests: vQrs.map(mapQr),
        quotations: vQs.map(mapQ),
        invoices: vInvs.map(mapI),
        customers: vCustomers.map((c) => ({
          id: c.id,
          name: c.name,
          email: c.email,
          phone: c.phone,
          address: c.address,
          language: c.language,
          currency: c.currency,
          has_password: c.passwordHash !== "",
          created_at: c.createdAt.toISOString(),
        })),
        technicians: techs.map((t) => ({
          id: t.id,
          name: t.name,
          email: t.email,
          phone: t.phone,
          specialty: t.specialty,
          role: t.role,
          active: t.active === 1,
        })),
        areas: areas.map((a) => ({
          id: a.id,
          country: a.country,
          region: a.region,
          city: a.city,
          postal_codes: a.postalCodes,
          electrical: a.electrical === 1,
          plumbing: a.plumbing === 1,
          emergency: a.emergency === 1,
          active: a.active === 1,
          surcharge_cents: a.surchargeCents,
        })),
        services: services.map((s) => ({
          slug: s.slug,
          category: s.category,
          name_it: s.nameIt,
          name_en: s.nameEn,
          sort: s.sort,
          published: s.published === 1,
          base_price_cents: s.basePriceCents,
        })),
        projects: vProjects.map((p) => ({
          id: p.id,
          title: p.title,
          category: p.category,
          location: p.location,
          description: p.description,
          is_demo: p.isDemo === 1,
        })),
        reviews: vReviews.map((r) => ({
          id: r.id,
          customer_name: r.customerName,
          service_slug: r.serviceSlug,
          rating: r.rating,
          body: r.body,
          approved: r.approved === 1,
          created_at: r.createdAt.toISOString(),
        })),
        messages: vMessages.map((m) => ({
          id: m.id,
          kind: m.kind,
          name: m.name,
          email: m.email,
          subject: m.subject,
          body: m.body,
          created_at: m.createdAt.toISOString(),
        })),
        notifications: vNotifs.map((n) => ({
          id: n.id,
          title: n.title,
          body: n.body,
          email: n.email,
          is_read: n.isRead === 1,
          created_at: n.createdAt.toISOString(),
        })),
        activity: vActivity.map((a) => ({
          id: a.id,
          action: a.action,
          detail: a.detail,
          created_at: a.createdAt.toISOString(),
        })),
        staff_users: staffRows.map((u) => ({
          id: u.id,
          name: u.name,
          email: u.email,
          role: u.role,
          technician_id: u.technicianId,
          active: u.active === 1,
          created_at: u.createdAt.toISOString(),
        })),
        settings: me.role === "admin" ? await settingsMap(db) : {},
        stats: {
          total_bookings: vBookings.length,
          new_requests: vBookings.filter((b) => b.status === "new").length,
          pending_quotations: vQrs.filter(
            (q) => q.status === "new" || q.status === "reviewing",
          ).length,
          confirmed: vBookings.filter((b) => b.status === "confirmed")
            .length,
          completed: vBookings.filter((b) => b.status === "completed")
            .length,
          customers: vCustomers.length,
          revenue_cents: revenue,
          outstanding_cents: outstanding,
        },
        offers: isTech
          ? []
          : await (async () => {
              const rows = await db
                .select()
                .from(schema.offers)
                .orderBy(desc(schema.offers.id));
              const byOffer = await assignmentsByOffer(db);
              return rows.map((o) =>
                mapOffer(o, byOffer.get(o.id) ?? []),
              );
            })(),
      };
    },
  }),

  adminUpdateBooking: defineAction({
    description:
      "Staff: updates a booking's status, assigned technician, schedule, internal notes or work notes. Requires a staff session; technicians may only update their own assigned jobs and only status + work notes (enforced server-side).",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int(),
      status: z
        .enum([
          "new",
          "pending",
          "confirmed",
          "assigned",
          "in_progress",
          "completed",
          "cancelled",
        ])
        .optional(),
      technician_id: z.number().int().nullable().optional(),
      date: z.string().optional(),
      slot: z.string().optional(),
      internal_notes: z.string().optional(),
      work_notes: z.string().optional(),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const me = await requireStaff(db, args.token, [
        "admin",
        "manager",
        "technician",
      ]);
      const patch: Partial<typeof schema.bookings.$inferInsert> = {};
      if (me.role === "technician") {
        /* Technicians: own jobs only, status + work notes only. */
        const own = await db
          .select()
          .from(schema.bookings)
          .where(eq(schema.bookings.id, args.id))
          .limit(1);
        if (!own[0] || own[0].technicianId !== me.technicianId)
          throw new Error("FORBIDDEN");
        if (args.status !== undefined) patch.status = args.status;
        if (args.work_notes !== undefined) patch.workNotes = args.work_notes;
      } else {
        if (args.status !== undefined) patch.status = args.status;
        if (args.technician_id !== undefined)
          patch.technicianId = args.technician_id;
        if (args.date !== undefined) patch.date = args.date;
        if (args.slot !== undefined) patch.slot = args.slot;
        if (args.internal_notes !== undefined)
          patch.internalNotes = args.internal_notes;
        if (args.work_notes !== undefined) patch.workNotes = args.work_notes;
      }
      await db
        .update(schema.bookings)
        .set(patch)
        .where(eq(schema.bookings.id, args.id));
      const rows = await db
        .select()
        .from(schema.bookings)
        .where(eq(schema.bookings.id, args.id))
        .limit(1);
      const b = rows[0];
      if (b) {
        await notify(
          db,
          "Booking update",
          `${b.ref} is now ${b.status}${b.date ? ` · ${b.date} ${b.slot}` : ""}`,
          b.customerEmail,
        );
        await log(db, "booking.update", `${b.ref} -> ${b.status}`);
      }
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminUpdateQuoteRequest: defineAction({
    description:
      "Admin/manager: changes a quotation request's status. Requires a staff session.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int(),
      status: z.enum(["new", "reviewing", "quoted", "closed"]),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin", "manager"]);
      await db
        .update(schema.quoteRequests)
        .set({ status: args.status })
        .where(eq(schema.quoteRequests.id, args.id));
      await log(db, "quote_request.update", `#${args.id} -> ${args.status}`);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminCreateQuotation: defineAction({
    description:
      "Admin: creates a priced quotation with labour, materials, service charges, discount, currency and expiry; optionally marks it sent to the customer.",
    request: z.object({
      token: z.string().min(1),
      quote_request_id: z.number().int().nullable().default(null),
      customer_name: z.string().min(2),
      customer_email: z.string().email(),
      title: z.string().min(3),
      labour_cents: z.number().int().min(0).default(0),
      materials_cents: z.number().int().min(0).default(0),
      service_cents: z.number().int().min(0).default(0),
      discount_cents: z.number().int().min(0).default(0),
      currency: z.string().default("EUR"),
      expiry_date: z.string().default(""),
      send: z.boolean().default(false),
    }),
    response: z.object({ ok: z.boolean(), ref: z.string() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin", "manager"]);
      const r = ref("QT");
      await db.insert(schema.quotations).values({
        ref: r,
        quoteRequestId: args.quote_request_id,
        customerName: args.customer_name,
        customerEmail: args.customer_email.toLowerCase(),
        title: args.title,
        labourCents: args.labour_cents,
        materialsCents: args.materials_cents,
        serviceCents: args.service_cents,
        discountCents: args.discount_cents,
        currency: args.currency,
        expiryDate: args.expiry_date,
        status: args.send ? "sent" : "draft",
      });
      if (args.quote_request_id) {
        await db
          .update(schema.quoteRequests)
          .set({ status: "quoted" })
          .where(eq(schema.quoteRequests.id, args.quote_request_id));
      }
      if (args.send) {
        await notify(
          db,
          "Your quotation is ready",
          `${r} · ${args.title}`,
          args.customer_email.toLowerCase(),
        );
      }
      await log(db, "quotation.create", r);
      ctx.invalidateQueries();
      return { ok: true, ref: r };
    },
  }),

  adminUpdateQuotation: defineAction({
    description:
      "Admin/manager: changes a quotation's status (draft/sent/expired). Requires a staff session.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int(),
      status: z.enum(["draft", "sent", "accepted", "rejected", "expired"]),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin", "manager"]);
      await db
        .update(schema.quotations)
        .set({ status: args.status })
        .where(eq(schema.quotations.id, args.id));
      await log(db, "quotation.update", `#${args.id} -> ${args.status}`);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminCreateInvoice: defineAction({
    description:
      "Admin: creates an invoice, optionally from an accepted quotation, in any supported currency.",
    request: z.object({
      token: z.string().min(1),
      quotation_id: z.number().int().nullable().default(null),
      customer_name: z.string().min(2),
      customer_email: z.string().email(),
      amount_cents: z.number().int().min(0),
      currency: z.string().default("EUR"),
      due_date: z.string().default(""),
    }),
    response: z.object({ ok: z.boolean(), ref: z.string() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      const r = ref("INV");
      await db.insert(schema.invoices).values({
        ref: r,
        quotationId: args.quotation_id,
        customerName: args.customer_name,
        customerEmail: args.customer_email.toLowerCase(),
        amountCents: args.amount_cents,
        currency: args.currency,
        dueDate: args.due_date,
        status: "unpaid",
      });
      await notify(
        db,
        "New invoice",
        `${r} · ${args.currency} ${(args.amount_cents / 100).toFixed(2)}`,
        args.customer_email.toLowerCase(),
      );
      await log(db, "invoice.create", r);
      ctx.invalidateQueries();
      return { ok: true, ref: r };
    },
  }),

  adminUpdateInvoice: defineAction({
    description:
      "Admin: changes an invoice's payment status. Requires an admin session.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int(),
      status: z.enum(["unpaid", "paid", "overdue", "void"]),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      await db
        .update(schema.invoices)
        .set({ status: args.status })
        .where(eq(schema.invoices.id, args.id));
      await log(db, "invoice.update", `#${args.id} -> ${args.status}`);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminUpsertTechnician: defineAction({
    description:
      "Admin: creates or updates a manager or technician (name, contact, specialty, role, active flag).",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int().nullable().default(null),
      name: z.string().min(2),
      email: z.string().default(""),
      phone: z.string().default(""),
      specialty: z.enum(["electrical", "plumbing", "both"]).default("both"),
      role: z.enum(["manager", "technician"]).default("technician"),
      active: z.boolean().default(true),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      const values = {
        name: args.name,
        email: args.email,
        phone: args.phone,
        specialty: args.specialty,
        role: args.role,
        active: args.active ? 1 : 0,
      };
      if (args.id) {
        await db
          .update(schema.technicians)
          .set(values)
          .where(eq(schema.technicians.id, args.id));
      } else {
        await db.insert(schema.technicians).values(values);
      }
      await log(db, "technician.upsert", args.name);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminDeleteTechnician: defineAction({
    description:
      "Admin: removes a technician or manager record. Requires an admin session.",
    request: z.object({ token: z.string().min(1), id: z.number().int() }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      await db
        .delete(schema.technicians)
        .where(eq(schema.technicians.id, args.id));
      await log(db, "technician.delete", `#${args.id}`);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminUpsertArea: defineAction({
    description:
      "Admin: creates or updates a service area (country, region, city, postal codes, trades covered, emergency coverage, surcharge, active flag). Inactive areas are never shown publicly.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int().nullable().default(null),
      country: z.string().min(2),
      region: z.string().default(""),
      city: z.string().min(2),
      postal_codes: z.string().default(""),
      electrical: z.boolean().default(true),
      plumbing: z.boolean().default(true),
      emergency: z.boolean().default(false),
      active: z.boolean().default(true),
      surcharge_cents: z.number().int().min(0).default(0),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const values = {
        country: args.country,
        region: args.region,
        city: args.city,
        postalCodes: args.postal_codes,
        electrical: args.electrical ? 1 : 0,
        plumbing: args.plumbing ? 1 : 0,
        emergency: args.emergency ? 1 : 0,
        active: args.active ? 1 : 0,
        surchargeCents: args.surcharge_cents,
      };
      await requireStaff(db, args.token, ["admin"]);
      if (args.id) {
        await db
          .update(schema.serviceAreas)
          .set(values)
          .where(eq(schema.serviceAreas.id, args.id));
      } else {
        await db.insert(schema.serviceAreas).values(values);
      }
      await log(db, "area.upsert", `${args.city}, ${args.country}`);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminDeleteArea: defineAction({
    description: "Admin: removes a service area. Requires an admin session.",
    request: z.object({ token: z.string().min(1), id: z.number().int() }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      await db
        .delete(schema.serviceAreas)
        .where(eq(schema.serviceAreas.id, args.id));
      await log(db, "area.delete", `#${args.id}`);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminUpdateService: defineAction({
    description:
      "Admin: publishes/unpublishes a catalogue service or sets its indicative starting price.",
    request: z.object({
      token: z.string().min(1),
      slug: z.string(),
      published: z.boolean().optional(),
      base_price_cents: z.number().int().nullable().optional(),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      const patch: Partial<typeof schema.services.$inferInsert> = {};
      if (args.published !== undefined) patch.published = args.published ? 1 : 0;
      if (args.base_price_cents !== undefined)
        patch.basePriceCents = args.base_price_cents;
      await db
        .update(schema.services)
        .set(patch)
        .where(eq(schema.services.slug, args.slug));
      await log(db, "service.update", args.slug);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminUpsertService: defineAction({
    description:
      "Admin: creates a new catalogue service (unique slug, Italian + English names, category, starting price, published flag, sort position) or renames/recategorises an existing one. Requires an admin session.",
    request: z.object({
      token: z.string().min(1),
      slug: z
        .string()
        .min(3)
        .max(80)
        .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "slug must be kebab-case"),
      name_it: z.string().min(3),
      name_en: z.string().min(3),
      category: z.enum(["electrical", "plumbing"]),
      base_price_cents: z.number().int().min(0).nullable().default(null),
      published: z.boolean().default(true),
    }),
    response: z.object({ ok: z.boolean(), created: z.boolean() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      const existing = await db
        .select()
        .from(schema.services)
        .where(eq(schema.services.slug, args.slug))
        .limit(1);
      if (existing[0]) {
        await db
          .update(schema.services)
          .set({
            nameIt: args.name_it,
            nameEn: args.name_en,
            category: args.category,
            basePriceCents: args.base_price_cents,
            published: args.published ? 1 : 0,
          })
          .where(eq(schema.services.slug, args.slug));
        await log(db, "service.upsert", `${args.slug} (updated)`);
        ctx.invalidateQueries();
        return { ok: true, created: false };
      }
      const all = await db.select().from(schema.services);
      const sort = all.reduce((m, s) => Math.max(m, s.sort), -1) + 1;
      await db.insert(schema.services).values({
        slug: args.slug,
        category: args.category,
        nameIt: args.name_it,
        nameEn: args.name_en,
        sort,
        published: args.published ? 1 : 0,
        basePriceCents: args.base_price_cents,
      });
      await log(db, "service.upsert", `${args.slug} (created)`);
      ctx.invalidateQueries();
      return { ok: true, created: true };
    },
  }),

  adminDeleteService: defineAction({
    description:
      "Admin: permanently deletes a catalogue service by slug. Existing bookings keep their stored service slug and history. Requires an admin session; the UI asks for confirmation first.",
    request: z.object({
      token: z.string().min(1),
      slug: z.string().min(1),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      await db
        .delete(schema.services)
        .where(eq(schema.services.slug, args.slug));
      await log(db, "service.delete", args.slug);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminUpsertProject: defineAction({
    description:
      "Admin: adds or updates a portfolio project; entries are labelled demo until marked as a real completed project.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int().nullable().default(null),
      title: z.string().min(3),
      category: z.string().default("electrical"),
      location: z.string().default(""),
      description: z.string().default(""),
      is_demo: z.boolean().default(true),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const values = {
        title: args.title,
        category: args.category,
        location: args.location,
        description: args.description,
        isDemo: args.is_demo ? 1 : 0,
      };
      await requireStaff(db, args.token, ["admin"]);
      if (args.id) {
        await db
          .update(schema.projects)
          .set(values)
          .where(eq(schema.projects.id, args.id));
      } else {
        await db.insert(schema.projects).values(values);
      }
      await log(db, "project.upsert", args.title);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminDeleteProject: defineAction({
    description:
      "Admin: removes a portfolio project. Requires an admin session.",
    request: z.object({ token: z.string().min(1), id: z.number().int() }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      await db.delete(schema.projects).where(eq(schema.projects.id, args.id));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminModerateReview: defineAction({
    description:
      "Admin: approves or unpublishes a customer review. Requires an admin session.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int(),
      approved: z.boolean(),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      await db
        .update(schema.reviews)
        .set({ approved: args.approved ? 1 : 0 })
        .where(eq(schema.reviews.id, args.id));
      await log(db, "review.moderate", `#${args.id}`);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminSaveSettings: defineAction({
    description:
      "Admin: saves site settings — contact details, emergency availability, default theme/language/currency, hero video URL and About copy.",
    request: z.object({
      token: z.string().min(1),
      settings: z.record(z.string(), z.string()),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      for (const [key, value] of Object.entries(args.settings)) {
        await db
          .insert(schema.settings)
          .values({ key, value })
          .onConflictDoUpdate({
            target: schema.settings.key,
            set: { value },
          });
      }
      await log(db, "settings.save", Object.keys(args.settings).join(","));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminMarkNotificationsRead: defineAction({
    description:
      "Admin/manager: marks all admin notifications as read. Requires a staff session.",
    request: z.object({ token: z.string().min(1) }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin", "manager"]);
      await db
        .update(schema.notifications)
        .set({ isRead: 1 })
        .where(eq(schema.notifications.isRead, 0));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminUpsertStaffUser: defineAction({
    description:
      "Admin: creates or updates a staff login account (name, email, role, linked technician, active flag, optional new password). Guards: cannot demote/deactivate yourself or the last active admin; email must be unique.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int().nullable().default(null),
      name: z.string().min(2),
      email: z.string().email(),
      password: z.string().default(""),
      role: z.enum(["admin", "manager", "technician"]),
      technician_id: z.number().int().nullable().default(null),
      active: z.boolean().default(true),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const me = await requireStaff(db, args.token, ["admin"]);
      const email = args.email.toLowerCase();
      const clash = await db
        .select()
        .from(schema.staffUsers)
        .where(eq(schema.staffUsers.email, email))
        .limit(1);
      if (clash[0] && clash[0].id !== args.id)
        throw new Error("EMAIL_TAKEN");
      if (args.id === me.id && (args.role !== "admin" || !args.active))
        throw new Error("CANNOT_CHANGE_OWN_ROLE");
      if (args.id) {
        const target = await db
          .select()
          .from(schema.staffUsers)
          .where(eq(schema.staffUsers.id, args.id))
          .limit(1);
        const t = target[0];
        if (!t) throw new Error("NOT_FOUND");
        if (
          t.role === "admin" &&
          t.active === 1 &&
          (args.role !== "admin" || !args.active)
        ) {
          const admins = await db
            .select()
            .from(schema.staffUsers)
            .where(
              and(
                eq(schema.staffUsers.role, "admin"),
                eq(schema.staffUsers.active, 1),
              ),
            );
          if (admins.length <= 1) throw new Error("LAST_ADMIN");
        }
        const patch: Partial<typeof schema.staffUsers.$inferInsert> = {
          name: args.name,
          email,
          role: args.role,
          technicianId: args.technician_id,
          active: args.active ? 1 : 0,
        };
        if (args.password) {
          if (args.password.length < 10)
            throw new Error("PASSWORD_TOO_SHORT");
          patch.passwordHash = await hashPassword(args.password);
        }
        await db
          .update(schema.staffUsers)
          .set(patch)
          .where(eq(schema.staffUsers.id, args.id));
      } else {
        if (args.password.length < 10)
          throw new Error("PASSWORD_TOO_SHORT");
        await db.insert(schema.staffUsers).values({
          name: args.name,
          email,
          passwordHash: await hashPassword(args.password),
          role: args.role,
          technicianId: args.technician_id,
          active: args.active ? 1 : 0,
        });
      }
      await log(db, "staff.upsert", `${email} (${args.role})`);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminDeleteStaffUser: defineAction({
    description:
      "Admin: deletes a staff login account. Guards: cannot delete your own account or the last active admin. Also ends that account's sessions.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int(),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      const me = await requireStaff(db, args.token, ["admin"]);
      if (args.id === me.id) throw new Error("CANNOT_DELETE_SELF");
      const target = await db
        .select()
        .from(schema.staffUsers)
        .where(eq(schema.staffUsers.id, args.id))
        .limit(1);
      const t = target[0];
      if (!t) throw new Error("NOT_FOUND");
      if (t.role === "admin" && t.active === 1) {
        const admins = await db
          .select()
          .from(schema.staffUsers)
          .where(
            and(
              eq(schema.staffUsers.role, "admin"),
              eq(schema.staffUsers.active, 1),
            ),
          );
        if (admins.length <= 1) throw new Error("LAST_ADMIN");
      }
      await db
        .delete(schema.sessions)
        .where(eq(schema.sessions.staffId, args.id));
      await db
        .delete(schema.staffUsers)
        .where(eq(schema.staffUsers.id, args.id));
      await log(db, "staff.delete", t.email);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminSetCustomerPassword: defineAction({
    description:
      "Admin: sets (or replaces) a customer's portal password — used for password-reset requests, since the platform has no mail channel. Ends the customer's existing sessions so the temporary password takes effect cleanly.",
    request: z.object({
      token: z.string().min(1),
      email: z.string().email(),
      password: z.string().min(8),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      const email = args.email.toLowerCase();
      const rows = await db
        .select()
        .from(schema.customers)
        .where(eq(schema.customers.email, email))
        .limit(1);
      if (!rows[0]) throw new Error("NOT_FOUND");
      await db
        .update(schema.customers)
        .set({ passwordHash: await hashPassword(args.password) })
        .where(eq(schema.customers.id, rows[0].id));
      await db
        .delete(schema.sessions)
        .where(
          and(
            eq(schema.sessions.kind, "customer"),
            eq(schema.sessions.email, email),
          ),
        );
      await log(db, "customer.password_set_by_admin", email);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  adminUpsertOffer: defineAction({
    description:
      "Admin: creates or edits a reusable promotional offer (percent or fixed-amount discount, validity window, public / all-clients / selected-clients audience). Selected-client assignments are replaced with the supplied list. When a non-public offer is live, the targeted customers receive a portal notification. Admin role only, enforced server-side.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int().nullable().default(null),
      title: z.string().min(2).max(120),
      description: z.string().max(500).default(""),
      discount_type: z.enum(["percent", "amount"]),
      discount_value: z.number().int().min(0).max(100000000),
      scope: z.enum(["public", "clients", "selected"]),
      service_slug: z.string().max(80).default(""),
      active: z.boolean().default(true),
      starts_at: z.string().max(10).default(""),
      expires_at: z.string().max(10).default(""),
      assigned_emails: z.array(z.string().email()).max(500).default([]),
    }),
    response: z.object({ ok: z.literal(true), id: z.number() }),
    async handler(
      ctx,
      args,
    ): Promise<{ ok: true; id: number }> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      if (
        args.discount_type === "percent" &&
        (args.discount_value < 1 || args.discount_value > 100)
      )
        throw new Error("INVALID_PERCENT");
      const dateOk = (s: string) =>
        s === "" || /^\d{4}-\d{2}-\d{2}$/.test(s);
      if (!dateOk(args.starts_at) || !dateOk(args.expires_at))
        throw new Error("INVALID_DATE");
      if (
        args.starts_at &&
        args.expires_at &&
        args.expires_at < args.starts_at
      )
        throw new Error("INVALID_WINDOW");
      const emails = [
        ...new Set(args.assigned_emails.map((e) => e.toLowerCase())),
      ];
      if (args.scope === "selected" && emails.length === 0)
        throw new Error("NO_RECIPIENTS");
      const values = {
        title: args.title.trim(),
        description: args.description.trim(),
        discountType: args.discount_type,
        discountValue: args.discount_value,
        scope: args.scope,
        serviceSlug: args.service_slug.trim(),
        active: args.active ? 1 : 0,
        startsAt: args.starts_at,
        expiresAt: args.expires_at,
      };
      let offerId: number;
      if (args.id != null) {
        const existing = await db
          .select()
          .from(schema.offers)
          .where(eq(schema.offers.id, args.id))
          .limit(1);
        if (!existing[0]) throw new Error("NOT_FOUND");
        await db
          .update(schema.offers)
          .set(values)
          .where(eq(schema.offers.id, args.id));
        offerId = args.id;
      } else {
        const [row] = await db
          .insert(schema.offers)
          .values(values)
          .returning();
        if (!row) throw new Error("CREATE_FAILED");
        offerId = row.id;
      }
      /* Replace the assignment set together with the offer write. */
      await db
        .delete(schema.offerAssignments)
        .where(eq(schema.offerAssignments.offerId, offerId));
      if (args.scope === "selected") {
        for (const em of emails) {
          await db
            .insert(schema.offerAssignments)
            .values({ offerId, customerEmail: em });
        }
      }
      /* Portal notifications for targeted offers (the notification
         channel the Client Portal already renders). Public offers are
         visible to everyone and are not pushed as notifications. */
      const live = offerIsLive(
        { ...values, id: offerId, createdAt: new Date() },
        todayStr(),
      );
      if (live && args.scope !== "public") {
        const targets =
          args.scope === "selected"
            ? emails
            : (await db.select().from(schema.customers)).map((c) => c.email);
        const discount =
          args.discount_type === "percent"
            ? `${args.discount_value}%`
            : `${(args.discount_value / 100).toFixed(2)}`;
        for (const em of targets) {
          await notify(
            db,
            `🎁 ${values.title}`,
            `${values.description} (−${discount}${values.expiresAt ? `, valid until ${values.expiresAt}` : ""})`.trim(),
            em,
          );
        }
      }
      await log(
        db,
        "offer.upsert",
        `${values.title} (${values.scope}, ${args.id != null ? "edit" : "new"})`,
      );
      ctx.invalidateQueries();
      return { ok: true as const, id: offerId };
    },
  }),

  adminDeleteOffer: defineAction({
    description:
      "Admin: permanently deletes a promotional offer and its client assignments. Deactivation (keeping the record) is done by editing the offer's active flag instead. Admin role only.",
    request: z.object({
      token: z.string().min(1),
      id: z.number().int(),
    }),
    response: okResponse,
    async handler(ctx, args): Promise<z.infer<typeof okResponse>> {
      const db = ctx.db<typeof schema>();
      await requireStaff(db, args.token, ["admin"]);
      const rows = await db
        .select()
        .from(schema.offers)
        .where(eq(schema.offers.id, args.id))
        .limit(1);
      if (!rows[0]) throw new Error("NOT_FOUND");
      await db
        .delete(schema.offerAssignments)
        .where(eq(schema.offerAssignments.offerId, args.id));
      await db
        .delete(schema.offers)
        .where(eq(schema.offers.id, args.id));
      await log(db, "offer.delete", rows[0].title);
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),
} satisfies ActionsModule;
