import { integer, real, sqliteTable, text } from "drizzle-orm/sqlite-core";

const ts = () =>
  integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .$defaultFn(() => new Date());

export const services = sqliteTable("services", {
  slug: text("slug").primaryKey(),
  category: text("category", { enum: ["electrical", "plumbing"] }).notNull(),
  nameIt: text("name_it").notNull(),
  nameEn: text("name_en").notNull(),
  sort: integer("sort").notNull().default(0),
  published: integer("published").notNull().default(1),
  basePriceCents: integer("base_price_cents"),
});

export const customers = sqliteTable("customers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull().default(""),
  address: text("address").notNull().default(""),
  language: text("language").notNull().default("it"),
  currency: text("currency").notNull().default("EUR"),
  /* PBKDF2 password hash ("pbkdf2$iterations$salt$hash"); empty string =
     legacy account created by a booking/quote, not yet claimed. Once
     set, the portal requires a real login for that email. */
  passwordHash: text("password_hash").notNull().default(""),
  createdAt: ts(),
});

/* Staff login accounts for the private back office. Separate from the
   technicians roster: a staff user has a role (admin / manager /
   technician) and may be linked to a technician record, which is what
   scopes a technician login to their own assigned jobs. Passwords are
   PBKDF2 hashes; there is no default or seeded account — the first
   admin is created through the one-time setup flow. */
export const staffUsers = sqliteTable("staff_users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role", { enum: ["admin", "manager", "technician"] })
    .notNull()
    .default("technician"),
  technicianId: integer("technician_id"),
  active: integer("active").notNull().default(1),
  createdAt: ts(),
});

/* Login sessions for staff and customers. Only the SHA-256 hash of the
   bearer token is stored; the raw token exists only in the client's
   local storage. expires_at is a Unix-ms instant. */
export const sessions = sqliteTable("sessions", {
  tokenHash: text("token_hash").primaryKey(),
  kind: text("kind", { enum: ["staff", "customer"] }).notNull(),
  email: text("email").notNull(),
  staffId: integer("staff_id"),
  expiresAt: integer("expires_at").notNull(),
  createdAt: ts(),
});

export const technicians = sqliteTable("technicians", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  email: text("email").notNull().default(""),
  phone: text("phone").notNull().default(""),
  specialty: text("specialty", {
    enum: ["electrical", "plumbing", "both"],
  })
    .notNull()
    .default("both"),
  role: text("role", { enum: ["manager", "technician"] })
    .notNull()
    .default("technician"),
  active: integer("active").notNull().default(1),
  createdAt: ts(),
});

export const bookings = sqliteTable("bookings", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ref: text("ref").notNull().unique(),
  serviceSlug: text("service_slug").notNull(),
  category: text("category", { enum: ["electrical", "plumbing"] }).notNull(),
  propertyType: text("property_type").notNull().default("residential"),
  description: text("description").notNull().default(""),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone").notNull().default(""),
  address: text("address").notNull().default(""),
  city: text("city").notNull().default(""),
  postalCode: text("postal_code").notNull().default(""),
  date: text("date").notNull().default(""),
  slot: text("slot").notNull().default(""),
  language: text("language").notNull().default("it"),
  isEmergency: integer("is_emergency").notNull().default(0),
  status: text("status", {
    enum: [
      "new",
      "pending",
      "confirmed",
      "assigned",
      "in_progress",
      "completed",
      "cancelled",
    ],
  })
    .notNull()
    .default("new"),
  technicianId: integer("technician_id"),
  internalNotes: text("internal_notes").notNull().default(""),
  workNotes: text("work_notes").notNull().default(""),
  photoName: text("photo_name").notNull().default(""),
  createdAt: ts(),
});

export const quoteRequests = sqliteTable("quote_requests", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ref: text("ref").notNull().unique(),
  serviceSlug: text("service_slug").notNull(),
  description: text("description").notNull().default(""),
  propertyType: text("property_type").notNull().default("residential"),
  measurements: text("measurements").notNull().default(""),
  address: text("address").notNull().default(""),
  city: text("city").notNull().default(""),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone").notNull().default(""),
  language: text("language").notNull().default("it"),
  status: text("status", {
    enum: ["new", "reviewing", "quoted", "closed"],
  })
    .notNull()
    .default("new"),
  photoName: text("photo_name").notNull().default(""),
  createdAt: ts(),
});

export const quotations = sqliteTable("quotations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ref: text("ref").notNull().unique(),
  quoteRequestId: integer("quote_request_id"),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  title: text("title").notNull(),
  labourCents: integer("labour_cents").notNull().default(0),
  materialsCents: integer("materials_cents").notNull().default(0),
  serviceCents: integer("service_cents").notNull().default(0),
  discountCents: integer("discount_cents").notNull().default(0),
  currency: text("currency").notNull().default("EUR"),
  expiryDate: text("expiry_date").notNull().default(""),
  status: text("status", {
    enum: ["draft", "sent", "accepted", "rejected", "expired"],
  })
    .notNull()
    .default("draft"),
  createdAt: ts(),
});

export const invoices = sqliteTable("invoices", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  ref: text("ref").notNull().unique(),
  quotationId: integer("quotation_id"),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  amountCents: integer("amount_cents").notNull().default(0),
  currency: text("currency").notNull().default("EUR"),
  status: text("status", { enum: ["unpaid", "paid", "overdue", "void"] })
    .notNull()
    .default("unpaid"),
  dueDate: text("due_date").notNull().default(""),
  createdAt: ts(),
});

export const serviceAreas = sqliteTable("service_areas", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  country: text("country").notNull(),
  region: text("region").notNull().default(""),
  city: text("city").notNull(),
  postalCodes: text("postal_codes").notNull().default(""),
  electrical: integer("electrical").notNull().default(1),
  plumbing: integer("plumbing").notNull().default(1),
  emergency: integer("emergency").notNull().default(0),
  active: integer("active").notNull().default(1),
  surchargeCents: integer("surcharge_cents").notNull().default(0),
  createdAt: ts(),
});

export const projects = sqliteTable("projects", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  category: text("category").notNull().default("electrical"),
  location: text("location").notNull().default(""),
  description: text("description").notNull().default(""),
  isDemo: integer("is_demo").notNull().default(1),
  createdAt: ts(),
});

export const reviews = sqliteTable("reviews", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerName: text("customer_name").notNull(),
  serviceSlug: text("service_slug").notNull().default(""),
  rating: real("rating").notNull().default(5),
  body: text("body").notNull().default(""),
  approved: integer("approved").notNull().default(0),
  createdAt: ts(),
});

export const messages = sqliteTable("messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  kind: text("kind", { enum: ["contact", "support"] })
    .notNull()
    .default("contact"),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull().default(""),
  body: text("body").notNull(),
  createdAt: ts(),
});

export const notifications = sqliteTable("notifications", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  email: text("email"),
  isRead: integer("is_read").notNull().default(0),
  createdAt: ts(),
});

export const settings = sqliteTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
});

/* Reusable promotional offers (Report 22). Deliberately separate from
   quotations.discount_cents, which is a one-off discount on a single
   quote — an offer is a reusable promotion with a validity window and
   an audience: "public" (all visitors), "clients" (all registered
   clients) or "selected" (only the customers listed in
   offer_assignments). discount_type "percent" stores a whole percent
   in discount_value; "amount" stores cents in the site default
   currency. starts_at / expires_at are plain YYYY-MM-DD dates; an
   empty expires_at means no expiry. */
export const offers = sqliteTable("offers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  discountType: text("discount_type", { enum: ["percent", "amount"] })
    .notNull()
    .default("percent"),
  discountValue: integer("discount_value").notNull().default(0),
  scope: text("scope", { enum: ["public", "clients", "selected"] })
    .notNull()
    .default("public"),
  serviceSlug: text("service_slug").notNull().default(""),
  active: integer("active").notNull().default(1),
  startsAt: text("starts_at").notNull().default(""),
  expiresAt: text("expires_at").notNull().default(""),
  createdAt: ts(),
});

export const offerAssignments = sqliteTable("offer_assignments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  offerId: integer("offer_id").notNull(),
  customerEmail: text("customer_email").notNull(),
});

export const activityLog = sqliteTable("activity_log", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  action: text("action").notNull(),
  detail: text("detail").notNull().default(""),
  createdAt: ts(),
});
