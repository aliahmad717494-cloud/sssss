/* Full translations for the cinematic / scrollytelling sections.
   Every supported language has its own complete copy — no Italian fallback. */
export type ScrollyCopy = {
  filmKicker: string; filmTitle: string; filmSub: string; filmAria: string;
  bookThisWork: string; keepScrolling: string;
  storyAria: string; sceneWord: string;
  scenes: { title: string; body: string }[];
  seqLabels: string[];
  journeyKicker: string; journeyTitle: string; journeySub: string; journeyAria: string;
  journey: { title: string; body: string }[];
  journeyCtaTitle: string; journeyCtaBody: string; journeyCtaBtn: string;
  threeKicker: string; threeTitle: string; threeBody: string; threeAria: string; threeImgAlt: string; scrollToRotate: string;
  reducedTitle: string; reducedJourneyAria: string; videoAria: string;
  electrical: string; plumbing: string; electricalServices: string; plumbingServices: string; bookService: string;
};

const it: ScrollyCopy = {
  filmKicker: "Lo scroll è la riproduzione", filmTitle: "Il nostro lavoro, fotogramma dopo fotogramma",
  filmSub: "Scorri in basso e il film avanza. Scorri in alto e si riavvolge. Nessun pulsante play: la telecamera la muovi tu.",
  filmAria: "Film a scorrimento controllato: S SERVICES al lavoro", bookThisWork: "Prenota questo intervento", keepScrolling: "Continua a scorrere",
  storyAria: "Storia cinematografica: dal quadro alla caldaia", sceneWord: "Scena",
  scenes: [
    { title: "Dal quadro elettrico nasce tutto", body: "Installiamo quadri con magnetotermici e differenziali moderni, circuiti etichettati e protezioni dimensionate sui carichi reali. Scorri: la telecamera entra nell'impianto." },
    { title: "Diagnostica strumentale", body: "Dispersioni, cortocircuiti intermittenti, differenziali che scattano: li troviamo con strumentazione professionale, senza tentativi a vuoto." },
    { title: "Perdite trovate senza demolire", body: "Correlatori, geofoni e termocamere individuano il punto esatto della perdita. La riparazione è mirata, il danno resta minimo." },
    { title: "Tubazioni a regola d'arte", body: "Tubi danneggiati, corrosi o scoppiati: riparazione o sostituzione con materiali certificati, pendenze corrette e prova di tenuta documentata." },
    { title: "Caldaia efficiente, casa calda", body: "Installazione e manutenzione caldaie, analisi dei fumi e bilanciamento dell'impianto: comfort uniforme e consumi sotto controllo, in ogni stagione." },
  ],
  seqLabels: ["Quadro elettrico","Verifica impianto","Fotovoltaico","Wallbox EV","Ricerca perdite","Tubazioni","Bagno e cucina","Caldaie"],
  journeyKicker: "Un'unica squadra, dall'inizio alla fine", journeyTitle: "Il lavoro, in movimento laterale",
  journeySub: "Lo scroll verticale muove questa galleria in orizzontale: dal primo sopralluogo all'impianto di riscaldamento finito.", journeyAria: "Il percorso di lavoro S SERVICES",
  journey: [
    { title: "1 · Sopralluogo e diagnosi", body: "Analisi strumentale dell'impianto e diagnosi chiara prima di qualsiasi intervento." },
    { title: "2 · Quadro e cablaggio", body: "Quadri, linee e protezioni nuovi o ricablati a norma, con circuiti etichettati." },
    { title: "3 · Fotovoltaico", body: "Pannelli dimensionati sul tuo consumo, pratiche di connessione e monitoraggio da app." },
    { title: "4 · Wallbox EV", body: "Ricarica domestica e aziendale con gestione dei carichi e protezioni dedicate." },
    { title: "5 · Bagno e cucina", body: "Impianti idraulici completi, sanitari e rubinetteria con finiture impeccabili." },
    { title: "6 · Caldaie e riscaldamento", body: "Caldaie, radiatori e pavimento radiante bilanciati per comfort e risparmio." },
  ],
  journeyCtaTitle: "Pronti quando vuoi", journeyCtaBody: "Prenota un sopralluogo o richiedi un preventivo trasparente: un tecnico esamina personalmente ogni richiesta.", journeyCtaBtn: "Prenota un Intervento →",
  threeKicker: "3D · Three.js", threeTitle: "Due mestieri, una rotazione",
  threeBody: "Tubazioni in rame e acciaio, una valvola di intercettazione e un fulmine: il modello ruota in sincronia diretta con il tuo scroll. Giù per girarlo avanti, su per riavvolgerlo.",
  threeAria: "3D interattivo: tubi e fulmine", threeImgAlt: "Modello 3D di tubi idraulici e fulmine elettrico, ruotato dallo scroll", scrollToRotate: "scorri per ruotare",
  reducedTitle: "Il nostro lavoro, scena dopo scena", reducedJourneyAria: "Percorso di lavoro", videoAria: "S SERVICES al lavoro",
  electrical: "Elettrico", plumbing: "Idraulica", electricalServices: "Servizi elettrici", plumbingServices: "Servizi idraulici", bookService: "Prenota un Intervento",
};

const en: ScrollyCopy = {
  filmKicker: "Scroll = playhead", filmTitle: "Our work, frame by frame",
  filmSub: "Scroll down and the film advances. Scroll up and it rewinds. No play button — you control the camera.",
  filmAria: "Scroll-controlled film: S SERVICES at work", bookThisWork: "Book this work", keepScrolling: "Keep scrolling",
  storyAria: "Cinematic story: from panel to boiler", sceneWord: "Scene",
  scenes: [
    { title: "It all starts at the panel", body: "We install panels with modern breakers and RCDs, labelled circuits and protections sized for real loads. Keep scrolling: the camera moves into the installation." },
    { title: "Instrument diagnostics", body: "Leakage currents, intermittent short circuits, tripping RCDs: we find them with professional instruments, not guesswork." },
    { title: "Leaks found without demolition", body: "Correlators, geophones and thermal cameras pinpoint the exact leak. The repair is targeted and the damage stays minimal." },
    { title: "Pipework done properly", body: "Damaged, corroded or burst pipes: repaired or replaced with certified materials, correct falls and a documented pressure test." },
    { title: "An efficient boiler, a warm home", body: "Boiler installation and maintenance, flue-gas analysis and system balancing: even comfort and controlled consumption, in every season." },
  ],
  seqLabels: ["Electrical panel","System inspection","Solar power","EV wallbox","Leak detection","Pipework","Bathroom & kitchen","Boilers"],
  journeyKicker: "One team, start to finish", journeyTitle: "The job, moving sideways",
  journeySub: "Vertical scroll drives this gallery horizontally — from the first survey to the finished heating system.", journeyAria: "The S SERVICES work journey",
  journey: [
    { title: "1 · Survey & diagnosis", body: "Instrument survey of the system and a clear diagnosis before any work begins." },
    { title: "2 · Panel & wiring", body: "New or rewired panels, lines and protections up to standard, with labelled circuits." },
    { title: "3 · Solar", body: "Panels sized to your consumption, grid paperwork and app monitoring." },
    { title: "4 · EV wallbox", body: "Home and company charging with load management and dedicated protections." },
    { title: "5 · Bathroom & kitchen", body: "Complete plumbing, sanitaryware and taps with flawless finishes." },
    { title: "6 · Boilers & heating", body: "Boilers, radiators and underfloor heating balanced for comfort and savings." },
  ],
  journeyCtaTitle: "Ready when you are", journeyCtaBody: "Book a visit or request a transparent quotation — a technician reviews every request personally.", journeyCtaBtn: "Book a Service →",
  threeKicker: "3D · Three.js", threeTitle: "Two trades, one rotation",
  threeBody: "Copper and steel pipework, a shut-off valve and a lightning bolt — the model rotates in direct sync with your scroll. Down to turn it forward, up to spin it back.",
  threeAria: "Interactive 3D: pipes and lightning", threeImgAlt: "3D model of plumbing pipes and an electric lightning bolt, rotated by scrolling", scrollToRotate: "scroll to rotate",
  reducedTitle: "Our work, scene by scene", reducedJourneyAria: "Work journey", videoAria: "S SERVICES at work",
  electrical: "Electrical", plumbing: "Plumbing", electricalServices: "Electrical services", plumbingServices: "Plumbing services", bookService: "Book a Service",
};

const fr: ScrollyCopy = {
  filmKicker: "Le défilement = la lecture", filmTitle: "Notre travail, image par image",
  filmSub: "Faites défiler vers le bas et le film avance. Vers le haut, il recule. Aucun bouton lecture — c'est vous qui contrôlez la caméra.",
  filmAria: "Film contrôlé par le défilement : S SERVICES au travail", bookThisWork: "Réserver ce travail", keepScrolling: "Continuez à défiler",
  storyAria: "Récit cinématographique : du tableau à la chaudière", sceneWord: "Scène",
  scenes: [
    { title: "Tout commence au tableau électrique", body: "Nous installons des tableaux avec disjoncteurs et différentiels modernes, circuits étiquetés et protections dimensionnées pour les charges réelles. Continuez : la caméra entre dans l'installation." },
    { title: "Diagnostic par instruments", body: "Courants de fuite, courts-circuits intermittents, différentiels qui déclenchent : nous les trouvons avec des instruments professionnels, sans tâtonnements." },
    { title: "Fuites détectées sans démolition", body: "Corrélateurs, géophones et caméras thermiques localisent le point exact de la fuite. La réparation est ciblée, les dégâts minimes." },
    { title: "Tuyauterie dans les règles de l'art", body: "Tuyaux endommagés, corrodés ou éclatés : réparation ou remplacement avec matériaux certifiés, pentes correctes et test d'étanchéité documenté." },
    { title: "Chaudière efficace, maison chaude", body: "Installation et entretien de chaudières, analyse des fumées et équilibrage : confort homogène et consommation maîtrisée, en toute saison." },
  ],
  seqLabels: ["Panneau électrique","Inspection du système","Photovoltaïque","Borne VE","Détection de fuites","Tuyauterie","Salle de bain et cuisine","Chaudières"],
  journeyKicker: "Une seule équipe, du début à la fin", journeyTitle: "Le chantier, en mouvement latéral",
  journeySub: "Le défilement vertical fait glisser cette galerie horizontalement — du premier diagnostic au chauffage terminé.", journeyAria: "Le parcours de travail S SERVICES",
  journey: [
    { title: "1 · Visite et diagnostic", body: "Analyse instrumentale du système et diagnostic clair avant tout travaux." },
    { title: "2 · Tableau et câblage", body: "Tableaux, lignes et protections neufs ou recâblés aux normes, circuits étiquetés." },
    { title: "3 · Photovoltaïque", body: "Panneaux dimensionnés selon votre consommation, raccordement et suivi par application." },
    { title: "4 · Borne de recharge VE", body: "Recharge à domicile et en entreprise avec gestion de charge et protections dédiées." },
    { title: "5 · Salle de bain et cuisine", body: "Plomberie complète, sanitaires et robinetterie aux finitions impeccables." },
    { title: "6 · Chaudières et chauffage", body: "Chaudières, radiateurs et plancher chauffant équilibrés pour confort et économies." },
  ],
  journeyCtaTitle: "Prêts quand vous l'êtes", journeyCtaBody: "Réservez une visite ou demandez un devis transparent — un technicien examine chaque demande personnellement.", journeyCtaBtn: "Réserver une intervention →",
  threeKicker: "3D · Three.js", threeTitle: "Deux métiers, une rotation",
  threeBody: "Tuyauterie en cuivre et acier, vanne d'arrêt et éclair — le modèle tourne en synchronisation directe avec votre défilement. Vers le bas pour avancer, vers le haut pour revenir.",
  threeAria: "3D interactif : tuyaux et éclair", threeImgAlt: "Modèle 3D de tuyaux de plomberie et d'un éclair électrique, pivoté par le défilement", scrollToRotate: "défiler pour pivoter",
  reducedTitle: "Notre travail, scène par scène", reducedJourneyAria: "Parcours de travail", videoAria: "S SERVICES au travail",
  electrical: "Électricité", plumbing: "Plomberie", electricalServices: "Services électriques", plumbingServices: "Services de plomberie", bookService: "Réserver une intervention",
};

const de: ScrollyCopy = {
  filmKicker: "Scrollen = Wiedergabe", filmTitle: "Unsere Arbeit, Bild für Bild",
  filmSub: "Scrollen Sie nach unten, der Film läuft vorwärts. Nach oben spult er zurück. Kein Play-Button — Sie steuern die Kamera.",
  filmAria: "Scroll-gesteuerter Film: S SERVICES bei der Arbeit", bookThisWork: "Diese Arbeit buchen", keepScrolling: "Weiter scrollen",
  storyAria: "Filmgeschichte: vom Verteiler bis zum Kessel", sceneWord: "Szene",
  scenes: [
    { title: "Alles beginnt am Verteilerkasten", body: "Wir installieren Verteiler mit modernen Leitungsschutzschaltern und FI-Schaltern, beschrifteten Stromkreisen und auf reale Lasten ausgelegten Schutzorganen. Scrollen Sie weiter: Die Kamera fährt in die Anlage." },
    { title: "Messtechnische Diagnose", body: "Ableitströme, sporadische Kurzschlüsse, auslösende FI-Schalter: Wir finden sie mit Profi-Messtechnik — ganz ohne Rätselraten." },
    { title: "Lecks finden ohne Abriss", body: "Korrelatoren, Geophone und Wärmebildkameras orten das Leck exakt. Die Reparatur ist gezielt, der Schaden bleibt minimal." },
    { title: "Rohrleitungen fachgerecht verlegt", body: "Beschädigte, korrodierte oder geplatzte Rohre: Reparatur oder Austausch mit zertifizierten Materialien, korrektem Gefälle und dokumentierter Druckprüfung." },
    { title: "Effizienter Kessel, warmes Zuhause", body: "Kesselinstallation und -wartung, Abgasanalyse und hydraulischer Abgleich: gleichmässiger Komfort und kontrollierter Verbrauch, zu jeder Jahreszeit." },
  ],
  seqLabels: ["Verteilerkasten","Anlagenprüfung","Photovoltaik","EV-Wallbox","Leckortung","Rohrleitungen","Bad & Küche","Heizkessel"],
  journeyKicker: "Ein Team, von Anfang bis Ende", journeyTitle: "Die Baustelle, seitwärts in Bewegung",
  journeySub: "Vertikales Scrollen bewegt diese Galerie horizontal — von der ersten Bestandsaufnahme bis zur fertigen Heizungsanlage.", journeyAria: "Der Arbeitsablauf von S SERVICES",
  journey: [
    { title: "1 · Besichtigung & Diagnose", body: "Messtechnische Prüfung der Anlage und klare Diagnose vor Arbeitsbeginn." },
    { title: "2 · Verteiler & Verkabelung", body: "Neue oder normgerecht erneuerte Verteiler, Leitungen und Schutzorgane mit beschrifteten Kreisen." },
    { title: "3 · Photovoltaik", body: "Module passend zu Ihrem Verbrauch, Netzanschluss-Papierkram und App-Monitoring." },
    { title: "4 · EV-Wallbox", body: "Laden zu Hause und im Betrieb mit Lastmanagement und eigenen Schutzorganen." },
    { title: "5 · Bad & Küche", body: "Komplette Sanitärinstallation, Sanitärobjekte und Armaturen mit makelloser Verarbeitung." },
    { title: "6 · Kessel & Heizung", body: "Kessel, Heizkörper und Fussbodenheizung — abgeglichen für Komfort und Ersparnis." },
  ],
  journeyCtaTitle: "Bereit, wenn Sie es sind", journeyCtaBody: "Buchen Sie eine Besichtigung oder fordern Sie ein transparentes Angebot an — ein Techniker prüft jede Anfrage persönlich.", journeyCtaBtn: "Termin buchen →",
  threeKicker: "3D · Three.js", threeTitle: "Zwei Gewerke, eine Drehung",
  threeBody: "Kupfer- und Stahlrohre, ein Absperrventil und ein Blitz — das Modell dreht sich synchron zu Ihrem Scrollen. Runter für vorwärts, hoch für zurück.",
  threeAria: "Interaktives 3D: Rohre und Blitz", threeImgAlt: "3D-Modell aus Sanitärrohren und einem elektrischen Blitz, gedreht durch Scrollen", scrollToRotate: "scrollen zum Drehen",
  reducedTitle: "Unsere Arbeit, Szene für Szene", reducedJourneyAria: "Arbeitsablauf", videoAria: "S SERVICES bei der Arbeit",
  electrical: "Elektro", plumbing: "Sanitär", electricalServices: "Elektro-Leistungen", plumbingServices: "Sanitär-Leistungen", bookService: "Termin buchen",
};

const es: ScrollyCopy = {
  filmKicker: "Desplazar = reproducir", filmTitle: "Nuestro trabajo, fotograma a fotograma",
  filmSub: "Desplázate hacia abajo y la película avanza. Hacia arriba, retrocede. Sin botón de reproducción: tú controlas la cámara.",
  filmAria: "Película controlada por el desplazamiento: S SERVICES trabajando", bookThisWork: "Reservar este trabajo", keepScrolling: "Sigue desplazándote",
  storyAria: "Historia cinematográfica: del cuadro a la caldera", sceneWord: "Escena",
  scenes: [
    { title: "Todo empieza en el cuadro eléctrico", body: "Instalamos cuadros con magnetotérmicos y diferenciales modernos, circuitos etiquetados y protecciones dimensionadas para cargas reales. Sigue desplazándote: la cámara entra en la instalación." },
    { title: "Diagnóstico con instrumentos", body: "Corrientes de fuga, cortocircuitos intermitentes, diferenciales que saltan: los encontramos con instrumentos profesionales, sin adivinar." },
    { title: "Fugas localizadas sin demoler", body: "Correladores, geófonos y cámaras térmicas localizan el punto exacto de la fuga. La reparación es precisa y el daño mínimo." },
    { title: "Tuberías hechas como debe ser", body: "Tuberías dañadas, corroídas o reventadas: reparación o sustitución con materiales certificados, pendientes correctas y prueba de estanqueidad documentada." },
    { title: "Caldera eficiente, hogar cálido", body: "Instalación y mantenimiento de calderas, análisis de humos y equilibrado del sistema: confort uniforme y consumo controlado, en cada estación." },
  ],
  seqLabels: ["Cuadro eléctrico","Inspección del sistema","Energía solar","Wallbox VE","Detección de fugas","Tuberías","Baño y cocina","Calderas"],
  journeyKicker: "Un solo equipo, de principio a fin", journeyTitle: "El trabajo, en movimiento lateral",
  journeySub: "El desplazamiento vertical mueve esta galería en horizontal: desde la primera visita hasta el sistema de calefacción terminado.", journeyAria: "El proceso de trabajo de S SERVICES",
  journey: [
    { title: "1 · Visita y diagnóstico", body: "Revisión instrumental del sistema y diagnóstico claro antes de empezar." },
    { title: "2 · Cuadro y cableado", body: "Cuadros, líneas y protecciones nuevos o recableados según normativa, con circuitos etiquetados." },
    { title: "3 · Energía solar", body: "Paneles dimensionados según tu consumo, trámites de conexión y monitorización por app." },
    { title: "4 · Wallbox VE", body: "Carga en casa y en la empresa con gestión de cargas y protecciones dedicadas." },
    { title: "5 · Baño y cocina", body: "Fontanería completa, sanitarios y grifería con acabados impecables." },
    { title: "6 · Calderas y calefacción", body: "Calderas, radiadores y suelo radiante equilibrados para confort y ahorro." },
  ],
  journeyCtaTitle: "Listos cuando tú lo estés", journeyCtaBody: "Reserva una visita o pide un presupuesto transparente: un técnico revisa personalmente cada solicitud.", journeyCtaBtn: "Reservar un servicio →",
  threeKicker: "3D · Three.js", threeTitle: "Dos oficios, una rotación",
  threeBody: "Tuberías de cobre y acero, una válvula de cierre y un rayo: el modelo gira en sincronía directa con tu desplazamiento. Abajo para avanzar, arriba para retroceder.",
  threeAria: "3D interactivo: tuberías y rayo", threeImgAlt: "Modelo 3D de tuberías de fontanería y un rayo eléctrico, girado al desplazarse", scrollToRotate: "desplaza para girar",
  reducedTitle: "Nuestro trabajo, escena a escena", reducedJourneyAria: "Proceso de trabajo", videoAria: "S SERVICES trabajando",
  electrical: "Electricidad", plumbing: "Fontanería", electricalServices: "Servicios eléctricos", plumbingServices: "Servicios de fontanería", bookService: "Reservar un servicio",
};

const pt: ScrollyCopy = {
  filmKicker: "Deslocar = reproduzir", filmTitle: "O nosso trabalho, fotograma a fotograma",
  filmSub: "Desloque para baixo e o filme avança. Para cima, recua. Sem botão de reprodução — você controla a câmara.",
  filmAria: "Filme controlado pela deslocação: S SERVICES a trabalhar", bookThisWork: "Marcar este trabalho", keepScrolling: "Continue a deslocar",
  storyAria: "História cinematográfica: do quadro à caldeira", sceneWord: "Cena",
  scenes: [
    { title: "Tudo começa no quadro elétrico", body: "Instalamos quadros com disjuntores e diferenciais modernos, circuitos etiquetados e proteções dimensionadas para cargas reais. Continue a deslocar: a câmara entra na instalação." },
    { title: "Diagnóstico com instrumentos", body: "Correntes de fuga, curtos-circuitos intermitentes, diferenciais que disparam: encontramo-los com instrumentos profissionais, sem tentativas." },
    { title: "Fugas detetadas sem demolição", body: "Correlacionadores, geofones e câmaras térmicas localizam o ponto exato da fuga. A reparação é direcionada e o dano mínimo." },
    { title: "Canalização feita como deve ser", body: "Tubos danificados, corroídos ou rebentados: reparação ou substituição com materiais certificados, pendentes corretas e ensaio de estanqueidade documentado." },
    { title: "Caldeira eficiente, casa quente", body: "Instalação e manutenção de caldeiras, análise de fumos e equilíbrio do sistema: conforto uniforme e consumo controlado, em todas as estações." },
  ],
  seqLabels: ["Quadro elétrico","Inspeção do sistema","Energia solar","Wallbox VE","Deteção de fugas","Canalização","Casa de banho e cozinha","Caldeiras"],
  journeyKicker: "Uma só equipa, do início ao fim", journeyTitle: "O trabalho, em movimento lateral",
  journeySub: "A deslocação vertical move esta galeria na horizontal — da primeira visita ao sistema de aquecimento concluído.", journeyAria: "O percurso de trabalho da S SERVICES",
  journey: [
    { title: "1 · Visita e diagnóstico", body: "Levantamento instrumental do sistema e diagnóstico claro antes de qualquer trabalho." },
    { title: "2 · Quadro e cablagem", body: "Quadros, linhas e proteções novos ou recablados segundo as normas, com circuitos etiquetados." },
    { title: "3 · Energia solar", body: "Painéis dimensionados para o seu consumo, burocracia de ligação e monitorização por app." },
    { title: "4 · Wallbox VE", body: "Carregamento em casa e na empresa com gestão de cargas e proteções dedicadas." },
    { title: "5 · Casa de banho e cozinha", body: "Canalização completa, loiças sanitárias e torneiras com acabamentos impecáveis." },
    { title: "6 · Caldeiras e aquecimento", body: "Caldeiras, radiadores e piso radiante equilibrados para conforto e poupança." },
  ],
  journeyCtaTitle: "Prontos quando você estiver", journeyCtaBody: "Marque uma visita ou peça um orçamento transparente — um técnico analisa pessoalmente cada pedido.", journeyCtaBtn: "Marcar um serviço →",
  threeKicker: "3D · Three.js", threeTitle: "Dois ofícios, uma rotação",
  threeBody: "Tubos de cobre e aço, uma válvula de corte e um relâmpago — o modelo roda em sincronia direta com a sua deslocação. Para baixo avança, para cima recua.",
  threeAria: "3D interativo: tubos e relâmpago", threeImgAlt: "Modelo 3D de tubos de canalização e um relâmpago elétrico, rodado pela deslocação", scrollToRotate: "desloque para rodar",
  reducedTitle: "O nosso trabalho, cena a cena", reducedJourneyAria: "Percurso de trabalho", videoAria: "S SERVICES a trabalhar",
  electrical: "Eletricidade", plumbing: "Canalização", electricalServices: "Serviços elétricos", plumbingServices: "Serviços de canalização", bookService: "Marcar um serviço",
};

const nl: ScrollyCopy = {
  filmKicker: "Scrollen = afspelen", filmTitle: "Ons werk, beeld voor beeld",
  filmSub: "Scroll omlaag en de film speelt vooruit. Scroll omhoog en hij spoelt terug. Geen afspeelknop — u bedient de camera.",
  filmAria: "Scroll-gestuurde film: S SERVICES aan het werk", bookThisWork: "Boek dit werk", keepScrolling: "Blijf scrollen",
  storyAria: "Filmisch verhaal: van groepenkast tot ketel", sceneWord: "Scène",
  scenes: [
    { title: "Alles begint bij de groepenkast", body: "Wij installeren groepenkasten met moderne automaten en aardlekschakelaars, gelabelde groepen en beveiligingen op maat van de echte belasting. Scroll verder: de camera gaat de installatie in." },
    { title: "Diagnose met meetapparatuur", body: "Lekstromen, intermitterende kortsluitingen, trippende aardlekschakelaars: wij vinden ze met professionele meetapparatuur, zonder giswerk." },
    { title: "Lekken gevonden zonder sloopwerk", body: "Correlatoren, geofoons en warmtecamera's lokaliseren het lek exact. De reparatie is gericht en de schade blijft minimaal." },
    { title: "Leidingwerk volgens de regels", body: "Beschadigde, gecorrodeerde of gesprongen leidingen: hersteld of vervangen met gecertificeerde materialen, correct afschot en gedocumenteerde druktest." },
    { title: "Efficiënte ketel, warm huis", body: "Ketelinstallatie en -onderhoud, rookgasanalyse en waterzijdig inregelen: gelijkmatig comfort en beheerst verbruik, elk seizoen." },
  ],
  seqLabels: ["Groepenkast","Installatiecontrole","Zonne-energie","EV-wallbox","Lekdetectie","Leidingwerk","Badkamer & keuken","Ketels"],
  journeyKicker: "Eén team, van start tot finish", journeyTitle: "Het werk, zijwaarts in beweging",
  journeySub: "Verticaal scrollen beweegt deze galerij horizontaal — van de eerste opname tot het afgewerkte verwarmingssysteem.", journeyAria: "Het werktraject van S SERVICES",
  journey: [
    { title: "1 · Opname & diagnose", body: "Instrumentele opname van de installatie en een heldere diagnose vóór elk werk." },
    { title: "2 · Kast & bekabeling", body: "Nieuwe of volgens norm herbedrade kasten, leidingen en beveiligingen met gelabelde groepen." },
    { title: "3 · Zonne-energie", body: "Panelen op maat van uw verbruik, netaansluiting en monitoring via app." },
    { title: "4 · EV-wallbox", body: "Thuis en zakelijk laden met load balancing en eigen beveiligingen." },
    { title: "5 · Badkamer & keuken", body: "Compleet leidingwerk, sanitair en kranen met vlekkeloze afwerking." },
    { title: "6 · Ketels & verwarming", body: "Ketels, radiatoren en vloerverwarming ingeregeld voor comfort en besparing." },
  ],
  journeyCtaTitle: "Klaar wanneer u dat bent", journeyCtaBody: "Boek een bezoek of vraag een transparante offerte aan — een technicus beoordeelt elke aanvraag persoonlijk.", journeyCtaBtn: "Boek een dienst →",
  threeKicker: "3D · Three.js", threeTitle: "Twee vakken, één rotatie",
  threeBody: "Koperen en stalen leidingen, een afsluiter en een bliksemschicht — het model draait synchroon met uw scrollen. Omlaag vooruit, omhoog terug.",
  threeAria: "Interactieve 3D: leidingen en bliksem", threeImgAlt: "3D-model van loodgietersleidingen en een elektrische bliksem, gedraaid door scrollen", scrollToRotate: "scroll om te draaien",
  reducedTitle: "Ons werk, scène voor scène", reducedJourneyAria: "Werktraject", videoAria: "S SERVICES aan het werk",
  electrical: "Elektro", plumbing: "Loodgieter", electricalServices: "Elektrische diensten", plumbingServices: "Loodgietersdiensten", bookService: "Boek een dienst",
};

const tr: ScrollyCopy = {
  filmKicker: "Kaydırma = oynatma", filmTitle: "İşimiz, kare kare",
  filmSub: "Aşağı kaydırın, film ileri gider. Yukarı kaydırın, geri sarar. Oynat düğmesi yok — kamerayı siz kontrol ediyorsunuz.",
  filmAria: "Kaydırmayla kontrol edilen film: S SERVICES iş başında", bookThisWork: "Bu işi ayırtın", keepScrolling: "Kaydırmaya devam edin",
  storyAria: "Sinematik hikâye: panodan kazana", sceneWord: "Sahne",
  scenes: [
    { title: "Her şey elektrik panosunda başlar", body: "Modern sigortalar ve kaçak akım röleleriyle panolar kuruyoruz; etiketli devreler ve gerçek yüklere göre boyutlandırılmış korumalar. Kaydırmaya devam edin: kamera tesisatın içine giriyor." },
    { title: "Cihazla arıza teşhisi", body: "Kaçak akımlar, aralıklı kısa devreler, atan röleler: hepsini profesyonel cihazlarla buluyoruz, tahminle değil." },
    { title: "Kırmadan bulunan kaçaklar", body: "Korelatörler, jeofonlar ve termal kameralar kaçağın tam noktasını bulur. Onarım hedefe yöneliktir, hasar minimumda kalır." },
    { title: "Kuralına uygun boru tesisatı", body: "Hasarlı, paslanmış veya patlamış borular: sertifikalı malzemelerle onarım veya değişim, doğru eğimler ve belgeli basınç testi." },
    { title: "Verimli kazan, sıcak ev", body: "Kazan kurulumu ve bakımı, baca gazı analizi ve sistem dengelemesi: her mevsim eşit konfor ve kontrollü tüketim." },
  ],
  seqLabels: ["Elektrik panosu","Sistem kontrolü","Güneş enerjisi","EV wallbox","Kaçak tespiti","Boru tesisatı","Banyo ve mutfak","Kazanlar"],
  journeyKicker: "Tek ekip, baştan sona", journeyTitle: "İş, yana doğru hareket ediyor",
  journeySub: "Dikey kaydırma bu galeriyi yatay hareket ettirir — ilk keşiften bitmiş ısıtma sistemine.", journeyAria: "S SERVICES iş süreci",
  journey: [
    { title: "1 · Keşif ve teşhis", body: "Sistemin cihazla incelenmesi ve işe başlamadan önce net teşhis." },
    { title: "2 · Pano ve kablolama", body: "Standartlara uygun yeni veya yenilenmiş panolar, hatlar ve korumalar; etiketli devreler." },
    { title: "3 · Güneş enerjisi", body: "Tüketiminize göre boyutlandırılmış paneller, şebeke işlemleri ve uygulama takibi." },
    { title: "4 · EV wallbox", body: "Yük yönetimi ve özel korumalarla evde ve işte şarj." },
    { title: "5 · Banyo ve mutfak", body: "Eksiksiz tesisat, vitrifiye ve bataryalar; kusursuz işçilik." },
    { title: "6 · Kazanlar ve ısıtma", body: "Konfor ve tasarruf için dengelenmiş kazanlar, radyatörler ve yerden ısıtma." },
  ],
  journeyCtaTitle: "Siz hazır olduğunuzda hazırız", journeyCtaBody: "Keşif ayırtın veya şeffaf teklif isteyin — her talebi bir teknisyen bizzat inceler.", journeyCtaBtn: "Servis ayırtın →",
  threeKicker: "3D · Three.js", threeTitle: "İki meslek, tek dönüş",
  threeBody: "Bakır ve çelik borular, bir kesme vanası ve bir şimşek — model, kaydırmanızla doğrudan senkron döner. Aşağı ileri, yukarı geri.",
  threeAria: "Etkileşimli 3D: borular ve şimşek", threeImgAlt: "Kaydırmayla döndürülen tesisat boruları ve elektrik şimşeği 3D modeli", scrollToRotate: "döndürmek için kaydırın",
  reducedTitle: "İşimiz, sahne sahne", reducedJourneyAria: "İş süreci", videoAria: "S SERVICES iş başında",
  electrical: "Elektrik", plumbing: "Tesisat", electricalServices: "Elektrik hizmetleri", plumbingServices: "Tesisat hizmetleri", bookService: "Servis ayırtın",
};

const ar: ScrollyCopy = {
  filmKicker: "التمرير = التشغيل", filmTitle: "عملنا، إطارًا تلو إطار",
  filmSub: "مرّر للأسفل فيتقدم الفيلم. مرّر للأعلى فيعود للخلف. لا يوجد زر تشغيل — أنت تتحكم في الكاميرا.",
  filmAria: "فيلم يتحكم فيه التمرير: S SERVICES أثناء العمل", bookThisWork: "احجز هذا العمل", keepScrolling: "تابع التمرير",
  storyAria: "قصة سينمائية: من اللوحة إلى الغلاية", sceneWord: "مشهد",
  scenes: [
    { title: "كل شيء يبدأ من لوحة الكهرباء", body: "نركّب لوحات بقواطع ومفاتيح تفاضلية حديثة، ودوائر موسومة وحمايات مضبوطة على الأحمال الحقيقية. تابع التمرير: الكاميرا تدخل إلى التركيب." },
    { title: "تشخيص بالأجهزة", body: "تيارات التسرب والدوائر القصيرة المتقطعة والقواطع التي تفصل: نجدها بأجهزة احترافية، لا بالتخمين." },
    { title: "تسريبات تُكتشف دون هدم", body: "أجهزة الارتباط والجيوفونات والكاميرات الحرارية تحدد نقطة التسرب بدقة. الإصلاح موجّه والضرر يبقى في حده الأدنى." },
    { title: "تمديدات أنابيب متقنة", body: "أنابيب تالفة أو متآكلة أو منفجرة: إصلاح أو استبدال بمواد معتمدة، وميول صحيحة واختبار ضغط موثّق." },
    { title: "غلاية فعّالة ومنزل دافئ", body: "تركيب وصيانة الغلايات، وتحليل غازات الاحتراق وموازنة النظام: راحة متساوية واستهلاك مضبوط في كل فصل." },
  ],
  seqLabels: ["لوحة كهرباء","فحص النظام","طاقة شمسية","شاحن سيارة كهربائية","كشف التسريبات","الأنابيب","الحمام والمطبخ","الغلايات"],
  journeyKicker: "فريق واحد، من البداية إلى النهاية", journeyTitle: "العمل يتحرك جانبًا",
  journeySub: "التمرير العمودي يحرّك هذا المعرض أفقيًا — من المعاينة الأولى إلى نظام التدفئة المكتمل.", journeyAria: "مسار عمل S SERVICES",
  journey: [
    { title: "١ · معاينة وتشخيص", body: "فحص النظام بالأجهزة وتشخيص واضح قبل بدء أي عمل." },
    { title: "٢ · اللوحة والأسلاك", body: "لوحات وخطوط وحمايات جديدة أو معاد تمديدها وفق المعايير، ودوائر موسومة." },
    { title: "٣ · طاقة شمسية", body: "ألواح مضبوطة على استهلاكك، وإجراءات الربط بالشبكة ومراقبة عبر التطبيق." },
    { title: "٤ · شاحن سيارة كهربائية", body: "شحن منزلي وتجاري مع إدارة الأحمال وحمايات مخصصة." },
    { title: "٥ · الحمام والمطبخ", body: "سباكة متكاملة وأدوات صحية وحنفيات بتشطيبات لا تشوبها شائبة." },
    { title: "٦ · الغلايات والتدفئة", body: "غلايات ومشعّات وتدفئة أرضية متوازنة للراحة والتوفير." },
  ],
  journeyCtaTitle: "جاهزون متى ما كنت جاهزًا", journeyCtaBody: "احجز زيارة أو اطلب عرض سعر شفافًا — فني يراجع كل طلب شخصيًا.", journeyCtaBtn: "احجز خدمة ←",
  threeKicker: "ثلاثي الأبعاد · Three.js", threeTitle: "حرفتان، دوران واحد",
  threeBody: "أنابيب نحاسية وفولاذية وصمام إغلاق وبرق — النموذج يدور بتزامن مباشر مع تمريرك. للأسفل للأمام، وللأعلى للخلف.",
  threeAria: "ثلاثي أبعاد تفاعلي: أنابيب وبرق", threeImgAlt: "نموذج ثلاثي الأبعاد لأنابيب سباكة وبرق كهربائي، يُدار بالتمرير", scrollToRotate: "مرّر للتدوير",
  reducedTitle: "عملنا، مشهدًا تلو مشهد", reducedJourneyAria: "مسار العمل", videoAria: "S SERVICES أثناء العمل",
  electrical: "كهرباء", plumbing: "سباكة", electricalServices: "خدمات الكهرباء", plumbingServices: "خدمات السباكة", bookService: "احجز خدمة",
};

const ur: ScrollyCopy = {
  filmKicker: "اسکرول = پلے ہیڈ", filmTitle: "ہمارا کام، فریم بہ فریم",
  filmSub: "نیچے اسکرول کریں تو فلم آگے بڑھتی ہے۔ اوپر اسکرول کریں تو واپس جاتی ہے۔ کوئی پلے بٹن نہیں — کیمرا آپ کے کنٹرول میں ہے۔",
  filmAria: "اسکرول سے کنٹرول فلم: S SERVICES کام کرتے ہوئے", bookThisWork: "یہ کام بک کریں", keepScrolling: "اسکرول جاری رکھیں",
  storyAria: "سنیما کہانی: پینل سے بوائلر تک", sceneWord: "منظر",
  scenes: [
    { title: "سب کچھ پینل سے شروع ہوتا ہے", body: "ہم جدید بریکرز اور آر سی ڈیز کے ساتھ پینل لگاتے ہیں، لیبل شدہ سرکٹس اور اصل لوڈ کے مطابق حفاظتیں۔ اسکرول جاری رکھیں: کیمرا انسٹالیشن کے اندر جاتا ہے۔" },
    { title: "آلات سے تشخیص", body: "لیکج کرنٹس، وقفے وقفے سے شارٹ سرکٹس، ٹرپ ہوتے آر سی ڈیز: ہم انہیں پیشہ ورانہ آلات سے تلاش کرتے ہیں، اندازے سے نہیں۔" },
    { title: "بغیر توڑ پھوڑ کے لیک تلاش", body: "کوریلیٹرز، جیوفونز اور تھرمل کیمرے لیک کی اصل جگہ کی نشاندہی کرتے ہیں۔ مرمت ہدف پر ہوتی ہے اور نقصان کم سے کم رہتا ہے۔" },
    { title: "اصول کے مطابق پائپ ورک", body: "خراب، زنگ آلود یا پھٹے پائپ: مصدقہ مواد کے ساتھ مرمت یا تبدیلی، درست ڈھلوان اور دستاویزی پریشر ٹیسٹ۔" },
    { title: "موثر بوائلر، گرم گھر", body: "بوائلر انسٹالیشن اور مینٹیننس، فلو گیس تجزیہ اور سسٹم بیلنسنگ: ہر موسم میں یکساں آرام اور قابو میں کھپت۔" },
  ],
  seqLabels: ["بجلی کا پینل","سسٹم معائنہ","سولر پاور","ای وی وال باکس","لیک کی تلاش","پائپ ورک","باتھ روم اور کچن","بوائلرز"],
  journeyKicker: "ایک ٹیم، شروع سے آخر تک", journeyTitle: "کام، سائیڈ وے حرکت میں",
  journeySub: "عمودی اسکرول اس گیلری کو افقی حرکت دیتا ہے — پہلے سروے سے مکمل ہیٹنگ سسٹم تک۔", journeyAria: "S SERVICES کا ورک جرنی",
  journey: [
    { title: "۱ · سروے اور تشخیص", body: "سسٹم کا آلات سے سروے اور کوئی کام شروع ہونے سے پہلے واضح تشخیص۔" },
    { title: "۲ · پینل اور وائرنگ", body: "معیار کے مطابق نئے یا دوبارہ وائر شدہ پینل، لائنیں اور حفاظتیں، لیبل شدہ سرکٹس کے ساتھ۔" },
    { title: "۳ · سولر", body: "آپ کی کھپت کے مطابق پینل، گرڈ کاغذات اور ایپ مانیٹرنگ۔" },
    { title: "۴ · ای وی وال باکس", body: "لوڈ مینجمنٹ اور مخصوص حفاظتوں کے ساتھ گھر اور کمپنی چارجنگ۔" },
    { title: "۵ · باتھ روم اور کچن", body: "مکمل پلمبنگ، سینیٹری ویئر اور نلکے بے عیب فنش کے ساتھ۔" },
    { title: "۶ · بوائلر اور ہیٹنگ", body: "آرام اور بچت کے لیے متوازن بوائلر، ریڈی ایٹر اور انڈر فلور ہیٹنگ۔" },
  ],
  journeyCtaTitle: "جب آپ تیار ہوں، ہم تیار ہیں", journeyCtaBody: "وزٹ بک کریں یا شفاف کوٹیشن مانگیں — ایک ٹیکنیشن ہر درخواست کا خود جائزہ لیتا ہے۔", journeyCtaBtn: "سروس بک کریں ←",
  threeKicker: "3D · Three.js", threeTitle: "دو ہنر، ایک گردش",
  threeBody: "تانبے اور اسٹیل کے پائپ، ایک شٹ آف والو اور ایک بجلی — ماڈل آپ کے اسکرول کے ساتھ براہ راست گھومتا ہے۔ نیچے آگے، اوپر پیچھے۔",
  threeAria: "انٹرایکٹو 3D: پائپ اور بجلی", threeImgAlt: "پلمبنگ پائپوں اور بجلی کا 3D ماڈل، اسکرول سے گھومتا ہے", scrollToRotate: "گھمانے کے لیے اسکرول کریں",
  reducedTitle: "ہمارا کام، منظر بہ منظر", reducedJourneyAria: "ورک جرنی", videoAria: "S SERVICES کام کرتے ہوئے",
  electrical: "بجلی", plumbing: "پلمبنگ", electricalServices: "بجلی کی خدمات", plumbingServices: "پلمبنگ کی خدمات", bookService: "سروس بک کریں",
};

export const SCROLLY: Record<string, ScrollyCopy> = {
  it, en, "en-GB": en, fr, de, es, pt, nl, tr, ar, ur,
};

export const SCENE_IMGS_COUNT = 5;
