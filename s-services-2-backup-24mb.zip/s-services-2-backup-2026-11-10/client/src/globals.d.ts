declare module "*.css";
declare module "*.jpg";
declare module "*.jpeg";
declare module "*.png";
declare module "*.webp";
declare module "*.svg";
declare module "*.mp4";

/* The platform map runtime is loaded lazily as a file asset (never in
   the initial bundle): the import returns the emitted asset URL. The
   files use a .bin extension so the single-file build copies them
   verbatim (like the videos) instead of treating them as JS bundles;
   the loader in service-map.tsx fetches the bytes and runs them from
   a Blob URL, so no content-type is ever involved. */
declare module "*.bin" {
  const url: string;
  export default url;
}

/* Bundled map helpers (copied verbatim from the platform map runtime):
   mountMap checks capabilities and routes fatal errors to the
   onUnavailable callback; the URL builders produce Google Maps search /
   directions links for the outbound handoff only. */
declare module "*.mjs" {
  export interface MapPlace {
    label: string;
    venue?: string;
    address?: string;
    locality?: string;
    region?: string;
    country?: string;
    lat?: number;
    lng?: number;
  }
  export interface MapHandle {
    destroy: () => void;
    selectPlace: (index: number | null) => void;
  }
  export function mountMap(
    container: HTMLElement,
    options: Record<string, unknown>,
    onUnavailable: () => void,
  ): MapHandle | null;
  export function mapsSearchUrl(place: MapPlace): string | null;
  export function mapsDirectionsUrl(
    destination: MapPlace,
    options?: { origin?: { lat: number; lng: number }; travelmode?: string },
  ): string | null;
}
