import { useEffect, useMemo, useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, type ApiRequest, type ApiResponse } from "./api";
import { storageGet, storageRemove, storageSet } from "./storage";
import { CURRENCIES, DICTS, THEMES, money } from "./i18n";
import { statusLabel } from "./portal";
import { FAQ_LOCALIZED, SERVICE_DESC, SERVICE_NAMES } from "./service-i18n";
import { ALL_DETAILS, FAQS } from "./catalog";
import { SCROLLY } from "./scrolly-i18n";

type All = ApiResponse<typeof api, "adminGetAll">;

const BOOKING_STATUSES = ["new", "pending", "confirmed", "assigned", "in_progress", "completed", "cancelled"];

function Row({ children }: { children: React.ReactNode }) {
  return (
    <li className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
      {children}
    </li>
  );
}

/* Logo / favicon upload helper (Report 23): the chosen image is
   downscaled in the browser (max dimension `max` px) and returned as
   a data URL, which the settings form then saves into the settings
   store like any other setting — persistent, no separate file host,
   and the public site renders it from getState. */
function fileToScaledDataUrl(file: File, max: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const cx = canvas.getContext("2d");
      if (!cx) {
        URL.revokeObjectURL(url);
        reject(new Error("canvas unavailable"));
        return;
      }
      cx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/png"));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("image load failed"));
    };
    img.src = url;
  });
}

/* ---------- Staff authentication (dedicated Admin Login page) ----
   The back office has NO URL: no hash, path or link opens it. The old
   #admin hash route was removed completely (Report 24) — a website
   address ending in #admin now just loads the public website. The
   only way in is this Admin Login page, opened from the site's
   "Admin Login" menu/footer item, together with a staff session the
   SERVER has verified: the password hash is checked at login, a
   stored token is re-verified with the server (staffVerifySession)
   before any dashboard content renders, and every admin action
   re-checks the session token and role server-side. The name and
   role used below come from the server's verified answer, never from
   what the browser happens to have stored. */

interface StaffSession {
  token: string;
  name: string;
  email: string;
  role: "admin" | "manager" | "technician";
  technician_id: number | null;
}

function loadStaffSession(): StaffSession | null {
  try {
    const raw = storageGet("ss-staff-session");
    if (!raw) return null;
    const s = JSON.parse(raw) as StaffSession;
    return s.token && s.role ? s : null;
  } catch {
    return null;
  }
}

export function AdminView({
  serviceName,
  onExit,
}: {
  serviceName: (slug: string) => string;
  onExit?: () => void;
}) {
  const qc = useQueryClient();
  const [session, setSession] = useState<StaffSession | null>(loadStaffSession);
  const [verifiedToken, setVerifiedToken] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const status = useQuery({
    queryKey: ["staff-status"],
    queryFn: () => api.staffAuthStatus({}),
    enabled: !session,
  });

  /* Server verification gate (Report 24): a session object sitting in
     this browser's storage is NEVER enough to display the dashboard.
     The stored token is checked with the server and the dashboard
     renders only after the server confirms the session is live and
     returns the account's current name and role. A token the server
     rejects (expired, revoked at sign-out, deactivated account,
     forged) ends the local session immediately and returns to the
     Admin Login form — no dashboard content is ever shown for it. */
  const verify = useQuery({
    queryKey: ["admin-verify", session?.token ?? ""],
    queryFn: () => api.staffVerifySession({ token: session!.token }),
    enabled: !!session && verifiedToken !== session.token,
    retry: false,
  });

  useEffect(() => {
    if (!session || verifiedToken === session.token) return;
    const res = verify.data;
    if (!res) return;
    if (!res.ok) {
      storageRemove("ss-staff-session");
      setSession(null);
      setVerifiedToken(null);
      setNotice(
        "Your previous session has ended or is no longer valid — please sign in again.",
      );
      return;
    }
    if (
      res.role !== session.role ||
      res.name !== session.name ||
      res.email !== session.email ||
      res.technician_id !== session.technician_id
    ) {
      const fresh: StaffSession = {
        token: session.token,
        name: res.name,
        email: res.email,
        role: res.role as StaffSession["role"],
        technician_id: res.technician_id,
      };
      storageSet("ss-staff-session", JSON.stringify(fresh));
      setSession(fresh);
    }
    setVerifiedToken(session.token);
  }, [verify.data, session, verifiedToken]);

  const applySession = (s: StaffSession) => {
    setNotice("");
    storageSet("ss-staff-session", JSON.stringify(s));
    setSession(s);
  };

  /* Ends the back-office session everywhere it could linger: the
     stored token is dropped, every cached admin dataset is removed
     from the query cache (so the dashboard cannot reappear from
     cache via refresh or history), and the app leaves the admin view
     for the public homepage. The server session itself is deleted by
     staffLogout in AdminPanel before this runs; if it was already
     invalid server-side, the verification gate above has the same
     effect. */
  const endSession = () => {
    storageRemove("ss-staff-session");
    qc.removeQueries({ queryKey: ["admin-all"] });
    qc.removeQueries({ queryKey: ["admin-verify"] });
    setSession(null);
    setVerifiedToken(null);
    onExit?.();
  };

  if (!session) {
    if (status.isPending)
      return <p className="p-10 text-center text-[var(--dim)]">…</p>;
    if (status.data?.setup_required)
      return (
        <StaffSetup
          onDone={applySession}
          authorizedEmail={status.data.authorized_email}
        />
      );
    return <StaffLogin onDone={applySession} notice={notice} />;
  }

  const verified = verifiedToken === session.token && verify.data?.ok === true;
  if (!verified) {
    if (verify.isError)
      return (
        <div className="mx-auto max-w-md px-4 py-16 text-center">
          <h2 className="font-display text-2xl font-black">Could not verify your session</h2>
          <p className="mt-2 text-sm text-[var(--dim)]">
            For your security, the Admin Dashboard is shown only after
            the server confirms your staff session. The check could not
            be completed — no dashboard data was loaded.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <button
              type="button"
              className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold"
              onClick={() => verify.refetch()}
            >
              Try again
            </button>
            <button
              type="button"
              className="rounded-xl border border-[var(--border)] px-5 py-2.5 font-display font-bold"
              onClick={endSession}
            >
              Back to website
            </button>
          </div>
        </div>
      );
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center" role="status">
        <p className="font-display text-lg font-bold">Verifying your session…</p>
        <p className="mt-2 text-sm text-[var(--dim)]">
          The Admin Dashboard opens only after the server confirms your
          staff login.
        </p>
      </div>
    );
  }
  return (
    <AdminPanel
      session={session}
      onLogout={endSession}
      serviceName={serviceName}
    />
  );
}

function StaffSetup({
  onDone,
  authorizedEmail,
}: {
  onDone: (s: StaffSession) => void;
  authorizedEmail: string;
}) {
  const [error, setError] = useState("");
  const bootstrap = useMutation({
    mutationFn: api.staffBootstrap,
    onSuccess: (res, vars) => {
      if (res.ok)
        onDone({
          token: res.token,
          name: res.name,
          email: vars.email.toLowerCase(),
          role: "admin",
          technician_id: null,
        });
      else
        setError(
          res.error === "setup_closed"
            ? "Setup is already complete — please sign in."
            : res.error === "unauthorized_email"
              ? `This setup accepts only the authorized administrator email (${authorizedEmail}). No account was created.`
              : res.error,
        );
    },
    onError: () => setError("Setup failed — please try again."),
  });
  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <h2 className="font-display text-3xl font-black">Admin Login — first-time setup</h2>
      <p className="mt-2 text-sm text-[var(--dim)]">
        This protected area has no staff account yet. Create the first
        administrator account now; this setup closes permanently as soon
        as one account exists. For security, the setup accepts{" "}
        <strong className="text-[var(--text)]">only the authorized administrator email: {authorizedEmail}</strong>{" "}
        — any other email is refused by the server and no account is created.
        Clients can never register as administrators. Choose a strong
        password (min. 10 characters) — it is stored only as a salted
        PBKDF2 hash, never in plain text.
      </p>
      <form
        className="mt-6 grid gap-4 rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-5"
        onSubmit={(e) => {
          e.preventDefault();
          const fd = new FormData(e.currentTarget);
          bootstrap.mutate({
            name: String(fd.get("name") ?? ""),
            email: String(fd.get("email") ?? ""),
            password: String(fd.get("password") ?? ""),
          });
        }}
      >
        <div>
          <label htmlFor="su-name">Your name</label>
          <input id="su-name" name="name" required autoComplete="name" />
        </div>
        <div>
          <label htmlFor="su-email">Authorized admin email (your login)</label>
          <input id="su-email" name="email" type="email" required autoComplete="email" defaultValue={authorizedEmail} />
        </div>
        <div>
          <label htmlFor="su-pw">Password (min. 10)</label>
          <input id="su-pw" name="password" type="password" required minLength={10} autoComplete="new-password" />
        </div>
        {error && <p className="text-sm font-semibold text-red-500" role="alert">{error}</p>}
        <button type="submit" className="btn-primary rounded-xl px-5 py-3 font-display font-bold" disabled={bootstrap.isPending}>
          Create administrator account
        </button>
      </form>
    </div>
  );
}

function StaffLogin({
  onDone,
  notice,
}: {
  onDone: (s: StaffSession) => void;
  notice?: string;
}) {
  const [error, setError] = useState("");
  const login = useMutation({
    mutationFn: api.staffLogin,
    onSuccess: (res, vars) => {
      if (res.ok)
        onDone({
          token: res.token,
          name: res.name,
          email: vars.email.toLowerCase(),
          role: res.role as StaffSession["role"],
          technician_id: res.technician_id,
        });
      else setError("Incorrect email or password.");
    },
    onError: () => setError("Sign-in failed — please try again."),
  });
  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <h2 className="font-display text-3xl font-black">Admin Login</h2>
      <p className="mt-2 text-sm text-[var(--dim)]">
        Private back office of S SERVICES — this is the dedicated Admin
        Login page, the only way into the Admin Dashboard. There is no
        web address for the back office: adding anything (such as
        #admin) to the website address opens nothing. Sign in with a
        staff account created by an administrator; the dashboard opens
        only after the server verifies your login and your role.
      </p>
      {notice && (
        <p className="mt-4 rounded-xl border border-[var(--border)] bg-[var(--surface2)] px-4 py-3 text-sm font-semibold" role="status">
          {notice}
        </p>
      )}
      <form
        className="mt-6 grid gap-4 rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-5"
        onSubmit={(e) => {
          e.preventDefault();
          const fd = new FormData(e.currentTarget);
          login.mutate({
            email: String(fd.get("email") ?? ""),
            password: String(fd.get("password") ?? ""),
          });
        }}
      >
        <div>
          <label htmlFor="sl-email">Email</label>
          <input id="sl-email" name="email" type="email" required autoComplete="email" />
        </div>
        <div>
          <label htmlFor="sl-pw">Password</label>
          <input id="sl-pw" name="password" type="password" required autoComplete="current-password" />
        </div>
        {error && <p className="text-sm font-semibold text-red-500" role="alert">{error}</p>}
        <button type="submit" className="btn-primary rounded-xl px-5 py-3 font-display font-bold" disabled={login.isPending}>
          Sign in
        </button>
      </form>
    </div>
  );
}

function AdminPanel({
  session,
  onLogout,
  serviceName,
}: {
  session: StaffSession;
  onLogout: () => void;
  serviceName: (slug: string) => string;
}) {
  const qc = useQueryClient();
  const token = session.token;
  const role = session.role;
  const [tab, setTab] = useState("overview");
  /* List filters (Bookings / Customers / Services tabs) */
  const [bkQuery, setBkQuery] = useState("");
  const [bkStatus, setBkStatus] = useState("all");
  const [bkDate, setBkDate] = useState("");
  const [cuQuery, setCuQuery] = useState("");
  const [svQuery, setSvQuery] = useState("");
  const [svCat, setSvCat] = useState("all");
  const [svDeleteSlug, setSvDeleteSlug] = useState("");
  const [offerEdit, setOfferEdit] = useState<number | null>(null);
  const [offerDeleteId, setOfferDeleteId] = useState(0);
  /* Website Settings (Report 23): logo / favicon uploads are held as
     data URLs until the settings form saves them. null = untouched,
     "" = removed. */
  const [logoVal, setLogoVal] = useState<string | null>(null);
  const [faviconVal, setFaviconVal] = useState<string | null>(null);
  const [pwOpen, setPwOpen] = useState(false);
  const [pwMsg, setPwMsg] = useState("");
  const techSelf = session.technician_id ?? 0;
  const all = useQuery({
    queryKey: ["admin-all", token],
    queryFn: () => api.adminGetAll({ token }),
  });
  const inv = () => qc.invalidateQueries({ queryKey: ["admin-all"] });

  /* A rejected/expired session ends the back-office session locally. */
  useEffect(() => {
    if (!all.error) return;
    const msg = String((all.error as Error)?.message ?? all.error);
    if (msg.includes("UNAUTHORIZED") || msg.includes("FORBIDDEN")) onLogout();
  }, [all.error, onLogout]);

  const updBooking = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpdateBooking">, "token">) => api.adminUpdateBooking({ ...args, token }),
    onSuccess: inv,
  });
  const updQr = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpdateQuoteRequest">, "token">) => api.adminUpdateQuoteRequest({ ...args, token }),
    onSuccess: inv,
  });
  const createQ = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminCreateQuotation">, "token">) => api.adminCreateQuotation({ ...args, token }),
    onSuccess: inv,
  });
  const updQ = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpdateQuotation">, "token">) => api.adminUpdateQuotation({ ...args, token }),
    onSuccess: inv,
  });
  const createInv = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminCreateInvoice">, "token">) => api.adminCreateInvoice({ ...args, token }),
    onSuccess: inv,
  });
  const updInv = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpdateInvoice">, "token">) => api.adminUpdateInvoice({ ...args, token }),
    onSuccess: inv,
  });
  const upsertTech = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpsertTechnician">, "token">) => api.adminUpsertTechnician({ ...args, token }),
    onSuccess: inv,
  });
  const delTech = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminDeleteTechnician">, "token">) => api.adminDeleteTechnician({ ...args, token }),
    onSuccess: inv,
  });
  const upsertArea = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpsertArea">, "token">) => api.adminUpsertArea({ ...args, token }),
    onSuccess: inv,
  });
  const delArea = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminDeleteArea">, "token">) => api.adminDeleteArea({ ...args, token }),
    onSuccess: inv,
  });
  const updService = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpdateService">, "token">) => api.adminUpdateService({ ...args, token }),
    onSuccess: inv,
  });
  const upsertService = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpsertService">, "token">) => api.adminUpsertService({ ...args, token }),
    onSuccess: inv,
  });
  const delService = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminDeleteService">, "token">) => api.adminDeleteService({ ...args, token }),
    onSuccess: inv,
  });
  const upsertProject = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpsertProject">, "token">) => api.adminUpsertProject({ ...args, token }),
    onSuccess: inv,
  });
  const delProject = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminDeleteProject">, "token">) => api.adminDeleteProject({ ...args, token }),
    onSuccess: inv,
  });
  const moderate = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminModerateReview">, "token">) => api.adminModerateReview({ ...args, token }),
    onSuccess: inv,
  });
  const saveSettings = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminSaveSettings">, "token">) => api.adminSaveSettings({ ...args, token }),
    onSuccess: () => { inv(); qc.invalidateQueries({ queryKey: ["state"] }); },
  });
  const changePw = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "staffChangePassword">, "token">) => api.staffChangePassword({ ...args, token }),
    onSuccess: (res) =>
      setPwMsg(
        res.ok
          ? "Password changed ✓ — your other sessions were signed out; this one stays active."
          : "Current password is incorrect — nothing was changed.",
      ),
    onError: () => setPwMsg("Password change failed — please try again."),
  });
  const markRead = useMutation({
    mutationFn: () => api.adminMarkNotificationsRead({ token }),
    onSuccess: inv,
  });
  const upsertStaff = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpsertStaffUser">, "token">) => api.adminUpsertStaffUser({ ...args, token }),
    onSuccess: inv,
  });
  const delStaff = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminDeleteStaffUser">, "token">) => api.adminDeleteStaffUser({ ...args, token }),
    onSuccess: inv,
  });
  const setCustPw = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminSetCustomerPassword">, "token">) => api.adminSetCustomerPassword({ ...args, token }),
    onSuccess: inv,
  });
  const upsertOffer = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminUpsertOffer">, "token">) => api.adminUpsertOffer({ ...args, token }),
    onSuccess: () => { inv(); qc.invalidateQueries({ queryKey: ["state"] }); setOfferEdit(null); },
  });
  const delOffer = useMutation({
    mutationFn: (args: Omit<ApiRequest<typeof api, "adminDeleteOffer">, "token">) => api.adminDeleteOffer({ ...args, token }),
    onSuccess: () => { inv(); qc.invalidateQueries({ queryKey: ["state"] }); setOfferDeleteId(0); },
  });
  const staffLogout = useMutation({
    mutationFn: api.staffLogout,
    onSuccess: onLogout,
    onError: onLogout,
  });

  const d: All | undefined = all.data;
  const techName = useMemo(() => {
    const m = new Map<number, string>();
    d?.technicians.forEach((t) => m.set(t.id, t.name));
    return m;
  }, [d]);

  if (all.isPending) return <p className="p-10 text-center text-[var(--dim)]">…</p>;
  if (!d) return <p className="p-10 text-center text-red-500">Failed to load admin data.</p>;

  const tabs: [string, string][] =
    role === "technician"
      ? [["jobs", "My Jobs"]]
      : role === "manager"
        ? [["overview", "Overview"], ["bookings", "Bookings"], ["quotes", "Quotations"], ["team", "Team"]]
        : [["overview", "Overview"], ["bookings", "Bookings"], ["quotes", "Quotations"], ["finance", "Finance"], ["customers", "Customers"], ["team", "Team"], ["areas", "Service Areas"], ["services", "Services"], ["offers", "Offers"], ["projects", "Projects"], ["reviews", "Reviews"], ["messages", "Messages"], ["access", "Staff Access"], ["settings", "Settings"], ["reports", "Reports"]];

  const activeTab = tabs.some(([k]) => k === tab) ? tab : tabs[0]![0];
  const euro = (c: number) => money(c, d.settings["default_currency"] || "EUR");
  const unread = d.notifications.filter((n) => !n.is_read).length;

  const submitQuotation = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const g = (k: string) => String(fd.get(k) ?? "");
    const eur = (k: string) => Math.round(parseFloat(g(k) || "0") * 100);
    const qrId = g("quote_request_id");
    createQ.mutate({
      quote_request_id: qrId ? Number(qrId) : null,
      customer_name: g("customer_name"),
      customer_email: g("customer_email"),
      title: g("title"),
      labour_cents: eur("labour"),
      materials_cents: eur("materials"),
      service_cents: eur("service"),
      discount_cents: eur("discount"),
      currency: g("currency") || "EUR",
      expiry_date: g("expiry_date"),
      send: g("send") === "on",
    });
    e.currentTarget.reset();
  };

  const submitOffer = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const g = (k: string) => String(fd.get(k) ?? "");
    const dtype = g("discount_type") === "amount" ? "amount" : "percent";
    const raw = parseFloat(g("discount_value") || "0");
    upsertOffer.mutate({
      id: offerEdit,
      title: g("title"),
      description: g("description"),
      discount_type: dtype,
      discount_value: dtype === "amount" ? Math.round(raw * 100) : Math.round(raw),
      scope: (["public", "clients", "selected"].includes(g("scope")) ? g("scope") : "public") as "public" | "clients" | "selected",
      service_slug: g("service_slug"),
      active: g("active") === "on",
      starts_at: g("starts_at"),
      expires_at: g("expires_at"),
      assigned_emails: fd.getAll("assigned").map((v) => String(v)),
    });
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-3xl font-black">
          Admin {unread > 0 && <span className="ms-2 rounded-full bg-red-500 px-2.5 py-0.5 align-middle text-sm text-white">{unread}</span>}
        </h2>
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full bg-[var(--surface2)] px-3 py-1.5 text-sm font-bold">
            {session.name} · {role === "admin" ? "Admin" : role === "manager" ? "Manager" : "Technician"}
          </span>
          {unread > 0 && (
            <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-2 text-sm font-semibold" onClick={() => markRead.mutate()}>
              Mark notifications read
            </button>
          )}
          <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-2 text-sm font-semibold" onClick={() => { setPwOpen((o) => !o); setPwMsg(""); }} aria-expanded={pwOpen}>
            Change password
          </button>
          <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-2 text-sm font-semibold" onClick={() => staffLogout.mutate({ token })}>
            Sign out
          </button>
        </div>
      </div>
      <p className="mt-1 text-xs text-[var(--dim)]">
        Signed in as {session.email}. Your role comes from your staff account and is enforced on the server for every action — Admin (all modules), Manager (operations), Technician (only own assigned jobs). Customer accounts can never reach this area.
      </p>
      {pwOpen && (
        <form
          className="mt-3 grid max-w-lg gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4"
          onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            changePw.mutate({
              current_password: String(fd.get("current_password") ?? ""),
              new_password: String(fd.get("new_password") ?? ""),
            });
            e.currentTarget.reset();
          }}
        >
          <h3 className="font-display text-sm font-black">Change your password</h3>
          <div>
            <label htmlFor="pw-current">Current password</label>
            <input id="pw-current" name="current_password" type="password" required autoComplete="current-password" />
          </div>
          <div>
            <label htmlFor="pw-new">New password (min. 10 characters)</label>
            <input id="pw-new" name="new_password" type="password" required minLength={10} autoComplete="new-password" />
          </div>
          <div>
            <button type="submit" className="btn-primary rounded-xl px-4 py-2 font-display text-sm font-bold" disabled={changePw.isPending}>
              Save new password
            </button>
            {pwMsg && (
              <span className={`ms-3 text-sm font-semibold ${pwMsg.startsWith("Password changed") ? "text-emerald-500" : "text-red-500"}`} role="status">
                {pwMsg}
              </span>
            )}
          </div>
        </form>
      )}

      <div className="mt-5 flex flex-wrap gap-2 pb-1" role="tablist" aria-label="Admin sections">
        {tabs.map(([k, label]) => (
          <button key={k} type="button" role="tab" aria-selected={activeTab === k} onClick={() => setTab(k)}
            className={`whitespace-nowrap rounded-full px-4 py-2 font-display text-sm font-bold ${activeTab === k ? "btn-primary" : "border border-[var(--border)]"}`}>
            {label}
          </button>
        ))}
      </div>

      {activeTab === "overview" && (
        <div className="mt-6 grid gap-6">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              ["Total services", d.services.length],
              ["Electrical services", d.services.filter((s) => s.category === "electrical").length],
              ["Plumbing services", d.services.filter((s) => s.category === "plumbing").length],
              ["Published services", d.services.filter((s) => s.published).length],
              ["Total bookings", d.stats.total_bookings],
              ["New requests", d.stats.new_requests],
              ["Pending bookings", d.bookings.filter((b) => b.status === "pending").length],
              ["Emergency bookings", d.bookings.filter((b) => b.is_emergency).length],
              ["Confirmed", d.stats.confirmed],
              ["Completed jobs", d.stats.completed],
              ["Cancelled bookings", d.bookings.filter((b) => b.status === "cancelled").length],
              ["Quote requests", d.quote_requests.length],
              ["Offers (total)", d.offers.length],
              ["Offers (live now)", d.offers.filter((o) => o.active && (!o.starts_at || o.starts_at <= new Date().toISOString().slice(0, 10)) && (!o.expires_at || o.expires_at >= new Date().toISOString().slice(0, 10))).length],
              ["Pending quotations", d.stats.pending_quotations],
              ["Customers", d.stats.customers],
              ["Revenue (paid)", euro(d.stats.revenue_cents)],
              ["Outstanding", euro(d.stats.outstanding_cents)],
            ].map(([label, v]) => (
              <div key={label} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                <p className="font-display text-2xl font-black">{v}</p>
                <p className="text-xs font-semibold text-[var(--dim)]">{label}</p>
              </div>
            ))}
          </div>
          <section>
            <h3 className="font-display text-lg font-bold">Recent activity</h3>
            <ul className="mt-2 grid gap-1.5 text-sm">
              {d.activity.slice(0, 12).map((a) => (
                <li key={a.id} className="rounded-lg bg-[var(--surface2)] px-3 py-2">
                  <span className="font-semibold">{a.action}</span> · {a.detail}
                  <span className="block text-xs text-[var(--dim)]">{new Date(a.created_at).toLocaleString()}</span>
                </li>
              ))}
              {d.activity.length === 0 && <li className="text-[var(--dim)]">No activity yet.</li>}
            </ul>
          </section>
        </div>
      )}

      {(activeTab === "bookings" || activeTab === "jobs") && (
        <div className="mt-6">
          {role === "technician" && techSelf === 0 && (
            <p className="mb-4 rounded-xl bg-amber-500/10 px-4 py-3 text-sm font-semibold text-amber-500">
              Your staff account is not linked to a technician record yet, so no jobs can be assigned to you here. Ask an administrator to link your account in Staff Access.
            </p>
          )}
          {role === "technician" && techSelf > 0 && (
            <p className="mb-4 text-sm text-[var(--dim)]">
              Showing only jobs assigned to you — the server sends nothing else to a technician session.
            </p>
          )}
          {role !== "technician" && (
            <div className="mb-4 grid gap-2 sm:grid-cols-[1fr_180px_180px]">
              <div>
                <label htmlFor="bk-search">Search bookings (name, email, reference)</label>
                <input id="bk-search" type="search" value={bkQuery} onChange={(e) => setBkQuery(e.target.value)} placeholder="Es. Rossi, BK-…, email" />
              </div>
              <div>
                <label htmlFor="bk-status">Status</label>
                <select id="bk-status" value={bkStatus} onChange={(e) => setBkStatus(e.target.value)}>
                  <option value="all">All statuses</option>
                  {BOOKING_STATUSES.map((s) => <option key={s} value={s}>{statusLabel(s)}</option>)}
                  <option value="emergency">🚨 Emergency only</option>
                </select>
              </div>
              <div>
                <label htmlFor="bk-date">Date</label>
                <input id="bk-date" type="date" value={bkDate} onChange={(e) => setBkDate(e.target.value)} />
              </div>
            </div>
          )}
          <ul className="grid gap-3">
            {d.bookings
              .filter((b) => role !== "technician" || b.technician_id === techSelf)
              .filter((b) => {
                if (role === "technician") return true;
                if (bkStatus === "emergency" && !b.is_emergency) return false;
                if (bkStatus !== "all" && bkStatus !== "emergency" && b.status !== bkStatus) return false;
                if (bkDate && b.date !== bkDate) return false;
                if (bkQuery) {
                  const q = bkQuery.toLowerCase();
                  const hay = `${b.customer_name} ${b.customer_email} ${b.ref} ${b.customer_phone}`.toLowerCase();
                  if (!hay.includes(q)) return false;
                }
                return true;
              })
              .map((b) => (
                <Row key={b.id}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-display font-bold">
                      {b.is_emergency ? "🚨 " : ""}{serviceName(b.service_slug)} — {b.customer_name}
                    </span>
                    <span className="rounded-full bg-[var(--surface2)] px-2.5 py-0.5 text-xs font-bold">{statusLabel(b.status)}</span>
                  </div>
                  <p className="mt-1 text-sm text-[var(--dim)]">
                    {b.ref} · {b.customer_email} {b.customer_phone} · {b.address} {b.city} {b.postal_code}
                    {b.date ? ` · 📅 ${b.date} ${b.slot}` : ""}
                  </p>
                  {b.description && <p className="mt-1 text-sm">{b.description}</p>}
                  {b.photo_name && <p className="mt-1 text-xs text-[var(--dim)]">📷 {b.photo_name}</p>}
                  <div className="mt-3 grid gap-2 sm:grid-cols-4">
                    <div>
                      <label htmlFor={`bs-${b.id}`}>Status</label>
                      <select id={`bs-${b.id}`} aria-label={`Status for ${b.ref}`} defaultValue={b.status}
                        onChange={(e) => updBooking.mutate({ id: b.id, status: e.target.value as never })}>
                        {BOOKING_STATUSES.map((s) => <option key={s} value={s}>{statusLabel(s)}</option>)}
                      </select>
                    </div>
                    {role !== "technician" && (
                      <div>
                        <label htmlFor={`bt-${b.id}`}>Technician</label>
                        <select id={`bt-${b.id}`} aria-label={`Technician for ${b.ref}`} defaultValue={b.technician_id ?? ""}
                          onChange={(e) => updBooking.mutate({ id: b.id, technician_id: e.target.value ? Number(e.target.value) : null, status: (e.target.value ? "assigned" : b.status) as "assigned" })}>
                          <option value="">— unassigned —</option>
                          {d.technicians.filter((t) => t.active).map((t) => (
                            <option key={t.id} value={t.id}>{t.name} ({t.specialty})</option>
                          ))}
                        </select>
                      </div>
                    )}
                    <div>
                      <label htmlFor={`bd-${b.id}`}>Date</label>
                      <input id={`bd-${b.id}`} type="date" defaultValue={b.date} aria-label={`Date for ${b.ref}`}
                        onBlur={(e) => e.target.value !== b.date && updBooking.mutate({ id: b.id, date: e.target.value })} />
                    </div>
                    <div>
                      <label htmlFor={`bn-${b.id}`}>{role === "technician" ? "Work notes" : "Internal notes"}</label>
                      <input id={`bn-${b.id}`} defaultValue={role === "technician" ? b.work_notes : b.internal_notes} aria-label={`Notes for ${b.ref}`}
                        onBlur={(e) => updBooking.mutate(role === "technician" ? { id: b.id, work_notes: e.target.value } : { id: b.id, internal_notes: e.target.value })} />
                    </div>
                  </div>
                  {b.technician_id != null && <p className="mt-2 text-xs text-[var(--dim)]">Assigned to: {techName.get(b.technician_id) ?? b.technician_id}</p>}
                </Row>
              ))}
            {d.bookings.length === 0 && <p className="text-[var(--dim)]">No bookings yet.</p>}
          </ul>
        </div>
      )}

      {activeTab === "quotes" && (
        <div className="mt-6 grid gap-8">
          <section>
            <h3 className="font-display text-lg font-bold">Quotation requests</h3>
            <ul className="mt-3 grid gap-3">
              {d.quote_requests.map((q) => (
                <Row key={q.id}>
                  <div className="flex flex-wrap justify-between gap-2">
                    <span className="font-semibold">{serviceName(q.service_slug)} — {q.customer_name}</span>
                    <span className="text-xs font-bold text-[var(--dim)]">{q.ref} · {statusLabel(q.status)}</span>
                  </div>
                  <p className="mt-1 text-sm text-[var(--dim)]">{q.customer_email} · {q.city} · {q.measurements}</p>
                  <p className="mt-1 text-sm">{q.description}</p>
                  <div className="mt-2 flex gap-2">
                    {(["reviewing", "quoted", "closed"] as const).map((s) => (
                      <button key={s} type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold"
                        onClick={() => updQr.mutate({ id: q.id, status: s })}>{statusLabel(s)}</button>
                    ))}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <a className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold" href={`mailto:${q.customer_email}`}>✉️ Email customer</a>
                    {q.customer_phone && <a className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold" href={`tel:${q.customer_phone}`}>📞 Call</a>}
                    {q.customer_phone && (
                      <a className="rounded-lg px-3 py-1.5 text-xs font-bold text-white" style={{ background: "#1ebe5b" }} href={`https://wa.me/${q.customer_phone.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer">💬 WhatsApp</a>
                    )}
                  </div>
                </Row>
              ))}
              {d.quote_requests.length === 0 && <p className="text-[var(--dim)]">No requests yet.</p>}
            </ul>
          </section>

          <section>
            <h3 className="font-display text-lg font-bold">Create quotation</h3>
            <form onSubmit={submitQuotation} className="mt-3 grid gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-3">
              <div>
                <label htmlFor="q-req">From request</label>
                <select id="q-req" name="quote_request_id" aria-label="From request" defaultValue=""
                  onChange={(e) => {
                    const qr = d.quote_requests.find((x) => x.id === Number(e.target.value));
                    const f = e.target.form;
                    if (qr && f) {
                      (f.elements.namedItem("customer_name") as HTMLInputElement).value = qr.customer_name;
                      (f.elements.namedItem("customer_email") as HTMLInputElement).value = qr.customer_email;
                      (f.elements.namedItem("title") as HTMLInputElement).value = serviceName(qr.service_slug);
                    }
                  }}>
                  <option value="">— manual —</option>
                  {d.quote_requests.map((q) => <option key={q.id} value={q.id}>{q.ref} · {q.customer_name}</option>)}
                </select>
              </div>
              <div><label htmlFor="q-name">Customer name</label><input id="q-name" name="customer_name" required /></div>
              <div><label htmlFor="q-email">Customer email</label><input id="q-email" name="customer_email" type="email" required /></div>
              <div className="sm:col-span-3"><label htmlFor="q-title">Title</label><input id="q-title" name="title" required /></div>
              <div><label htmlFor="q-lab">Labour</label><input id="q-lab" name="labour" type="number" step="0.01" min="0" defaultValue="0" /></div>
              <div><label htmlFor="q-mat">Materials</label><input id="q-mat" name="materials" type="number" step="0.01" min="0" defaultValue="0" /></div>
              <div><label htmlFor="q-svc">Service charges</label><input id="q-svc" name="service" type="number" step="0.01" min="0" defaultValue="0" /></div>
              <div><label htmlFor="q-disc">Discount</label><input id="q-disc" name="discount" type="number" step="0.01" min="0" defaultValue="0" /></div>
              <div>
                <label htmlFor="q-cur">Currency</label>
                <select id="q-cur" name="currency" defaultValue={d.settings["default_currency"] || "EUR"}>
                  {CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div><label htmlFor="q-exp">Expiry date</label><input id="q-exp" name="expiry_date" type="date" /></div>
              <label className="!mb-0 flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
                <input type="checkbox" name="send" className="!w-4" /> Send to customer now
              </label>
              <div className="sm:col-span-3">
                <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold" disabled={createQ.isPending}>
                  Create quotation {createQ.data?.ref ? `· ${createQ.data.ref}` : ""}
                </button>
              </div>
            </form>
          </section>

          <section>
            <h3 className="font-display text-lg font-bold">Quotations</h3>
            <ul className="mt-3 grid gap-3">
              {d.quotations.map((q) => (
                <Row key={q.id}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold">{q.title} — {q.customer_name}</span>
                    <span className="font-display font-black">{money(q.total_cents, q.currency)}</span>
                  </div>
                  <p className="mt-1 text-sm text-[var(--dim)]">
                    {q.ref} · {statusLabel(q.status)} · labour {money(q.labour_cents, q.currency)} · materials {money(q.materials_cents, q.currency)} · service {money(q.service_cents, q.currency)} · discount −{money(q.discount_cents, q.currency)}
                    {q.expiry_date ? ` · expires ${q.expiry_date}` : ""}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {q.status === "draft" && (
                      <button type="button" className="btn-primary rounded-lg px-3 py-1.5 text-xs font-bold" onClick={() => updQ.mutate({ id: q.id, status: "sent" })}>Send to customer</button>
                    )}
                    {q.status === "accepted" && (
                      <button type="button" className="btn-primary rounded-lg px-3 py-1.5 text-xs font-bold"
                        onClick={() => createInv.mutate({ quotation_id: q.id, customer_name: q.customer_name, customer_email: q.customer_email, amount_cents: q.total_cents, currency: q.currency, due_date: "" })}>
                        Create invoice
                      </button>
                    )}
                    <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold" onClick={() => window.print()}>Print / PDF</button>
                  </div>
                </Row>
              ))}
              {d.quotations.length === 0 && <p className="text-[var(--dim)]">No quotations yet.</p>}
            </ul>
          </section>
        </div>
      )}

      {activeTab === "finance" && (
        <div className="mt-6">
          <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
              <p className="font-display text-2xl font-black">{euro(d.stats.revenue_cents)}</p>
              <p className="text-xs font-semibold text-[var(--dim)]">Revenue (paid invoices)</p>
            </div>
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
              <p className="font-display text-2xl font-black">{euro(d.stats.outstanding_cents)}</p>
              <p className="text-xs font-semibold text-[var(--dim)]">Outstanding balances</p>
            </div>
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
              <p className="font-display text-2xl font-black">{d.invoices.length}</p>
              <p className="text-xs font-semibold text-[var(--dim)]">Invoices · multi-currency EUR/USD/GBP/PKR/AED</p>
            </div>
          </div>
          <ul className="grid gap-3">
            {d.invoices.map((inv) => (
              <Row key={inv.id}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">{inv.ref} — {inv.customer_name}</span>
                  <span className="font-display font-black">{money(inv.amount_cents, inv.currency)}</span>
                </div>
                <p className="mt-1 text-sm text-[var(--dim)]">{inv.customer_email} · {statusLabel(inv.status)}{inv.due_date ? ` · due ${inv.due_date}` : ""}</p>
                <div className="mt-2 flex gap-2">
                  {(["paid", "unpaid", "overdue", "void"] as const).map((s) => (
                    <button key={s} type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold" onClick={() => updInv.mutate({ id: inv.id, status: s })}>{statusLabel(s)}</button>
                  ))}
                </div>
              </Row>
            ))}
            {d.invoices.length === 0 && <p className="text-[var(--dim)]">No invoices yet. Create one from an accepted quotation.</p>}
          </ul>
        </div>
      )}

      {activeTab === "customers" && (
        <div className="mt-6">
          <div className="mb-4 max-w-md">
            <label htmlFor="cu-search">Search customers (name, email, phone)</label>
            <input id="cu-search" type="search" value={cuQuery} onChange={(e) => setCuQuery(e.target.value)} placeholder="Es. Rossi, email, +39…" />
          </div>
        <ul className="grid gap-3">
          {d.customers
            .filter((c) => {
              if (!cuQuery) return true;
              const q = cuQuery.toLowerCase();
              return `${c.name} ${c.email} ${c.phone}`.toLowerCase().includes(q);
            })
            .map((c) => (
            <Row key={c.id}>
              <span className="font-semibold">{c.name}</span>
              <span className="text-sm text-[var(--dim)]"> · {c.email} · {c.phone} · {c.address} · {c.language.toUpperCase()} · {c.currency}</span>
              <p className="mt-1 text-xs text-[var(--dim)]">
                Bookings: {d.bookings.filter((b) => b.customer_email === c.email).length} · Quotations: {d.quotations.filter((q) => q.customer_email === c.email).length} · Invoices: {d.invoices.filter((i) => i.customer_email === c.email).length}
                {" · "}Portal password: {c.has_password ? "set (login required)" : "not set — records visible by email lookup; the customer can claim a password in the portal"}
              </p>
              <details className="mt-2">
                <summary className="cursor-pointer text-sm font-bold text-[var(--accent)]">Booking &amp; quotation history</summary>
                <ul className="mt-2 grid gap-1.5 text-sm">
                  {d.bookings.filter((b) => b.customer_email === c.email).map((b) => (
                    <li key={`b-${b.id}`} className="rounded-lg bg-[var(--surface2)] px-3 py-2">
                      📅 {b.ref} · {serviceName(b.service_slug)} · {statusLabel(b.status)}{b.date ? ` · ${b.date} ${b.slot}` : ""}{b.is_emergency ? " · 🚨 emergency" : ""}
                    </li>
                  ))}
                  {d.quote_requests.filter((q) => q.customer_email === c.email).map((q) => (
                    <li key={`q-${q.id}`} className="rounded-lg bg-[var(--surface2)] px-3 py-2">
                      📋 {q.ref} · {serviceName(q.service_slug)} · {statusLabel(q.status)}
                    </li>
                  ))}
                  {d.quotations.filter((q) => q.customer_email === c.email).map((q) => (
                    <li key={`qt-${q.id}`} className="rounded-lg bg-[var(--surface2)] px-3 py-2">
                      💶 {q.ref} · {q.title} · {money(q.total_cents, q.currency)} · {statusLabel(q.status)}
                    </li>
                  ))}
                  {d.bookings.filter((b) => b.customer_email === c.email).length === 0 &&
                    d.quote_requests.filter((q) => q.customer_email === c.email).length === 0 &&
                    d.quotations.filter((q) => q.customer_email === c.email).length === 0 && (
                      <li className="text-[var(--dim)]">No bookings or quotations yet.</li>
                    )}
                </ul>
              </details>
              <form
                className="mt-2 flex flex-wrap items-end gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  const fd = new FormData(e.currentTarget);
                  setCustPw.mutate({ email: c.email, password: String(fd.get("password") ?? "") });
                  e.currentTarget.reset();
                }}
              >
                <div className="w-56">
                  <label htmlFor={`cpw-${c.id}`}>{c.has_password ? "Set new / temporary password (min 8)" : "Set first password (min 8)"}</label>
                  <input id={`cpw-${c.id}`} name="password" type="password" minLength={8} required autoComplete="new-password" />
                </div>
                <button type="submit" className="rounded-lg border border-[var(--border)] px-3 py-2 text-xs font-bold" disabled={setCustPw.isPending}>
                  Save password {setCustPw.isSuccess ? "✓" : ""}
                </button>
                <span className="text-xs text-[var(--dim)]">Use for password-reset requests: give the temporary password to the customer directly; they can change it in their portal.</span>
              </form>
            </Row>
          ))}
          {d.customers.length === 0 && <p className="text-[var(--dim)]">No customers yet.</p>}
        </ul>
        </div>
      )}

      {activeTab === "team" && (
        <div className="mt-6 grid gap-6">
          {role !== "admin" && (
            <p className="text-sm text-[var(--dim)]">Team records are read-only for managers — only an administrator can add, deactivate or delete people.</p>
          )}
          {role === "admin" && (
          <form
            className="grid gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-3"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const g = (k: string) => String(fd.get(k) ?? "");
              upsertTech.mutate({ id: null, name: g("name"), email: g("email"), phone: g("phone"), specialty: g("specialty") as never, role: g("role") as never, active: true });
              e.currentTarget.reset();
            }}
          >
            <div><label htmlFor="tm-name">Name</label><input id="tm-name" name="name" required /></div>
            <div><label htmlFor="tm-email">Email</label><input id="tm-email" name="email" type="email" /></div>
            <div><label htmlFor="tm-phone">Phone</label><input id="tm-phone" name="phone" /></div>
            <div>
              <label htmlFor="tm-spec">Specialty</label>
              <select id="tm-spec" name="specialty" defaultValue="both">
                <option value="electrical">Electrical</option>
                <option value="plumbing">Plumbing</option>
                <option value="both">Both</option>
              </select>
            </div>
            <div>
              <label htmlFor="tm-role">Role</label>
              <select id="tm-role" name="role" defaultValue="technician">
                <option value="technician">Technician</option>
                <option value="manager">Manager</option>
              </select>
            </div>
            <div className="self-end">
              <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold">Add person</button>
            </div>
          </form>
          )}
          <ul className="grid gap-3">
            {d.technicians.map((t) => (
              <Row key={t.id}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">{t.name} <span className="text-[var(--dim)]">· {t.role} · {t.specialty}{t.active ? "" : " · inactive"}</span></span>
                  {role === "admin" && (
                  <div className="flex gap-2">
                    <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold"
                      onClick={() => upsertTech.mutate({ id: t.id, name: t.name, email: t.email, phone: t.phone, specialty: t.specialty as never, role: t.role as never, active: !t.active })}>
                      {t.active ? "Deactivate" : "Activate"}
                    </button>
                    <button type="button" className="rounded-lg border border-red-500/50 px-3 py-1.5 text-xs font-bold text-red-500" onClick={() => delTech.mutate({ id: t.id })}>Delete</button>
                  </div>
                  )}
                </div>
                <p className="text-sm text-[var(--dim)]">{t.email} {t.phone} · Assigned jobs: {d.bookings.filter((b) => b.technician_id === t.id).length}</p>
              </Row>
            ))}
            {d.technicians.length === 0 && <p className="text-[var(--dim)]">No team members yet.</p>}
          </ul>
        </div>
      )}

      {activeTab === "areas" && (
        <div className="mt-6 grid gap-6">
          <form
            className="grid gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-3"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const g = (k: string) => String(fd.get(k) ?? "");
              upsertArea.mutate({
                id: null, country: g("country"), region: g("region"), city: g("city"), postal_codes: g("postal_codes"),
                electrical: g("electrical") === "on", plumbing: g("plumbing") === "on", emergency: g("emergency") === "on",
                active: true, surcharge_cents: Math.round(parseFloat(g("surcharge") || "0") * 100),
              });
              e.currentTarget.reset();
            }}
          >
            <div><label htmlFor="ar-country">Country</label><input id="ar-country" name="country" required placeholder="Italia" /></div>
            <div><label htmlFor="ar-region">Region</label><input id="ar-region" name="region" placeholder="Lombardia" /></div>
            <div><label htmlFor="ar-city">City</label><input id="ar-city" name="city" required placeholder="Milano" /></div>
            <div><label htmlFor="ar-postal">Postal codes</label><input id="ar-postal" name="postal_codes" placeholder="20100–20162" /></div>
            <div><label htmlFor="ar-sur">Surcharge</label><input id="ar-sur" name="surcharge" type="number" step="0.01" min="0" defaultValue="0" /></div>
            <div className="flex flex-wrap items-end gap-4 pb-2">
              <label className="!mb-0 flex items-center gap-1.5 text-sm font-semibold text-[var(--text)]"><input type="checkbox" name="electrical" defaultChecked className="!w-4" /> Electrical</label>
              <label className="!mb-0 flex items-center gap-1.5 text-sm font-semibold text-[var(--text)]"><input type="checkbox" name="plumbing" defaultChecked className="!w-4" /> Plumbing</label>
              <label className="!mb-0 flex items-center gap-1.5 text-sm font-semibold text-[var(--text)]"><input type="checkbox" name="emergency" className="!w-4" /> Emergency</label>
            </div>
            <div className="sm:col-span-3">
              <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold">Activate area</button>
            </div>
          </form>
          <ul className="grid gap-3">
            {d.areas.map((a) => (
              <Row key={a.id}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">{a.city}, {a.region} — {a.country} {a.active ? "" : "(inactive)"}</span>
                  <div className="flex gap-2">
                    <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold"
                      onClick={() => upsertArea.mutate({ id: a.id, country: a.country, region: a.region, city: a.city, postal_codes: a.postal_codes, electrical: a.electrical, plumbing: a.plumbing, emergency: a.emergency, active: !a.active, surcharge_cents: a.surcharge_cents })}>
                      {a.active ? "Deactivate" : "Activate"}
                    </button>
                    <button type="button" className="rounded-lg border border-red-500/50 px-3 py-1.5 text-xs font-bold text-red-500" onClick={() => delArea.mutate({ id: a.id })}>Delete</button>
                  </div>
                </div>
                <p className="text-sm text-[var(--dim)]">{a.postal_codes} · {a.electrical ? "⚡ " : ""}{a.plumbing ? "💧 " : ""}{a.emergency ? "🚨 emergency" : ""} {a.surcharge_cents > 0 ? `· surcharge ${euro(a.surcharge_cents)}` : ""}</p>
              </Row>
            ))}
            {d.areas.length === 0 && <p className="text-[var(--dim)]">No areas yet — the public site honestly shows no coverage until you activate one.</p>}
          </ul>
        </div>
      )}

      {activeTab === "services" && (
        <div className="mt-6 grid gap-5">
          <p className="max-w-3xl text-sm text-[var(--dim)]">
            All {d.services.length} catalogue services ({d.services.filter((s) => s.category === "electrical").length} electrical · {d.services.filter((s) => s.category === "plumbing").length} plumbing).
            Edit a name or category inline (saved when you leave the field), set the starting price, publish/hide, add a new service, or delete one.
            Long descriptions and their 11-language translations are managed in the site catalogue files, so an edited name keeps every translation of its description.
          </p>
          <div className="grid gap-2 sm:grid-cols-[1fr_200px]">
            <div>
              <label htmlFor="sv-search">Search services</label>
              <input id="sv-search" type="search" value={svQuery} onChange={(e) => setSvQuery(e.target.value)} placeholder="Es. caldaia, boiler, …" />
            </div>
            <div>
              <label htmlFor="sv-cat">Category</label>
              <select id="sv-cat" value={svCat} onChange={(e) => setSvCat(e.target.value)}>
                <option value="all">All categories</option>
                <option value="electrical">⚡ Electrical</option>
                <option value="plumbing">💧 Plumbing</option>
              </select>
            </div>
          </div>
          <form
            className="grid gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-3"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const g = (k: string) => String(fd.get(k) ?? "");
              const price = g("price");
              upsertService.mutate({
                slug: g("slug").trim().toLowerCase(),
                name_it: g("name_it"),
                name_en: g("name_en"),
                category: g("category") as "electrical" | "plumbing",
                base_price_cents: price ? Math.round(parseFloat(price) * 100) : null,
                published: g("published") === "on",
              });
              e.currentTarget.reset();
            }}
          >
            <div><label htmlFor="ns-slug">Slug (unique, kebab-case)</label><input id="ns-slug" name="slug" required pattern="[a-z0-9]+(-[a-z0-9]+)*" placeholder="es. smart-home-lighting" /></div>
            <div><label htmlFor="ns-nameit">Name (Italiano)</label><input id="ns-nameit" name="name_it" required /></div>
            <div><label htmlFor="ns-nameen">Name (English)</label><input id="ns-nameen" name="name_en" required /></div>
            <div>
              <label htmlFor="ns-cat">Category</label>
              <select id="ns-cat" name="category" defaultValue="electrical">
                <option value="electrical">⚡ Electrical</option>
                <option value="plumbing">💧 Plumbing</option>
              </select>
            </div>
            <div><label htmlFor="ns-price">Starting price € (optional)</label><input id="ns-price" name="price" type="number" step="0.01" min="0" /></div>
            <div className="flex items-end gap-3 pb-1">
              <label className="!mb-0 flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
                <input type="checkbox" name="published" defaultChecked className="!w-4" /> Published
              </label>
              <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold" disabled={upsertService.isPending}>
                Add service {upsertService.isSuccess ? "✓" : ""}
              </button>
            </div>
            {upsertService.isError && <p className="text-sm font-semibold text-red-500 sm:col-span-3" role="alert">Could not save — check the slug is unique kebab-case and both names are filled in.</p>}
          </form>
          <ul className="grid gap-2">
            {d.services
              .filter((s) => (svCat === "all" || s.category === svCat) && (!svQuery || `${s.name_it} ${s.name_en} ${s.slug}`.toLowerCase().includes(svQuery.toLowerCase())))
              .map((s) => (
                <li key={s.slug} className="grid gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span aria-hidden>{s.category === "electrical" ? "⚡" : "💧"}</span>
                    <div className="min-w-40 flex-1">
                      <label htmlFor={`sn-it-${s.slug}`} className="sr-only">Italian name for {s.slug}</label>
                      <input id={`sn-it-${s.slug}`} defaultValue={s.name_it} aria-label={`Italian name for ${s.name_en}`}
                        onBlur={(e) => {
                          const v = e.target.value.trim();
                          if (v && v !== s.name_it) upsertService.mutate({ slug: s.slug, name_it: v, name_en: s.name_en, category: s.category as "electrical" | "plumbing", base_price_cents: s.base_price_cents, published: s.published });
                        }} />
                    </div>
                    <div className="min-w-40 flex-1">
                      <label htmlFor={`sn-en-${s.slug}`} className="sr-only">English name for {s.slug}</label>
                      <input id={`sn-en-${s.slug}`} defaultValue={s.name_en} aria-label={`English name for ${s.name_en}`}
                        onBlur={(e) => {
                          const v = e.target.value.trim();
                          if (v && v !== s.name_en) upsertService.mutate({ slug: s.slug, name_it: s.name_it, name_en: v, category: s.category as "electrical" | "plumbing", base_price_cents: s.base_price_cents, published: s.published });
                        }} />
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="w-40">
                      <label htmlFor={`sc-${s.slug}`} className="sr-only">Category for {s.name_en}</label>
                      <select id={`sc-${s.slug}`} defaultValue={s.category} aria-label={`Category for ${s.name_en}`}
                        onChange={(e) => upsertService.mutate({ slug: s.slug, name_it: s.name_it, name_en: s.name_en, category: e.target.value as "electrical" | "plumbing", base_price_cents: s.base_price_cents, published: s.published })}>
                        <option value="electrical">⚡ Electrical</option>
                        <option value="plumbing">💧 Plumbing</option>
                      </select>
                    </div>
                    <label htmlFor={`sp-${s.slug}`} className="!mb-0">From €</label>
                    <input id={`sp-${s.slug}`} type="number" step="1" min="0" className="!w-24" aria-label={`Starting price for ${s.name_en}`}
                      defaultValue={s.base_price_cents != null ? s.base_price_cents / 100 : ""}
                      onBlur={(e) => {
                        const v = e.target.value ? Math.round(parseFloat(e.target.value) * 100) : null;
                        if (v !== s.base_price_cents) updService.mutate({ slug: s.slug, base_price_cents: v });
                      }} />
                    <button type="button" className={`rounded-lg px-3 py-1.5 text-xs font-bold ${s.published ? "btn-primary" : "border border-[var(--border)]"}`}
                      onClick={() => updService.mutate({ slug: s.slug, published: !s.published })}>
                      {s.published ? "Published" : "Hidden"}
                    </button>
                    <span className="text-xs text-[var(--dim)]">{s.slug}</span>
                    {svDeleteSlug === s.slug ? (
                      <span className="ms-auto flex items-center gap-2">
                        <span className="text-xs font-bold text-red-500">Delete “{s.name_en}” permanently?</span>
                        <button type="button" className="rounded-lg bg-red-500 px-3 py-1.5 text-xs font-bold text-white"
                          onClick={() => { delService.mutate({ slug: s.slug }); setSvDeleteSlug(""); }}>
                          Confirm delete
                        </button>
                        <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold" onClick={() => setSvDeleteSlug("")}>Cancel</button>
                      </span>
                    ) : (
                      <button type="button" className="ms-auto rounded-lg border border-red-500/50 px-3 py-1.5 text-xs font-bold text-red-500" onClick={() => setSvDeleteSlug(s.slug)}>
                        Delete
                      </button>
                    )}
                  </div>
                </li>
              ))}
          </ul>
        </div>
      )}

      {activeTab === "offers" && (() => {
        const today = new Date().toISOString().slice(0, 10);
        const offerStatus = (o: All["offers"][number]) =>
          !o.active ? "Disabled"
            : o.starts_at && o.starts_at > today ? "Scheduled"
              : o.expires_at && o.expires_at < today ? "Expired"
                : "Live";
        const editing = offerEdit != null ? d.offers.find((o) => o.id === offerEdit) : undefined;
        return (
          <div className="mt-6 grid gap-6">
            <p className="text-sm text-[var(--dim)]">
              Reusable promotions — separate from the one-off discount on a single quotation. Public offers appear on the
              homepage for every visitor; “Registered clients” offers appear in every signed-in Client Portal; “Selected
              clients” offers appear only in the chosen customers' portals, and those customers also receive a portal
              notification. Expired offers stop showing automatically.
            </p>
            <form key={editing ? `edit-${editing.id}` : "new"} onSubmit={submitOffer} className="grid gap-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-2">
              <h3 className="font-display text-lg font-bold sm:col-span-2">{editing ? `Edit offer — ${editing.title}` : "Create a new offer"}</h3>
              <div className="sm:col-span-2">
                <label htmlFor="of-title">Title</label>
                <input id="of-title" name="title" required minLength={2} maxLength={120} defaultValue={editing?.title ?? ""} placeholder="Es. Autumn panel check −15%" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="of-desc">Description</label>
                <textarea id="of-desc" name="description" rows={2} maxLength={500} defaultValue={editing?.description ?? ""} placeholder="What the offer covers, in one or two sentences." />
              </div>
              <div>
                <label htmlFor="of-dtype">Discount type</label>
                <select id="of-dtype" name="discount_type" defaultValue={editing?.discount_type ?? "percent"}>
                  <option value="percent">Percentage (%)</option>
                  <option value="amount">Fixed amount ({d.settings["default_currency"] || "EUR"})</option>
                </select>
              </div>
              <div>
                <label htmlFor="of-dvalue">Discount value (% or amount)</label>
                <input id="of-dvalue" name="discount_value" type="number" min={0} step="any" required defaultValue={editing ? (editing.discount_type === "amount" ? editing.discount_value / 100 : editing.discount_value) : ""} placeholder="15" />
              </div>
              <div>
                <label htmlFor="of-scope">Audience</label>
                <select id="of-scope" name="scope" defaultValue={editing?.scope ?? "public"}>
                  <option value="public">Public — all visitors</option>
                  <option value="clients">Registered clients — all</option>
                  <option value="selected">Selected clients only</option>
                </select>
              </div>
              <div>
                <label htmlFor="of-service">Applies to service (optional)</label>
                <select id="of-service" name="service_slug" defaultValue={editing?.service_slug ?? ""}>
                  <option value="">All services</option>
                  {d.services.map((s) => (
                    <option key={s.slug} value={s.slug}>{serviceName(s.slug)}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="of-start">Start date</label>
                <input id="of-start" name="starts_at" type="date" defaultValue={editing?.starts_at ?? ""} />
              </div>
              <div>
                <label htmlFor="of-exp">Expiration date</label>
                <input id="of-exp" name="expires_at" type="date" defaultValue={editing?.expires_at ?? ""} />
              </div>
              <div className="sm:col-span-2">
                <span className="mb-1 block text-xs font-semibold text-[var(--dim)]">Assign to clients (used when audience = “Selected clients only”)</span>
                {d.customers.length === 0 && <p className="text-sm text-[var(--dim)]">No customer records yet.</p>}
                <div className="grid max-h-44 gap-1 overflow-y-auto sm:grid-cols-2">
                  {d.customers.map((c) => (
                    <label key={c.id} className="!mb-0 flex items-center gap-2 rounded-lg bg-[var(--surface2)] px-3 py-2 text-sm font-normal normal-case">
                      <input type="checkbox" name="assigned" value={c.email} defaultChecked={editing?.assigned_emails.includes(c.email)} className="!w-auto" />
                      <span className="min-w-0 truncate">{c.name} · {c.email}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
                <label className="!mb-0 flex items-center gap-2 text-sm">
                  <input type="checkbox" name="active" defaultChecked={editing ? editing.active : true} className="!w-auto" /> Enabled
                </label>
                <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold" disabled={upsertOffer.isPending}>
                  {editing ? "Save changes" : "Create offer"}
                </button>
                {editing && (
                  <button type="button" className="rounded-xl border border-[var(--border)] px-4 py-2.5 font-display font-bold" onClick={() => setOfferEdit(null)}>
                    Cancel editing
                  </button>
                )}
                {upsertOffer.isError && <span className="text-sm font-semibold text-red-500" role="alert">Save failed — check the values (percent must be 1–100; a selected offer needs at least one client).</span>}
              </div>
            </form>

            <ul className="grid gap-3">
              {d.offers.map((o) => {
                const st = offerStatus(o);
                return (
                  <li key={o.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-display font-bold">{o.title}</span>
                      <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold ${st === "Live" ? "bg-emerald-500/15 text-emerald-500" : st === "Expired" ? "bg-red-500/15 text-red-500" : "bg-[var(--surface2)] text-[var(--dim)]"}`}>{st}</span>
                    </div>
                    <p className="mt-1 text-sm text-[var(--dim)]">
                      {o.discount_type === "percent" ? `${o.discount_value}% off` : `${euro(o.discount_value)} off`}
                      {" · "}{o.scope === "public" ? "Public" : o.scope === "clients" ? "All registered clients" : `Selected (${o.assigned_emails.length})`}
                      {o.service_slug ? ` · ${serviceName(o.service_slug)}` : " · All services"}
                      {o.starts_at ? ` · from ${o.starts_at}` : ""}
                      {o.expires_at ? ` · until ${o.expires_at}` : " · no expiry"}
                    </p>
                    {o.description && <p className="mt-1 text-sm">{o.description}</p>}
                    {o.scope === "selected" && o.assigned_emails.length > 0 && (
                      <p className="mt-1 text-xs text-[var(--dim)]">{o.assigned_emails.join(", ")}</p>
                    )}
                    <div className="mt-3 flex flex-wrap gap-2">
                      <button type="button" className="rounded-lg border border-[var(--border)] px-3.5 py-1.5 text-sm font-bold" onClick={() => setOfferEdit(o.id)}>Edit</button>
                      {offerDeleteId === o.id ? (
                        <>
                          <button type="button" className="rounded-lg bg-red-500 px-3.5 py-1.5 text-sm font-bold text-white" onClick={() => delOffer.mutate({ id: o.id })} disabled={delOffer.isPending}>Confirm delete</button>
                          <button type="button" className="rounded-lg border border-[var(--border)] px-3.5 py-1.5 text-sm font-bold" onClick={() => setOfferDeleteId(0)}>Keep</button>
                        </>
                      ) : (
                        <button type="button" className="rounded-lg border border-red-500/50 px-3.5 py-1.5 text-sm font-bold text-red-500" onClick={() => setOfferDeleteId(o.id)}>Delete</button>
                      )}
                    </div>
                  </li>
                );
              })}
              {d.offers.length === 0 && <li className="text-sm text-[var(--dim)]">No offers yet — create the first one above.</li>}
            </ul>
          </div>
        );
      })()}

      {activeTab === "projects" && (
        <div className="mt-6 grid gap-6">
          <form
            className="grid gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-2"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const g = (k: string) => String(fd.get(k) ?? "");
              upsertProject.mutate({ id: null, title: g("title"), category: g("category"), location: g("location"), description: g("description"), is_demo: g("is_demo") === "on" });
              e.currentTarget.reset();
            }}
          >
            <div><label htmlFor="pj-title">Title</label><input id="pj-title" name="title" required /></div>
            <div>
              <label htmlFor="pj-cat">Category</label>
              <select id="pj-cat" name="category" defaultValue="electrical">
                <option value="electrical">Electrical Installations</option>
                <option value="plumbing">Plumbing Installations</option>
                <option value="residential">Residential Projects</option>
                <option value="commercial">Commercial Projects</option>
                <option value="industrial">Industrial Projects</option>
                <option value="bathroom">Bathroom Renovations</option>
                <option value="maintenance">Maintenance Projects</option>
              </select>
            </div>
            <div><label htmlFor="pj-loc">Location</label><input id="pj-loc" name="location" /></div>
            <label className="!mb-0 flex items-center gap-2 self-end pb-2 text-sm font-semibold text-[var(--text)]">
              <input type="checkbox" name="is_demo" defaultChecked className="!w-4" /> Demo / sample content
            </label>
            <div className="sm:col-span-2"><label htmlFor="pj-desc">Description</label><textarea id="pj-desc" name="description" rows={2} /></div>
            <div className="sm:col-span-2"><button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold">Add project</button></div>
          </form>
          <ul className="grid gap-3">
            {d.projects.map((p) => (
              <Row key={p.id}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">{p.title} {p.is_demo && <span className="rounded bg-amber-500/20 px-2 py-0.5 text-xs font-bold text-amber-500">DEMO</span>}</span>
                  <button type="button" className="rounded-lg border border-red-500/50 px-3 py-1.5 text-xs font-bold text-red-500" onClick={() => delProject.mutate({ id: p.id })}>Delete</button>
                </div>
                <p className="text-sm text-[var(--dim)]">{p.category} · {p.location} · {p.description}</p>
              </Row>
            ))}
            {d.projects.length === 0 && <p className="text-[var(--dim)]">No projects yet.</p>}
          </ul>
        </div>
      )}

      {activeTab === "reviews" && (
        <ul className="mt-6 grid gap-3">
          {d.reviews.map((r) => (
            <Row key={r.id}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-semibold">{"★".repeat(Math.round(r.rating))} {r.customer_name}</span>
                <button type="button" className={`rounded-lg px-3 py-1.5 text-xs font-bold ${r.approved ? "border border-[var(--border)]" : "btn-primary"}`}
                  onClick={() => moderate.mutate({ id: r.id, approved: !r.approved })}>
                  {r.approved ? "Unpublish" : "Approve & publish"}
                </button>
              </div>
              <p className="mt-1 text-sm">{r.body}</p>
              <p className="text-xs text-[var(--dim)]">{r.service_slug} · {new Date(r.created_at).toLocaleString()}</p>
            </Row>
          ))}
          {d.reviews.length === 0 && <p className="text-[var(--dim)]">No reviews submitted yet.</p>}
        </ul>
      )}

      {activeTab === "messages" && (
        <ul className="mt-6 grid gap-3">
          {d.messages.map((m) => (
            <Row key={m.id}>
              <span className="font-semibold">{m.subject || m.kind} — {m.name}</span>
              <span className="text-sm text-[var(--dim)]"> · {m.email}</span>
              <p className="mt-1 text-sm">{m.body}</p>
            </Row>
          ))}
          {d.messages.length === 0 && <p className="text-[var(--dim)]">No messages yet.</p>}
          <h3 className="mt-4 font-display text-lg font-bold">Notifications</h3>
          {d.notifications.slice(0, 15).map((n) => (
            <li key={n.id} className="rounded-xl bg-[var(--surface2)] px-4 py-3 text-sm">
              <span className="font-semibold">{n.title}</span> — {n.body}
              <span className="block text-xs text-[var(--dim)]">{n.email ?? "admin"} · {new Date(n.created_at).toLocaleString()}</span>
            </li>
          ))}
        </ul>
      )}

      {activeTab === "access" && (
        <div className="mt-6 grid gap-6">
          <p className="max-w-3xl text-sm text-[var(--dim)]">
            Staff accounts sign in on the dedicated Admin Login page (menu drawer or footer → “Admin Login”). There is no URL for the back office — adding #admin or anything else to the website address opens nothing.
            Roles are enforced on the server: <strong className="text-[var(--text)]">Admin</strong> manages everything, <strong className="text-[var(--text)]">Manager</strong> runs bookings/quotations/team (read-only team), <strong className="text-[var(--text)]">Technician</strong> sees only jobs assigned to the technician record linked here.
            Passwords are stored as salted PBKDF2 hashes and can never be read back — set a new one instead. You cannot change your own role, delete your own account, or remove the last active admin.
          </p>
          <form
            className="grid gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-3"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const g = (k: string) => String(fd.get(k) ?? "");
              upsertStaff.mutate({
                id: null,
                name: g("name"),
                email: g("email"),
                password: g("password"),
                role: g("role") as never,
                technician_id: g("technician_id") ? Number(g("technician_id")) : null,
                active: true,
              });
              e.currentTarget.reset();
            }}
          >
            <div><label htmlFor="sa-name">Name</label><input id="sa-name" name="name" required /></div>
            <div><label htmlFor="sa-email">Email (login)</label><input id="sa-email" name="email" type="email" required /></div>
            <div><label htmlFor="sa-pw">Password (min 10)</label><input id="sa-pw" name="password" type="password" minLength={10} required autoComplete="new-password" /></div>
            <div>
              <label htmlFor="sa-role">Role</label>
              <select id="sa-role" name="role" defaultValue="technician">
                <option value="admin">Admin</option>
                <option value="manager">Manager</option>
                <option value="technician">Technician</option>
              </select>
            </div>
            <div>
              <label htmlFor="sa-tech">Linked technician record (for Technician role)</label>
              <select id="sa-tech" name="technician_id" defaultValue="">
                <option value="">— none —</option>
                {d.technicians.map((t) => (
                  <option key={t.id} value={t.id}>{t.name} ({t.role})</option>
                ))}
              </select>
            </div>
            <div className="self-end">
              <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold" disabled={upsertStaff.isPending}>
                Create staff account {upsertStaff.isSuccess ? "✓" : ""}
              </button>
              {upsertStaff.isError && <p className="mt-1 text-xs font-semibold text-red-500" role="alert">Failed — check the email is not already used and the password is 10+ characters.</p>}
            </div>
          </form>
          <ul className="grid gap-3">
            {d.staff_users.map((su) => (
              <Row key={su.id}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">
                    {su.name} <span className="text-[var(--dim)]">· {su.email} · {su.role}{su.active ? "" : " · inactive"}{su.technician_id != null ? ` · linked: ${techName.get(su.technician_id) ?? su.technician_id}` : ""}</span>
                  </span>
                  <div className="flex gap-2">
                    <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-bold"
                      onClick={() => upsertStaff.mutate({ id: su.id, name: su.name, email: su.email, password: "", role: su.role as never, technician_id: su.technician_id, active: !su.active })}>
                      {su.active ? "Deactivate" : "Activate"}
                    </button>
                    {su.email !== session.email && (
                      <button type="button" className="rounded-lg border border-red-500/50 px-3 py-1.5 text-xs font-bold text-red-500" onClick={() => delStaff.mutate({ id: su.id })}>Delete</button>
                    )}
                  </div>
                </div>
                <form
                  className="mt-2 flex flex-wrap items-end gap-2"
                  onSubmit={(e) => {
                    e.preventDefault();
                    const fd = new FormData(e.currentTarget);
                    upsertStaff.mutate({ id: su.id, name: su.name, email: su.email, password: String(fd.get("password") ?? ""), role: su.role as never, technician_id: su.technician_id, active: su.active });
                    e.currentTarget.reset();
                  }}
                >
                  <div className="w-56">
                    <label htmlFor={`sapw-${su.id}`}>Set new password (min 10)</label>
                    <input id={`sapw-${su.id}`} name="password" type="password" minLength={10} required autoComplete="new-password" />
                  </div>
                  <button type="submit" className="rounded-lg border border-[var(--border)] px-3 py-2 text-xs font-bold">Save password</button>
                </form>
              </Row>
            ))}
            {d.staff_users.length === 0 && <p className="text-[var(--dim)]">No staff accounts found.</p>}
          </ul>
        </div>
      )}

      {activeTab === "settings" && (
        <>
        <form
          className="mt-6 grid gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            const out: Record<string, string> = {};
            fd.forEach((v, k) => (out[k] = String(v).trim()));
            saveSettings.mutate({ settings: out });
          }}
        >
          {/* ===== Website Settings — Branding (Report 23) ===== */}
          <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
            <h3 className="font-display font-black">Website Settings — Branding</h3>
            <p className="mt-1 text-sm text-[var(--dim)]">
              The public identity of the site. Leave a field empty to keep the built-in default
              (name “S SERVICES”, the translated tagline, the “S” brand tile). Everything here
              saves persistently and appears on the public website as soon as you save — no code
              change needed.
            </p>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="set-site-name">Website name</label>
                <input id="set-site-name" name="site_name" defaultValue={d.settings["site_name"] ?? ""} placeholder="S SERVICES" />
              </div>
              <div>
                <label htmlFor="set-site-tagline">Website tagline (shown under the name; one language — your main one)</label>
                <input id="set-site-tagline" name="site_tagline" defaultValue={d.settings["site_tagline"] ?? ""} placeholder="Professional Electrical & Plumbing Solutions" />
              </div>
              <div>
                <label htmlFor="set-theme">Default theme (colours — visitors can still switch among all 6 themes)</label>
                <select id="set-theme" name="default_theme" defaultValue={d.settings["default_theme"] || "electric"}>
                  {THEMES.map((th) => <option key={th.id} value={th.id}>{th.nameEn}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="set-logo-file">Website logo — upload / change</label>
                <input type="hidden" name="site_logo" value={logoVal ?? (d.settings["site_logo"] ?? "")} />
                {(logoVal ?? (d.settings["site_logo"] ?? "")) ? (
                  <div className="flex flex-wrap items-center gap-3">
                    <img src={logoVal ?? (d.settings["site_logo"] ?? "")} alt="Current website logo" className="h-10 w-auto max-w-[150px] rounded-lg bg-white/10 object-contain p-1" />
                    <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-sm font-semibold" onClick={() => setLogoVal("")}>
                      Remove logo
                    </button>
                  </div>
                ) : (
                  <p className="text-sm text-[var(--dim)]">No logo uploaded — the site shows the built-in “S” brand tile.</p>
                )}
                <input
                  id="set-logo-file"
                  type="file"
                  accept="image/*"
                  className="mt-2"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) fileToScaledDataUrl(f, 256).then(setLogoVal).catch(() => {});
                    e.target.value = "";
                  }}
                />
                <p className="mt-1 text-xs text-[var(--dim)]">The image is resized in your browser (max 256 px) and stored with the site settings; after saving it appears in the header, the menu drawer and the footer.</p>
              </div>
              <div>
                <label htmlFor="set-favicon-file">Favicon — upload / change (browser tab icon)</label>
                <input type="hidden" name="site_favicon" value={faviconVal ?? (d.settings["site_favicon"] ?? "")} />
                {(faviconVal ?? (d.settings["site_favicon"] ?? "")) ? (
                  <div className="flex flex-wrap items-center gap-3">
                    <img src={faviconVal ?? (d.settings["site_favicon"] ?? "")} alt="Current favicon" className="h-8 w-8 rounded bg-white/10 object-contain p-0.5" />
                    <button type="button" className="rounded-lg border border-[var(--border)] px-3 py-1.5 text-sm font-semibold" onClick={() => setFaviconVal("")}>
                      Remove favicon
                    </button>
                  </div>
                ) : (
                  <p className="text-sm text-[var(--dim)]">No favicon uploaded — the logo above is used as the tab icon when one is set.</p>
                )}
                <input
                  id="set-favicon-file"
                  type="file"
                  accept="image/*"
                  className="mt-2"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) fileToScaledDataUrl(f, 64).then(setFaviconVal).catch(() => {});
                    e.target.value = "";
                  }}
                />
                <p className="mt-1 text-xs text-[var(--dim)]">A small square image works best; it is resized to 64 px and applied as the browser tab icon.</p>
              </div>
            </div>
          </section>

          {/* ===== Website Settings — Website content (Report 23) ===== */}
          <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
            <h3 className="font-display font-black">Website Settings — Homepage &amp; website content</h3>
            <p className="mt-1 text-sm text-[var(--dim)]">
              Editable public copy. The headline fields are single-language (shown as written, in
              every language) — leave them empty to keep the fully translated built-in texts.
              Services are managed in the <strong className="text-[var(--text)]">Services tab</strong> (names, categories, prices,
              publish/unpublish); their long descriptions stay catalogue-managed so the 11-language
              translations stay intact. Service areas are managed in the map section below and the
              <strong className="text-[var(--text)]"> Service Areas tab</strong>.
            </p>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="set-hero-title">Homepage headline (hero)</label>
                <input id="set-hero-title" name="hero_title" defaultValue={d.settings["hero_title"] ?? ""} placeholder="Built-in translated headline" />
              </div>
              <div>
                <label htmlFor="set-hero-sub">Homepage sub-headline (hero)</label>
                <input id="set-hero-sub" name="hero_sub" defaultValue={d.settings["hero_sub"] ?? ""} placeholder="Built-in translated sub-headline" />
              </div>
              <div>
                <label htmlFor="set-about-it">About Us text (Italiano)</label>
                <textarea id="set-about-it" name="about_it" rows={3} defaultValue={d.settings["about_it"] ?? ""} />
              </div>
              <div>
                <label htmlFor="set-about-en">About Us text (English)</label>
                <textarea id="set-about-en" name="about_en" rows={3} defaultValue={d.settings["about_en"] ?? ""} />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="set-footer-text">Footer text (leave empty for the built-in translated note)</label>
                <textarea id="set-footer-text" name="footer_text" rows={2} defaultValue={d.settings["footer_text"] ?? ""} />
              </div>
              {([
                ["social_facebook", "Facebook page URL"],
                ["social_instagram", "Instagram profile URL"],
                ["social_youtube", "YouTube channel URL"],
                ["social_linkedin", "LinkedIn page URL"],
              ] as const).map(([key, label]) => (
                <div key={key}>
                  <label htmlFor={`set-${key}`}>{label} (shown in the footer when filled)</label>
                  <input id={`set-${key}`} name={key} defaultValue={d.settings[key] ?? ""} placeholder="https://…" />
                </div>
              ))}
            </div>
          </section>

          {/* ===== Website Settings — Contact & WhatsApp (Report 23) ===== */}
          <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
            <h3 className="font-display font-black">Website Settings — Contact information &amp; WhatsApp</h3>
            <p className="mt-1 text-sm text-[var(--dim)]">
              Business phone, WhatsApp, email, address and opening hours, shown on the Contact
              page, the homepage map card and the footer. Nothing is invented: a field left empty
              simply does not appear on the public site.{" "}
              <strong className="text-[var(--text)]">
                {(d.settings["company_whatsapp"] ?? "").trim()
                  ? `WhatsApp is configured (${d.settings["company_whatsapp"]}) — the floating WhatsApp button and all WhatsApp links use this number.`
                  : "⚠ WhatsApp number is NOT configured — the floating WhatsApp button stays hidden until you enter the number here and save."}
              </strong>
            </p>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              {([
                ["company_phone", "Business phone number (click-to-call)"],
                ["company_whatsapp", "WhatsApp number (international format, es. +39…)"],
                ["company_email", "Business email"],
                ["company_address", "Business address"],
                ["company_hours", "Opening hours (shown on Contact, homepage map card and footer)"],
                ["contact_availability", "Contact availability note (es. response times, areas covered)"],
                ["emergency_enabled", "Emergency availability note (leave empty = not advertised)"],
                ["emergency_note", "Emergency response note"],
              ] as const).map(([key, label]) => (
                <div key={key}>
                  <label htmlFor={`set-${key}`}>{label}</label>
                  <input id={`set-${key}`} name={key} defaultValue={d.settings[key] ?? ""} />
                </div>
              ))}
            </div>
          </section>

          {/* ===== Hero video sources ===== */}
          <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
            <h3 className="font-display font-black">Hero video sources</h3>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="set-hero_video_url">Hero video 1 URL — Electrical (MP4/WebM, licensed footage)</label>
                <input id="set-hero_video_url" name="hero_video_url" defaultValue={d.settings["hero_video_url"] ?? ""} />
              </div>
              <div>
                <label htmlFor="set-hero_video_url_2">Hero video 2 URL — Plumbing (MP4/WebM, licensed footage)</label>
                <input id="set-hero_video_url_2" name="hero_video_url_2" defaultValue={d.settings["hero_video_url_2"] ?? ""} />
              </div>
              <div>
                <label htmlFor="set-hero-mode">Hero videos — which clips play in the homepage hero</label>
                <select id="set-hero-mode" name="hero_video_mode" defaultValue={d.settings["hero_video_mode"] || "builtin"}>
                  <option value="builtin">Built-in Pexels pair — electrical “Person Fixing Wires”, then plumbing “A Person doing Plumbing”</option>
                  <option value="custom">My own video URLs (the two fields above)</option>
                  <option value="off">No hero video — photo hero only (videos removed)</option>
                </select>
              </div>
            </div>
          </section>
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface2)] p-4 sm:col-span-2">
            <h3 className="font-display text-sm font-black">Floating emergency buttons (Call / WhatsApp)</h3>
            <p className="mt-1 text-sm text-[var(--dim)]">
              Two buttons float at the bottom corner of every public page (never inside this back office). Each one appears
              <strong className="text-[var(--text)]"> only when its number above is filled in</strong> — Company phone for Call, WhatsApp number for WhatsApp — and its switch below is on.
              No number is ever invented: leave a number empty and its button simply does not exist on the site.
            </p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div>
                <label htmlFor="set-float-msg">WhatsApp prefilled message (optional)</label>
                <input id="set-float-msg" name="float_whatsapp_message" defaultValue={d.settings["float_whatsapp_message"] ?? ""} placeholder="Es. Emergenza: ho bisogno di un intervento urgente" />
              </div>
              <div className="grid gap-2 self-end">
                <label className="!mb-0 flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
                  <input type="hidden" name="float_call_enabled" value="0" />
                  <input type="checkbox" name="float_call_enabled" value="1" defaultChecked={(d.settings["float_call_enabled"] ?? "1") !== "0"} className="!w-4" />
                  Show floating Call button
                </label>
                <label className="!mb-0 flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
                  <input type="hidden" name="float_whatsapp_enabled" value="0" />
                  <input type="checkbox" name="float_whatsapp_enabled" value="1" defaultChecked={(d.settings["float_whatsapp_enabled"] ?? "1") !== "0"} className="!w-4" />
                  Show floating WhatsApp button
                </label>
              </div>
            </div>
            <p className="mt-2 text-xs text-[var(--dim)]">
              Status today: phone {(d.settings["company_phone"] ?? "").trim() ? `set (${d.settings["company_phone"]})` : "NOT set — Call button hidden"} ·
              WhatsApp {(d.settings["company_whatsapp"] ?? "").trim() ? `set (${d.settings["company_whatsapp"]})` : "NOT set — WhatsApp button hidden"} ·
              switches: call {(d.settings["float_call_enabled"] ?? "1") !== "0" ? "on" : "off"}, WhatsApp {(d.settings["float_whatsapp_enabled"] ?? "1") !== "0" ? "on" : "off"}.
            </p>
          </div>
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface2)] p-4 sm:col-span-2">
            <h3 className="font-display text-sm font-black">Interactive service-area map</h3>
            <p className="mt-1 text-sm text-[var(--dim)]">
              The public homepage and the Service Areas page show an interactive map with a marker on the company's base and a
              coloured circle for the service radius. Visitors can zoom and pan it. The map is rendered by the platform's built-in
              map service — <strong className="text-[var(--text)]">no Google Maps API key is required and none is used</strong>; Google Maps is only
              used for the outbound “Directions” link. If the map service is ever unavailable, the site shows the address, radius and
              directions button instead — it never breaks.
            </p>
            <p className="mt-2 text-sm text-[var(--dim)]">
              Until you save real coordinates below, the site shows a clearly labelled <strong className="text-[var(--text)]">DEMO location (Rome, 25 km)</strong> —
              it is never presented as the company's real base. Fill in the real base, set the radius, switch “Demo location” off and save.
            </p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div>
                <label htmlFor="set-map-name">Base name (marker label)</label>
                <input id="set-map-name" name="map_name" defaultValue={d.settings["map_name"] ?? ""} placeholder="Es. S SERVICES — Milano" />
              </div>
              <div>
                <label htmlFor="set-map-address">Base address (shown under the map)</label>
                <input id="set-map-address" name="map_address" defaultValue={d.settings["map_address"] ?? ""} placeholder="Es. Via Roma 1, 20121 Milano MI" />
              </div>
              <div>
                <label htmlFor="set-map-lat">Latitude (decimal, es. 45.4642)</label>
                <input id="set-map-lat" name="map_lat" inputMode="decimal" defaultValue={d.settings["map_lat"] ?? ""} placeholder="41.9028 = Roma (demo)" />
              </div>
              <div>
                <label htmlFor="set-map-lng">Longitude (decimal, es. 9.1900)</label>
                <input id="set-map-lng" name="map_lng" inputMode="decimal" defaultValue={d.settings["map_lng"] ?? ""} placeholder="12.4964 = Roma (demo)" />
              </div>
              <div>
                <label htmlFor="set-map-radius">Service radius (km)</label>
                <input id="set-map-radius" name="map_radius_km" type="number" min="1" max="500" step="1" defaultValue={d.settings["map_radius_km"] ?? ""} placeholder="25" />
              </div>
              <div>
                <label htmlFor="set-map-demo">Demo location</label>
                <select id="set-map-demo" name="map_is_demo" defaultValue={d.settings["map_is_demo"] ?? "1"}>
                  <option value="1">DEMO — labelled as a demonstration location</option>
                  <option value="0">Real company base (demo label removed)</option>
                </select>
              </div>
            </div>
            <p className="mt-2 text-xs text-[var(--dim)]">
              Status today: {(d.settings["map_lat"] ?? "").trim() && (d.settings["map_lng"] ?? "").trim()
                ? `saved coordinates ${d.settings["map_lat"]}, ${d.settings["map_lng"]} · radius ${d.settings["map_radius_km"] || "25"} km · ${(d.settings["map_is_demo"] ?? "1") !== "0" ? "still flagged DEMO" : "shown as the real base"}`
                : "no coordinates saved — the public site shows the DEMO location (Rome, 41.9028 / 12.4964, 25 km), clearly labelled DEMO."}
            </p>
          </div>
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface2)] p-4 sm:col-span-2">
            <h3 className="font-display text-sm font-black">Hero videos — alternating electrical / plumbing, and scroll-scrub</h3>
            <p className="mt-2 text-sm text-[var(--dim)]">
              Two built-in clips ship with the site (Pexels, free licence, chosen by the owner) and alternate in the homepage hero —
              electrical first, then plumbing, with a smooth crossfade, muted:
              {" "}<a className="font-semibold text-[var(--accent)] underline" href="https://www.pexels.com/video/person-fixing-wires-6079417/" target="_blank" rel="noreferrer">“Person Fixing Wires” (0:16)</a>
              {" "}and{" "}
              <a className="font-semibold text-[var(--accent)] underline" href="https://www.pexels.com/video/a-person-doing-plumbing-7584762/" target="_blank" rel="noreferrer">“A Person doing Plumbing” (0:20)</a>.
              The first clip also drives the cinematic film section as true scroll-scrub (scroll down advances it, scroll up rewinds it).
              If a clip fails to load, the hero falls back to the photo slideshow and the film to the photo sequence. Reduced-motion visitors see the static photo hero instead of video.
            </p>
            <ol className="mt-2 list-decimal space-y-1 ps-5 text-sm text-[var(--dim)]">
              <li>Stay in <strong className="text-[var(--text)]">Admin → Settings</strong> (this tab) to change or remove the clips.</li>
              <li>The <strong className="text-[var(--text)]">“Hero videos” selector</strong> above decides what plays: <strong className="text-[var(--text)]">Built-in Pexels pair</strong> (the two clips named here, electrical → plumbing), <strong className="text-[var(--text)]">My own video URLs</strong>, or <strong className="text-[var(--text)]">No hero video</strong> — that last option removes hero video entirely and the hero shows photos only.</li>
              <li>For your own clips: paste the full URL of <em>your own licensed</em> MP4 or WebM file (hosted on your server/CDN) into <strong className="text-[var(--text)]">“Hero video 1 URL — Electrical”</strong> and/or <strong className="text-[var(--text)]">“Hero video 2 URL — Plumbing”</strong>, set the selector to “My own video URLs”, and click <strong className="text-[var(--text)]">Save settings</strong>. The hero then plays exactly the saved URL(s), in order; clearing one field removes just that clip.</li>
              <li>Do not paste a YouTube/Vimeo page link and do not use unlicensed stock footage.</li>
              <li>Set the selector back to “Built-in Pexels pair” and save to restore the built-in clips.</li>
              <li>To test: open the homepage and watch the hero alternate between the two clips; then scroll slowly down and up through the film section and check the % counter moves with the first clip's playback.</li>
            </ol>
            <p className="mt-2 text-xs text-[var(--dim)]">
              Status today: {(() => {
                const mode = (d.settings["hero_video_mode"] ?? "builtin").trim() || "builtin";
                const urls = [d.settings["hero_video_url"], d.settings["hero_video_url_2"]].map((u) => (u ?? "").trim()).filter(Boolean);
                if (mode === "off") return "hero videos are set to OFF — the homepage hero shows the photo slideshow only and the film section uses its photo sequence. Set the “Hero videos” selector above to bring videos back.";
                if (mode === "custom") return urls.length > 0
                  ? <>custom mode: the homepage hero alternates through your saved URL(s) ({urls.map((u) => <span key={u} className="break-all font-semibold text-[var(--text)]">{u} </span>)}) and the film section scroll-scrubs the first one, with automatic photo fallback if a file fails to load. Verify each is your licensed file, then test the hero and film in both scroll directions.</>
                  : "custom mode is selected but no URL is saved in either field, so no video plays — the hero shows photos and the film uses its photo sequence. Paste a licensed URL into at least one field and save, or switch back to the built-in pair.";
                return "the configured hero videos are the two built-in Pexels clips — electrical “Person Fixing Wires” first, then plumbing “A Person doing Plumbing”, alternating with a crossfade — and the film section scroll-scrubs the built-in electrical clip. Use the “Hero videos” selector and the two URL fields above to replace or remove them.";
              })()}
            </p>
          </div>
          {/* ===== Site defaults ===== */}
          <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
            <h3 className="font-display font-black">Site defaults</h3>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="set-lang">Default language</label>
                <select id="set-lang" name="default_language" defaultValue={d.settings["default_language"] || "it"}>
                  <option value="it">Italiano</option>
                  <option value="en">English</option>
                </select>
              </div>
              <div>
                <label htmlFor="set-cur">Default currency</label>
                <select id="set-cur" name="default_currency" defaultValue={d.settings["default_currency"] || "EUR"}>
                  {CURRENCIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
          </section>
          <div>
            <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold" disabled={saveSettings.isPending}>
              Save settings {saveSettings.isSuccess ? "✓" : ""}
            </button>
            {saveSettings.isSuccess && (
              <span className="ms-3 text-sm font-semibold text-emerald-500" role="status">Settings saved — the public site now reads the new values (branding, content, contact &amp; WhatsApp, map, hero video).</span>
            )}
            {saveSettings.isError && (
              <span className="ms-3 text-sm font-semibold text-red-500" role="alert">Saving failed — please try again.</span>
            )}
          </div>
        </form>
        <TechnicalSettings d={d} />
        </>
      )}

      {activeTab === "reports" && <Reports d={d} />}
    </div>
  );
}

/* Technical settings (Report 23): a read-only, SAFE view of the
   site's current configuration. It deliberately shows no API keys,
   no database credentials and no environment variables — none are
   stored in, or readable from, this panel. Domain registration, DNS
   and hosting are managed by the external platform provider and
   cannot be changed from here; the panel says so plainly instead of
   pretending otherwise. */
function TechnicalSettings({ d }: { d: All }) {
  const s = d.settings;
  const rows: [string, string][] = [
    ["Admin Login access", "There is NO URL or hash route to the back office: adding #admin (or anything else) to the website address opens nothing — it only loads the public website, and the dead fragment is removed from the address bar. The back office opens solely from the “Admin Login” item in the site's menu drawer / footer, which shows the dedicated Admin Login page. The dashboard renders only after the server verifies a valid staff session and its role (staffVerifySession); on sign-out the server session is deleted and all cached dashboard data is cleared, so refresh, browser history and previously opened links cannot bring the dashboard back."],
    ["First-admin setup", "One-time only, and locked on the server to the single administrator email the owner authorized. Once the first account exists, setup closes permanently; further staff accounts are created in the Staff Access tab."],
    ["Website name", (s["site_name"] ?? "").trim() || "S SERVICES (built-in default)"],
    ["Logo / favicon", `${(s["site_logo"] ?? "").trim() ? "Custom logo uploaded" : "Built-in “S” brand tile"} · ${(s["site_favicon"] ?? "").trim() ? "Custom favicon uploaded" : "No custom favicon"}`],
    ["Default theme / language / currency", `${s["default_theme"] || "electric"} · ${s["default_language"] || "it"} · ${s["default_currency"] || "EUR"} (6 themes and 11 languages are built in; visitors keep their own choice)`],
    ["Hero videos", `Mode: ${(s["hero_video_mode"] ?? "builtin").trim() || "builtin"}${(s["hero_video_mode"] ?? "") === "custom" ? ` — custom URL(s): ${[s["hero_video_url"], s["hero_video_url_2"]].map((x) => (x ?? "").trim()).filter(Boolean).join(" · ") || "none saved"}` : " — built-in licensed Pexels pair"}`],
    ["Service-area map", (s["map_lat"] ?? "").trim() && (s["map_lng"] ?? "").trim()
      ? `Saved base ${s["map_lat"]}, ${s["map_lng"]} · radius ${s["map_radius_km"] || "25"} km · ${(s["map_is_demo"] ?? "1") !== "0" ? "flagged DEMO" : "real base"}`
      : "No coordinates saved — the public site shows the labelled DEMO location (Rome, 25 km)"],
    ["WhatsApp", (s["company_whatsapp"] ?? "").trim()
      ? `Configured: ${s["company_whatsapp"]} · floating button ${(s["float_whatsapp_enabled"] ?? "1") !== "0" ? "ON" : "OFF"}`
      : "NOT configured — the floating WhatsApp button is hidden on the public site until a number is saved above"],
    ["Floating call button", (s["company_phone"] ?? "").trim()
      ? `Number set (${s["company_phone"]}) · ${(s["float_call_enabled"] ?? "1") !== "0" ? "ON" : "OFF"}`
      : "No phone number set — button hidden"],
    ["Live content right now", `${d.services.length} services (${d.services.filter((x) => x.published).length} published) · ${d.bookings.length} bookings · ${d.quote_requests.length} quote requests · ${d.customers.length} customers · ${d.offers.length} offers · ${d.staff_users.length} staff accounts`],
    ["Where settings live", "Every value on this page is stored in the site's own settings store and is applied to the public website the moment you save — no code change or redeploy is needed."],
    ["Domain, DNS & hosting — NOT managed here", "This website runs on the Muse web platform: the domain registration, DNS records and hosting are controlled by that external platform/provider account, NOT from this Admin Panel, and this panel cannot change them. To change the domain or DNS, sign in to the account of the provider where the domain is registered / the site is hosted and edit the records there; the website content managed here is unaffected by DNS changes."],
    ["Secrets", "API keys, database credentials and private environment variables are never stored in these settings and are never displayed in this panel or anywhere in the Admin Dashboard."],
  ];
  return (
    <section className="mt-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
      <h3 className="font-display font-black">Technical settings — current configuration (read-only)</h3>
      <p className="mt-1 text-sm text-[var(--dim)]">
        A safe summary of how the site is configured right now. To change any value, use the
        Website Settings sections above (or the dedicated tabs); this panel only reports.
      </p>
      <dl className="mt-3 grid gap-2">
        {rows.map(([k, v]) => (
          <div key={k} className="grid gap-0.5 rounded-xl bg-[var(--surface2)] px-3 py-2.5 sm:grid-cols-[220px_1fr] sm:gap-3">
            <dt className="text-sm font-bold">{k}</dt>
            <dd className="break-words text-sm text-[var(--dim)]">{v}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

function Reports({ d }: { d: All }) {
  const reports: [string, string, string][] = [
    ["1. Website Quality Report", d.bookings.length >= 0 ? "Completed" : "", "Responsive mobile-first layout: audit captures at phone (390px) and desktop (1440px) show the wrapping header and admin tab strip with 0px page-level horizontal overflow; tablet widths (768px and 1024px) run the identical wrapping layout with service grids stepping 1 → 2 (≥640px) → 3 (≥1024px) columns and full-viewport sticky scrollytelling stages — the tablet method and its capture limitation are recorded honestly in Report 14. All forms wired to the real backend; SEO meta + LocalBusiness schema in index.html; no placeholder sections — empty datasets render honest empty states."],
    ["2. Animation & Scrollytelling Testing Report", "Completed (rechecked both directions)", "Five cinematic features rechecked down AND up: (1) canvas film sequence scrub, (2) pinned 5-scene story with zoom/parallax/captions, (3) horizontal journey driven by vertical scroll, (4) Three.js pipe/valve/bolt rotation scrubbed by scroll, (5) heading parallax + progress bars. Native scrolling only — Lenis is NOT used (it froze scrolling in this shell and stays removed). Reduced-motion visitors get a fully static layout with a controllable video player. Plus Ken Burns hero, reveals, marquee, counters and emergency pulse."],
    ["3. Video Background & Scrub Testing Report", "Completed — two licensed Pexels clips built in (see Report 16)", "The hero now plays two real videos, downloaded from Pexels under its free licence and stored in the site itself: electrical “Person Fixing Wires” (0:16, 1920×1080) first, then plumbing “A Person doing Plumbing” (0:20, 1920×1080), alternating with a smooth crossfade, muted, with the photo slideshow underneath as poster fallback and a static photo hero under reduced motion. The cinematic film section drives the first clip's currentTime from scroll position in both directions (scroll-scrub), with automatic fallback to the photo sequence if the file fails to load. Admin → Settings → Hero video holds a mode selector plus two URL slots (electrical / plumbing): 'Built-in Pexels pair' plays the stored clips, 'My own video URLs' plays exactly the saved licensed MP4/WebM URL(s) (a cleared slot removes that clip), and 'No hero video' removes hero video entirely, leaving the photo hero."],
    ["4. Multi-Theme Testing Report", "Completed", "Six themes × light/dark/system modes via CSS variables; selection persists per visitor; admin sets the site default. Contrast pairs defined per theme."],
    ["5. Multilingual Testing Report", "Completed — live evidence in Report 14", "11 languages with persistent preference and full RTL for Arabic and Urdu. Cinematic/scrollytelling sections AND the long-form service pages are fully translated in ALL 11 languages (IT, EN, EN-GB, FR, DE, ES, PT, NL, TR, AR, UR) with no Italian fallback: all 42 service descriptions, all 42 service names, the What's Included list, the How We Work steps, the Safety text, all 6 FAQs and every interface dictionary key have a dedicated translation per language, faithful to the Italian/English masters (same meaning, same service details). The interface dictionaries no longer inherit Italian defaults — the only safety fallback left in code is English. Verify it live in Report 14 below: counts are computed at runtime from the shipped translation data, with French, German and Arabic (RTL) samples from a real service detail page."],
    ["6. Booking System Testing Report", "Completed", "Real availability check: the server rejects a second active booking for the same date+slot (slot_taken) and the form disables taken slots. Emergency requests bypass slots and are flagged priority. Seven booking statuses implemented."],
    ["7. Admin & Manager Permissions Report", "Completed", "Role views: Admin (all modules), Manager (overview, bookings, quotations, team), Technician (only own assigned jobs, status + work notes). Public sign-up never creates admin records; customers see only their own email's records in the portal."],
    ["8. Database & Backend Report", "Completed", `Relational SQLite via Drizzle: services (${d.services.length}), bookings (${d.bookings.length}), quote requests (${d.quote_requests.length}), quotations (${d.quotations.length}), invoices (${d.invoices.length}), customers (${d.customers.length}), technicians (${d.technicians.length}), areas (${d.areas.length}), projects, reviews, messages, notifications, settings, activity log (${d.activity.length} entries).`],
    ["9. Security Testing Report", "Partial", "Server-side validation on every action (zod), customer data isolation by email in the portal, reviews publish only after moderation, audit log on every mutation. Password authentication, email verification and payment processing are not active: they require the company's identity/payment provider credentials."],
    ["10. Remaining Issues Report", "Open items", "Still waiting on the company (nothing below was faked or auto-filled): (a) phone/WhatsApp/email/address in Settings; (b) activated service areas; (c) real project photos/records and approved reviews; (d) payment/identity provider credentials for online payment and password login. The former hero-video item is closed: the owner supplied two licensed Pexels clips, now built in and alternating in the hero (Report 16)."],
    ["11. Mobile Header, Stats, Accessibility & Performance — Fresh Check (Nov 2026)", "Completed", "Mobile header fixed: the top bar wraps, the tagline hides below 480px, language/theme/emergency controls compact, and the main nav wraps onto multiple rows instead of scrolling sideways; page-level overflow-x is clipped. Stats counters verified to settle exactly on their true values — published services count (42 when all published), 11 languages, 6 themes, and the live active-areas count — with no negative or overshoot values and instant settle under reduced motion. Accessibility: story progress no longer hides its buttons from assistive tech, the active scene aria-hidden state follows scroll, visible focus outlines added, reduced-motion disables looping/transition motion globally. Performance/images: all content images are owned local files, lazy-loaded (except the first hero/scene frames) with async decoding, canvas DPR capped at 1.75 and the 3D renderer pauses off-screen."],
    ["12. Fresh Testing Summary — Completed / Tested / Remaining", "See detail", "COMPLETED & TESTED in code and build: mobile header wrap fix; full 11-language cinematic copy with no Italian fallback; native-scroll scrollytelling (all five features, both directions by construction — scrub is a pure function of scroll progress); stats settle values; reduced-motion static layout; Settings instructions for the hero video. PREPARED BUT NOT LIVE-TESTED: real-video scrub (needs your licensed URL in Admin → Settings). REMAINING (needs company input, see Report 10): contact details, service areas, real projects/reviews, payment/login credentials. Nothing in this list is marked complete without implementation."],
    ["13. Final Verification Phase (Nov 2026) — Tablet, Admin Tabs, Hero Video Save, Service Translations", "Completed · video scrub still PENDING", "TABLET: the layout system is breakpoint-driven (grids step at 640px and 1024px, the header and admin tab strip wrap instead of scrolling sideways), so 768px and 1024px widths render the wrapped tablet layout; dedicated live checks at both tablet widths were still outstanding at the end of that phase and are closed in Report 14. ADMIN TABS FIXED: the tab strip previously scrolled horizontally, pushing Settings and Reports off-viewport; it now wraps onto multiple rows at every width, so Settings and Reports are always directly reachable — role permissions unchanged (Admin sees all tabs, Manager a subset, Technician only My Jobs). HERO VIDEO SAVE: the Settings save path (adminSaveSettings → settings table → public getState) was round-trip verified in the isolated verification database — a test value was saved, read back identically in Admin and in the public state, then cleared — so a URL saved here is exactly what the homepage hero (autoplay background, photo fallback on load error) and the cinematic film (scroll-scrubbed currentTime, photo-sequence fallback on error) consume. No licensed URL is configured on the live site: real-video scrub remains PENDING, not tested, exactly as Report 3 states. SERVICE TRANSLATIONS: long-form service content completed in all 11 languages (see Report 5). Nothing was invented: no contact details, reviews, projects, service areas or certifications were added."],
    ["14. Verification Evidence — Tablet & Translations (Nov 2026)", "Translations verified live · tablet by construction (see note)", "TABLET (768px / 1024px): what was verified — at 768px the layout is in the ≥640px regime (two-column service grids, header and admin tab strip wrapped, sticky full-viewport cinematic stages) and at 1024px in the ≥1024px regime (three-column grids); no element between those breakpoints has a fixed width that can exceed the viewport (containers are fluid max-w-6xl, journey cards cap at max-w-sm, overflow-x is clipped), and the audit captures at the neighbouring widths (390px phone, 1440px desktop) both show 0px page-level overflow with the same wrapping system. LIMITATION, stated plainly: the audit harness only captures phone and desktop viewports, and a direct headless attempt at 768px/1024px was refused by the capture proxy, so no standalone tablet screenshot exists — tablet is therefore recorded as verified-by-construction, NOT as capture-verified, and Report 1 says the same. TRANSLATIONS: the panel directly below is computed at runtime from the exact translation data this page shipped with — per language it counts the 42 service descriptions, the 42 service names and the 6 FAQs, and counts how many strings are byte-identical to the Italian master (Italian leak — must be 0 outside Italian itself). It also prints the live French, German and Arabic (RTL) name + description of one real service, matching what its detail page renders; all three detail pages were additionally opened live in the audit session (French and German titles, descriptions, included/process/safety sections fully translated; Arabic fully translated with correct RTL mirroring). Spot-check yourself: switch the site language to Français, Deutsch or العربية, open any service, and compare."],
    ["15. Desktop Black-Preview Investigation & Rendering Hardening (Nov 2026)", "Fixed — fallbacks in place, desktop re-verified in audit", "REPORT: on a desktop laptop the preview rendered completely black while the same site opened correctly on mobile. CAUSE: the site had no error boundary and no per-system rendering fallbacks. On desktop machines whose GPU/driver is WebGL-blocklisted (the audit console itself logs software-WebGL fallback warnings), a failure inside the cinematic module — WebGL context creation for the Three.js scene is the known trigger class — propagated and unmounted the entire React tree, leaving only the dark page background: a black screen. Mobile takes different code paths (no desktop GPU blocklist, static/reduced paths) and rendered normally. The scroll-film stage had a second black-screen vector: it painted pure black until its first canvas frame decoded, with nothing underneath. FIXES — no animation was removed or permanently disabled; each system now degrades gracefully on its own: (1) a ScrollyBoundary error boundary wraps the cinematic module, so a cinematic crash degrades to a static film section and the rest of the site (hero, services, booking, portals) always renders; (2) Three.js now preflights WebGL with a probe context before creating the renderer — if WebGL is unavailable, or the live context is lost mid-session (webglcontextlost), the 3D section swaps to its photo fallback; (3) the film canvas now sits over a poster photograph and only fades in once a real frame has drawn — if the 2D context is unavailable or every sequence image fails to load, the poster stays and the section is never a black slab; (4) if GSAP/ScrollTrigger itself fails to initialise, partial triggers are killed and the module falls back to its fully static layout instead of broken pinned stages; (5) the hero and film video error fallbacks (photo slideshow / photo sequence on video error) were already present and remain. VERIFICATION: after this change the audit probe rendered the desktop page at 1440px and mobile at 390px with the full page visible (hero, film, story, journey, 3D, services) and no console errors; the 3D and film sections were scrolled in-session. 1366px sits between the 1024px and 1440px breakpoints with no intermediate layout regime, so it shares the 1440px rendering verified here; the audit harness offers no dedicated 1366px viewport, so that width is verified by breakpoint construction, not by a separate capture — stated plainly rather than claimed."],
    ["16. Hero Videos — Alternating Pexels Pair (Nov 2026)", "Completed — built in, replaces the PENDING status in Reports 3/12/13", "The owner chose both recommended Pexels clips ('use both / alternate'). Both MP4s were downloaded from Pexels (free licence) at 1920×1080 HD and are stored in the site itself — electrical 'Person Fixing Wires' (6079417, 0:16, 24fps, H.264) and plumbing 'A Person doing Plumbing' (7584762, 0:20, 25fps, H.264); file integrity, codec, dimensions, frame rate and duration were verified at build time. HOMEPAGE HERO: the two clips alternate — electrical plays first, plumbing follows, then back — as stacked muted playsInline videos with a 1s opacity crossfade; the dots under the hero switch clips manually. The photo slideshow always renders underneath as the poster fallback: it shows instantly, takes over if every video errors, and is the only hero media under prefers-reduced-motion (no video is played at all). A clip that errors is skipped for the next one. SCROLL-SCRUB: the film section's scrub source is now the first hero clip (the built-in electrical video by default), so real-video scrub is live and no longer pending; its photo-sequence fallback on video error is unchanged. ADMIN: Settings → Hero video now shows the configured configuration explicitly — a 'Hero videos' selector (Built-in Pexels pair / My own video URLs / No hero video — photo hero only) naming both built-in clips, two URL slots (Hero video 1 — Electrical, Hero video 2 — Plumbing), and a status line naming the active configuration. In 'My own video URLs' mode the hero plays exactly the saved URL(s) in order and clearing a slot removes that clip; 'No hero video' removes hero video entirely; switching back to 'Built-in Pexels pair' restores the stored clips. No other page, the database schema, authentication or permissions changed, and Lenis remains absent."],
    ["17. View-Not-Loading Fix — Video Weight & Blank-Page Hardening (Nov 2026)", "Fixed — media compressed, blank-view paths closed", "REPORT: opening the S SERVICES view could sit on a black/blank screen that never finished loading. EVIDENCE: a fresh render inspection of the running site showed the page itself healthy (full content, zero console errors), but it NEVER reached a settled state — network activity stayed open for the entire capture on desktop and mobile, with 15–16s loads. Root cause: the page eagerly streamed ~19.5MB of hero video before it could settle — both hero clips at 1920×1080 with preload=auto (the 20s plumbing clip alone was 14MB), with the electrical clip additionally streamed by the cinematic film section as its scroll-scrub source. On a slow or metered connection the view therefore appears stuck on black indefinitely. Two structural gaps made it worse: (1) the scroll-film stage, when driven by a real video, painted nothing but the video element over a bg-black stage — no photograph underneath — so a stalled or undecodable video WAS a black stage (the poster-only-underlay protection added in Report 15 covered only the photo-sequence branch); (2) there was no error boundary around the app root and no recovery if the JS bundle itself failed before first render — either failure left a permanent dark void with no message and no way back. FIXES: (a) both built-in clips re-encoded for the web — 1280px wide, CRF 30, faststart, audio stripped, 1s keyframes on the scrubbed electrical clip — 5.4MB → ~1.9MB and 13.4MB → ~3.4MB at build time (same Pexels clips, same licence, same content); the hero now only fully preloads the clip that is playing (the other loads metadata only until it becomes active). (b) The film stage now keeps the hero photograph as a permanent underlay and the scrub video fades in over it only once it can display a frame; a video that stalls or cannot decode leaves the photo, never black. (c) A root error boundary wraps the whole app: any render error anywhere degrades to a visible branded recovery panel with a reload button. (d) A boot watchdog in the page shell paints the same recovery panel if the app has rendered nothing after 9 seconds (bundle blocked/failed), and removes itself the moment the app renders. No page, feature, database record, permission or setting changed; both clips still alternate electrical → plumbing in the hero and the first clip still scroll-scrubs in the film section."],
    ["18. Recovery-Panel Dead-End Fix — Non-Blocking Fonts & Self-Healing Boot (Nov 2026)", "Fixed — pending owner-device confirmation", "REPORT: the owner opened the site and was met by the recovery panel itself \u2014 the S SERVICES 'Something went wrong while loading this page' screen from Report 17 \u2014 and reported it as the error to solve. DIAGNOSIS: that panel is the Report 17 ROOT ERROR BOUNDARY, which only renders when the app crashed during load, OR the screenshot matches the BOOT WATCHDOG panel, which only paints when the app has rendered nothing after 9 seconds. Either way the app's JavaScript did not get to render on the owner's device, while a fresh independent render inspection of the same build showed the page fully healthy (complete content, zero console errors, settled in ~3s). The boot path was therefore audited for anything that can stop the bundle from EXECUTING on a real-world network: exactly one external dependency sat in that path \u2014 the brand fonts. They were loaded with a CSS @import at the very top of the bundled stylesheet, and a stylesheet (including its @import chain) blocks module-script execution until it resolves: on a network where fonts.googleapis.com is slow, filtered, or hangs (dropped packets can stall a fetch for minutes), the entire app waits on a font file and the watchdog/boundary panel is all the visitor ever sees. That also explains why every previous fix verified clean in the audit environment \u2014 where Google Fonts answers in milliseconds \u2014 yet failed on the owner's device. FIXES: (1) Fonts are no longer a boot dependency: the @import is removed from the stylesheet and Archivo / Archivo Narrow now load from the page head as a non-blocking print-media stylesheet that swaps in when downloaded; if the font host is unreachable the site boots instantly on the system font stack and simply swaps typefaces when (if) the fonts arrive. (2) The boot watchdog can no longer be a dead end: its panel is now an overlay that never replaces the app root, it removes itself the moment the app renders (even if it already painted), and if the app still has not rendered 6 seconds later it retries with a cache-busting reload (a stale cached shell pointing at a replaced bundle is the other classic cause of an empty root), at most twice, then leaves the manual button. (3) The root error boundary now displays the actual error message on its panel (small technical line) and offers an in-place Retry as well as Reload, so any future failure screenshot is self-diagnosing instead of generic. (4) The initial state query now retries twice with backoff, and if the first load is still pending after 8 seconds the spinner is replaced by an explanatory panel with a Reload button \u2014 a stalled connection no longer presents as a dead page. No page content, feature, database record, permission or setting changed. STATUS: the boot-blocking font dependency is removed and every recovery path now self-heals or explains itself; final confirmation is the owner re-opening the site on the same device/network where the panel appeared."],
    ["19. Option-1 Premium Upgrade — Private Admin Auth, Customer Accounts, Floating Emergency Buttons, List Layout, Craft Films (Nov 2026)", "Completed — supersedes the login statements in Reports 7, 9 and 10", "DIRECTION CONFIRMED BY OWNER: Option 1 — S SERVICES stays an ELECTRICAL & PLUMBING business (not a digital agency), upgraded in place. A full source backup was taken before any change (workspace/backups/s-services-2-pre-upgrade-2026-11-09). PRESERVED, UNTOUCHED: all 20 electrical + 22 plumbing services, booking with double-booking prevention, quotations, invoices, emergency system, Client/Manager/Technician portals, all 11 languages (Italian default, Arabic/Urdu RTL), all 6 themes × light/dark/system, the Pexels hero pair, the GSAP scrollytelling (film scrub, pinned story, horizontal journey, Three.js), all existing data and settings. (1) PRIVATE ADMIN: the Admin entry was REMOVED from the public navigation and footer; the back office now lives only on the #admin route and requires a real staff login. NEW SERVER-SIDE AUTH: staff accounts (staff_users) with salted PBKDF2-HMAC-SHA256 password hashes (210k iterations) and 30-day sessions stored as SHA-256 token hashes; the first admin is created through a one-time setup that closes permanently once any account exists — no default credentials anywhere. EVERY admin action now verifies the session token and role on the server: Admin = everything incl. Settings and the new Staff Access tab (create/edit/deactivate/delete staff accounts, link a technician record; guards — cannot change own role, delete own account, or remove the last active admin); Manager = operations only, Team read-only, no Settings/Staff data returned; Technician = the server returns ONLY their own assigned jobs and their booking updates are restricted server-side to status + work notes on their own jobs. The old client-side role switcher was removed — the role comes from the signed-in account. (2) CUSTOMER ACCOUNTS: the Client Portal now has real registration and sign-in (same hashing + sessions). Booking-created passwordless records keep working by email lookup until the customer claims the account by setting a password; from that moment the server requires a valid customer session for that email's records, profile edits and quotation responses. Change-password is in the portal profile. PASSWORD RESET: the platform has no mail channel, so 'forgot password' files an admin notification here; an admin sets a temporary password in Customers (which also ends the customer's old sessions) and contacts the customer — stated plainly rather than faking an email flow. Report 10(d) is therefore closed for password login (implemented in-platform, no external provider needed); online PAYMENTS remain inactive pending gateway credentials. (3) FLOATING EMERGENCY BUTTONS: Call (pulsing red) and WhatsApp (green) buttons now float on every public page (never in the back office), driven entirely by Settings: they render only when Company phone / WhatsApp number are filled in AND their Settings → 'Floating emergency buttons' switch is on; the WhatsApp prefilled message is configurable there too. No numbers were invented — with the settings still empty, the buttons correctly do not appear. (4) SERVICES LAYOUT: the Services page now defaults to a list-wise layout — photo, category, name, description, starting price and direct Book / Quote / View actions per service — with a List/Grid toggle, an Emergency shortcut chip, category filters (Electrical / Plumbing / Emergency entry) and search, across all 42 services in all 11 languages (new strings translated in all 11). (5) NEW CINEMATIC VIDEO: two real AI-generated MP4s produced for this site (electrician wiring a panel; plumber tightening a valve — 1280×720, H.264, faststart, 402KB and 1.1MB) with poster frames extracted from the films themselves, playing in a new homepage 'The craft, in motion' section and on the About page, always over photo fallbacks and replaced by posters under reduced motion. No fake video URLs; the Pexels hero pair and scroll-scrub are unchanged. (6) TESTING: the full auth chain was exercised against the live action layer (setup → login → gated data → role scoping → logout; customer register → login → protected records → reset request → admin-set password), admin actions without a token are rejected, and the public site was re-audited at phone and desktop widths. Framer Motion was deliberately NOT added: GSAP + ScrollTrigger already powers every scroll animation and CSS handles the micro-interactions — adding a second animation runtime would risk the stable build for no visible gain. Pricing/Packages as a separate page was not invented: per-service starting prices plus the quotation system are the platform's pricing, shown in the new list layout."],
    ["20. FINAL Production-Readiness Review (Nov 2026) — incl. localStorage Crash Fix", "Completed — verified items below; real-device items listed separately, NOT claimed", "SCOPE RULE (owner's instruction): this review separates what was actually tested from what only the owner's devices can prove; production readiness is NOT declared from sandbox tests alone. (A) URGENT FIX — 'Failed to read the localStorage property from Window: Access is denied for this document' + recovery panel. ROOT CAUSE: the preview runs in a sandboxed/restricted document where merely READING window.localStorage throws a SecurityError; App.tsx read localStorage UNGUARDED inside useState initializers (ss-lang / ss-theme / ss-mode) during the very first render, so the whole app crashed before painting and the Report 17/18 root boundary showed its panel with that exact message. The same unguarded pattern existed in portal.tsx (customer session) and admin.tsx (staff session set/remove). The index.html boot watchdog was already try/catch-guarded and was NOT the cause. FIX: new client/src/storage.ts — storageGet/storageSet/storageRemove probe availability once (real write+remove test, fully try/caught); when storage is denied, values fall back to an in-memory map so the site loads and works normally for the session (language, theme and logins function; they simply do not persist across reload in that restricted environment); when storage IS available the same keys are used exactly as before — no stored value is overwritten, moved or deleted, and no browser security restriction is bypassed. Files changed: client/src/storage.ts (new), client/src/App.tsx, client/src/portal.tsx, client/src/admin.tsx. No database, schema, service, booking or permission was touched. (B) VERIFIED IN THIS REVIEW — action layer (isolated sandbox DB): all 42 services present and published (20 electrical + 22 plumbing) via getState; booking created (BK-MW9K1IM5-IZW7N); a second booking for the same date+slot rejected with slot_taken; getBookedSlots returned the taken slot; an emergency booking bypassed the taken slot (EMG-…); a quote request was created (QR-MW9K1N56-IQQIM). #admin auth: missing/bogus token → UNAUTHORIZED; first-admin bootstrap succeeded and a second bootstrap was refused (setup_closed); wrong password → invalid_credentials; ADMIN session received the full dataset including settings and staff accounts; MANAGER received operations data with settings and staff accounts EMPTY and was FORBIDDEN from saving settings; TECHNICIAN (linked to a technician record) saw exactly ONE booking — his own assigned job — with customers/settings/staff/quote-requests empty and stats scoped to 1, and was FORBIDDEN from updating another technician's booking; CUSTOMER (the fourth account type — the platform has 3 staff roles + customer accounts): a booking-created passwordless record was claimed with a password, the portal then refused access without a token (requires_login, no data leaked) and returned exactly that customer's booking, quote request and notifications with the token; staff logout invalidated the token (subsequent call UNAUTHORIZED). (C) VERIFIED — media files: all four MP4s re-probed with ffprobe — hero electrical H.264 1280×720 24fps 16.4s 652KB, hero plumbing H.264 1280×720 25fps 20.0s 736KB, craft electrical + craft plumbing H.264 1280×720 24fps 10.0s each, posters 1280×720 extracted from the films. VERIFIED — live page (audit browser, desktop 1440px + phone 390px): 0 console errors, page settled ≈3.2s on both, 0px horizontal overflow on mobile; the language selector offers all 11 languages; stats settle at 42 / 11 / 6 / 0; BOTH hero clips measured actually PLAYING by frame-change analysis (≈54% of hero pixels changed over ~3s on each clip), and the Video 1/Video 2 dots switched clips with the crossfade. First seconds after load can show the poster photograph before the first video frame paints — that is the designed poster fallback, not a failure. (D) VERIFIED BY CONSTRUCTION / RUNTIME PANEL: translations — the Live Verification panel below computes, from the shipped tables at runtime, 42/42 descriptions, 42/42 names and 6/6 FAQs for every one of the 11 languages with 0 Italian leaks, and Report 14 records live FR/DE/AR(RTL) detail-page checks; themes — all 6 themes × light/dark token blocks ship in theme.css with the header selector and per-visitor persistence; reduced motion — code branches verified (photo-only hero, static scrollytelling, craft posters, global CSS motion kill-switch). (E) NO DATA LOST: production row counts before and after this review are identical (services 42, settings 12, activity log 1 seed entry; bookings/customers/staff and all other tables 0 — the business has not yet added live records, so there was nothing to lose and nothing was deleted); every test above ran against the isolated sandbox copy, never the production database; the pre-upgrade source backup (workspace/backups/s-services-2-pre-upgrade-2026-11-09) stands. Also fixed in this pass: the desktop header tagline no longer truncates mid-word — it wraps to two lines. (F) STILL REQUIRING REAL-DEVICE TESTING — NOT claimed as verified: (1) playback, autoplay and the unattended electrical→plumbing alternation on the OWNER's own phone and laptop/network, including confirmation that the localStorage fix ends the recovery-panel error in the owner's preview environment (the audit browser permits storage, so the denied-storage path is verified by code construction — probe throws → caught → in-memory fallback — and by the removal of every unguarded access, but only the owner's restricted preview can prove it end-to-end); (2) a full unattended hero cycle (16s + 20s + loop-back) in one sitting; (3) reduced-motion rendering forced ON on a real device for the new craft section; (4) tablet-width (768/1024px) captures — verified by breakpoint construction as recorded in Report 14; (5) craft-film frame-motion was attribute- and file-verified but not separately pixel-measured this session (the hero clips were). CONCLUSION: everything testable from here passes; the items in (F) are the owner's device checks, and until they are confirmed this report does NOT declare full production readiness."],
    ["21. Final Feature Additions — Interactive Service-Area Map, Admin Completion, Contact Management, Animation & Load Optimisation (Nov 2026)", "Completed — device checks still the owner's, as in Report 20 (F)", "FEATURE 1 — INTERACTIVE SERVICE-AREA MAP: the homepage and the Service Areas page (the header 'Zone di Servizio' entry previously opened an empty view — that latent bug is fixed) now show a real interactive map: a marker on the company's base and a coloured circle for the service radius, zoomable and pannable, following the site's light/dark mode. MAP TECHNOLOGY, stated plainly: the interactive map is rendered by this platform's built-in map service (the bundled map control), so NO Google Maps API key is needed, none was invented, and no paid Google service or billing was introduced; Google Maps is used only for the outbound 'Directions' buttons, which hand off to Google Maps in a new tab. If a Google-branded embedded map is ever wanted instead, it would require the company's own Google Cloud project with a Maps JavaScript API key and billing enabled — deliberately NOT introduced. GRACEFUL DEGRADATION: if the map service is unavailable or unsupported, the section shows the base name, address, radius and a Directions button instead — the page never breaks. DEMO LOCATION: until an administrator saves real coordinates, the map shows Rome (41.9028, 12.4964) with a 25 km radius, badged DEMO everywhere it appears, with an explicit note that it is a demonstration location — never presented as the company's real base. ADMIN CONTROL (Settings → Interactive service-area map): base name, address, latitude, longitude, radius in km and the demo on/off flag, saved through the existing settings store (no new table, no migration); the public site publishes exactly the saved values. LOAD COST: the map runtime (~1.3 MB) is a lazily loaded file asset fetched only when a map mounts — it is NOT part of the initial bundle. FEATURE 2 — ADMIN COMPLETION (same panel, no duplicate): the Overview now also reports total services, electrical/plumbing counts, published count, pending bookings, emergency bookings, cancelled bookings and total quote requests; Services gained search + category filter, an add-service form, inline Italian/English name editing, category editing and delete with an inline two-step confirmation (new server actions adminUpsertService / adminDeleteService, admin-only, validated; long descriptions stay catalogue-managed so their 11-language translations stay intact); Bookings gained search (name/email/reference/phone), status filter (including emergency-only) and date filter, on top of the existing status/technician/date/notes controls and the untouched slot-conflict prevention; Quotations gained per-request Email / Call / WhatsApp contact buttons; Customers gained search and an expandable per-customer booking + quote-request + quotation history. Role enforcement is unchanged and server-side for every new action. FEATURE 3 — WHATSAPP: unchanged single source (Settings → company_whatsapp + floating-button switch + prefilled message); the floating button, emergency page, hero strip and now the Contact page actions all build their wa.me link from that one saved number — nothing is hardcoded per-component and no number was invented. FEATURE 4 — CONTACT MANAGEMENT: Settings now also manages opening hours and a contact-availability note; the Contact page shows phone, WhatsApp, email, address, hours and availability with direct Call (tel:), Email (mailto:), WhatsApp and Directions actions; hours also appear on the homepage map card and in the footer. FEATURE 5 — ANIMATION & PERFORMANCE: (a) the scroll-progress bar no longer re-renders the entire app on every scroll event — it is now written directly to its DOM node, rAF-throttled, and measured against the element that actually scrolls (it also never moved before, for the same reason); (b) below-fold films (craft section, About) now decode only while on screen (IntersectionObserver play/pause) and fetch zero bytes before then (preload='none', poster first); (c) the marquee track gets a transform hint so its loop stays on the compositor. Hero videos, scrollytelling, autoplay/loop behaviour and reduced-motion handling are unchanged. LOAD MEASUREMENT: before this pass the initial JS bundle was 1,307,946 bytes with a 46 KB stylesheet and, per Report 20, the page settled in ≈3.2 s in the audit browser; the after figures are recorded in DATA-PLAN.md from the shipped build — the 1–2 s target is network-dependent and is NOT claimed as guaranteed. FEATURE 6 — TESTING: build + typecheck, sandbox action tests for the new service actions, and desktop/phone audit captures including the map section are the verification for this pass; tablet widths remain verified-by-construction (Report 14) and real-device checks remain the owner's (Report 20 F). NOTHING ELSE CHANGED: all 42 services, bookings, quotations, portals, 11 languages, 6 themes, videos and permissions are as they were."],
    ["22. Client Accounts Completion — Salam Greeting, Offers & Promotions System (Nov 2026)", "Completed — offers + greeting sandbox-verified end-to-end; email verification blocked on a mail provider (see below)", "INSPECTION FIRST (owner's instruction): the existing system already had REAL client signup/login/logout/change-password (customerRegister / customerLogin / customerLogout / customerChangePassword, PBKDF2-HMAC-SHA256, 210k iterations, 30-day sessions stored as SHA-256 hashes), a private #admin route with server-side role checks (admin / manager / technician), a Client Portal with profile editing and per-email records, and a complete admin dashboard — all REUSED unchanged. Genuinely missing were exactly two things, both added here: (1) THE SALAM GREETING — the Client Portal now opens with a greeting card: 'Assalamu Alaikum, [Client Name]!' (السلام علیکم in Urdu, السلام عليكم in Arabic, Latin script in the other nine languages) plus the account's REAL registered email and registered mobile number, read from the signed-in customer's own record — nothing hardcoded. Strings live in portalStrings() in upgrade-i18n.ts, complete in all 11 languages. (2) OFFERS & PROMOTIONS — an entirely new subsystem, deliberately separate from a quotation's one-off discount_cents. UNAVOIDABLE CHANGE, stated plainly: ONE additive migration (0004) adds two new tables — offers (title, description, percent-or-fixed-amount discount, audience scope, optional single service, enabled flag, start/expiry dates) and offer_assignments (offer → customer email) — NO existing table, column or row was altered, and no authentication code changed. ADMIN (new 'Offers' tab, admin role only, enforced server-side): create, edit, enable/disable, delete with two-step confirmation; discount as percentage (validated 1–100) or fixed amount; start + expiration dates validated (expiry may not precede start); audience = Public (all visitors) / Registered clients (all) / Selected clients (per-customer checkboxes; an empty selection is rejected with NO_RECIPIENTS); Overview gained total + live-offer counters. VISIBILITY: the public homepage shows a 'Offers & promotions' section ONLY for live public offers (getState never returns clients/selected offers to anonymous visitors); the Client Portal shows each customer exactly the live offers that apply to them (public + all-clients + offers assigned to their own email); expired, not-yet-started and disabled offers never render anywhere; when a clients/selected offer is live, its target customers also receive a portal notification (the existing notifications channel). SANDBOX VERIFICATION (isolated copy of the database; production rows untouched): bogus-token offer creation → UNAUTHORIZED; manager session → FORBIDDEN on both create and delete; a six-offer matrix (public live, all-clients €50, selected-only 20%, expired, disabled, scheduled-future) resolved exactly per audience — the selected customer saw 3 offers + 2 offer notifications, the other customer saw only public + all-clients and never the selected offer, the public state exposed only the live public offer; editing changed the discount/title, deactivating removed it from every surface, deleting removed the record; invalid inputs rejected (INVALID_PERCENT, NO_RECIPIENTS, INVALID_WINDOW by construction); a portal call without a token returned requires_login with zero offers/records leaked; regression — booking created (BK-MW9MMOKP-KEGKC), a second booking on the same date+slot rejected slot_taken, the booking appeared in the customer's own portal linked by email, and getState still returns all 42 services. EMAIL VERIFICATION — NOT IMPLEMENTED, honestly: this platform has NO outbound mail channel at all (no mail provider, no SMTP/API credentials anywhere in settings or server code), so real email verification CANNOT be switched on without inventing credentials, which was not done. What exists and stays: registration works immediately, and password recovery is the admin-assisted flow (request → admin notification → admin sets a temporary password → old sessions ended), labelled as such in the portal. TO ENABLE TRUE EMAIL VERIFICATION the company must supply ONE of: a Resend / SendGrid / Amazon SES API key (or SMTP host + user + password) for a sending address it owns; then a verification-token table + verify/resend actions can be added on top of the existing auth without changing it. No Admin Email or password was invented; the first admin is still created only through the one-time setup, and admin emails stay editable in Staff Access. NOT VERIFIED HERE: the greeting/offers UI on the owner's own device (action layer and build verified; the audit covers page rendering), and live rendering of a populated offers section on the public homepage — production correctly has zero offers until the admin creates the first real one."],
    ["23. Admin Login Clarity, Hamburger Menu & Website Settings (Nov 2026)", "Completed — sandbox-verified below; device checks remain the owner's", "OWNER'S REQUEST, implemented in place — nothing rebuilt, no data reset, no new tables or migrations (all new content lives in the existing settings store). (1) ADMIN LOGIN & SETUP: the Admin Login lives at the #admin route (open the site address with #admin at the end). Entry points added: a 'Admin Login' item in the new menu drawer and in the footer — both open ONLY the staff login / one-time setup screen; no admin controls are exposed publicly. The login screen is now titled 'Admin Login' and states that a successful sign-in lands on the Admin Dashboard (it does — the dashboard renders in place of the login form). FIRST-ADMIN SETUP IS NOW LOCKED TO THE OWNER-AUTHORIZED EMAIL: the owner designated 494motors@gmail.com as the administrator email; the server-side staffBootstrap now refuses any other email with 'unauthorized_email' and creates nothing, and the setup screen shows and pre-fills that address. No password was invented — the owner chooses it in the setup form (min. 10 chars, PBKDF2 hash). Clients can never become administrators: public signup only creates customer records. PASSWORD MANAGEMENT: a new staffChangePassword action lets ANY signed-in staff member (admin / manager / technician) change their own password from the dashboard header (current password verified server-side; all other sessions of that account are ended); admins can still reset staff passwords in Staff Access; secure logout (server session deletion) is unchanged. (2) HAMBURGER MENU: the crowded pill navigation row is REPLACED by a three-line hamburger button in the header at every width. It opens an animated side drawer (slide + fade overlay, closes on selection, on the overlay, or with Escape; RTL-aware) containing exactly: Home, Services, Book a Service, Get a Quote, About Us, Service Areas, Contact, Emergency, then Client Login / Sign Up and Admin Login. New drawer strings are translated in all 11 languages (menuStrings in upgrade-i18n.ts); the rest reuse the main dictionary. Language, theme and emergency controls stay in the header bar as before. (3) WEBSITE SETTINGS (Admin → Settings, reorganized into one 'Website Settings' area, all saved through the existing admin-only adminSaveSettings and published by getState): BRANDING — website name (site_name; header, drawer, footer, page title), tagline (site_tagline), LOGO UPLOAD/CHANGE (file → downscaled in the browser to ≤256 px → stored as a data URL in the settings store → rendered in header / drawer / footer; remove button restores the built-in 'S' tile), FAVICON upload (≤64 px, applied as the browser tab icon; the logo doubles as favicon when no favicon is set), and the default theme (colours) selector. WEBSITE CONTENT — homepage hero headline + sub-headline overrides (single-language as written; empty = the fully translated built-ins), About Us IT/EN (existing), footer text override, and social media links (Facebook / Instagram / YouTube / LinkedIn — shown in the footer only when filled). Services stay in the Services tab (the Settings page says so, with descriptions catalogue-managed for translations) and service areas in the map section + Service Areas tab. OFFERS — unchanged Offers tab (create/edit/publish/unpublish/delete, discounts, expiry, public/client/selected audiences). CONTACT & WHATSAPP — phone, WhatsApp number, email, address, opening hours, availability, emergency notes (all pre-existing fields, now grouped under one heading) plus a prominent status line: when no WhatsApp number is saved it states in Settings that the number is NOT configured and the floating button stays hidden. TECHNICAL SETTINGS — a new read-only panel (TechnicalSettings) summarizing the live configuration safely: admin route, setup lock, branding/theme/language/currency defaults, hero-video mode, map status, WhatsApp/call status, live content counts, where settings live — and an explicit note that domain registration, DNS and hosting are controlled by the external platform provider and CANNOT be changed from this panel, with where to change them instead. No API keys, database credentials or environment variables are shown anywhere (none are stored in settings). (4) FLOATING WHATSAPP BUTTON: already existed (Report 19) and is unchanged in behaviour — fixed bottom corner on the inline-end side, visible while scrolling on mobile and desktop, opens https://wa.me/<admin-configured number> with the admin-configured prefilled message, rendered ONLY when a real number is saved and its switch is on; never hardcoded anywhere. This pass only replaced its emoji glyph with the proper WhatsApp SVG icon and brand colour (#25D366). (5) SEPARATION: unchanged and re-verified — public browsing needs no login; clients see only their own records in the portal; only admin-role staff can save website settings (server-enforced via requireStaff). SANDBOX VERIFICATION (isolated DB copy; production rows untouched): staffAuthStatus returned setup_required + the authorized email; bootstrap with a WRONG email was refused (unauthorized_email, no account created); bootstrap with the authorized email succeeded; a second bootstrap was refused (setup_closed); login worked and adminGetAll returned all data; staffChangePassword with a wrong current password was refused, with the correct one it succeeded, the old password then failed login and the new one succeeded; adminSaveSettings saved site_name / site_tagline / hero_title / footer_text / social links and getState published them back verbatim alongside all 42 services; a manager session was FORBIDDEN from saving settings. NOT VERIFIED HERE: the drawer animation and the logo/favicon rendering on the owner's own devices (build + audit captures cover phone/desktop rendering), and the production first-admin setup itself — production still has no staff account, so the owner's first visit to #admin will show the locked setup form described above."],
    ["24. #admin Hash Route REMOVED — Secure Admin Login Only (Nov 2026)", "Completed — supersedes the admin-access statements in Reports 19, 20, 22 and 23", "OWNER'S REQUEST: remove direct #admin access completely and enforce the secure Admin Login as the ONLY way into the Admin Dashboard. WHAT CHANGED: (1) THE HASH ROUTE IS GONE — App.tsx no longer maps any URL hash to the back office: goMenu no longer writes #admin, the hash listener no longer opens the admin view, and a URL ending in #admin now simply loads the public website while the dead fragment is stripped from the address bar (history.replaceState, try/caught for restricted documents). There is no alternative hash, path or secret URL: #portal still opens only the Client Portal, as before. (2) THE ONLY ENTRY is the dedicated Admin Login page, opened in-app from the existing “Admin Login” items in the menu drawer and footer — it sets no URL and exposes no admin controls. (3) SERVER VERIFICATION GATE — a NEW action staffVerifySession (requireStaff, all staff roles) re-checks the stored session token with the server: AdminView now renders NO dashboard content until the server confirms the session is live, and the name/role/technician link used by the panel are refreshed from the server's answer, never trusted from browser storage. A rejected token (expired, revoked, deactivated account, forged, or a CUSTOMER token) destroys the local session and returns to the login form with a notice; if the verification call itself cannot complete, a neutral retry screen is shown and the dashboard still does not render. (4) LOGOUT — staffLogout already deleted the server-side session; sign-out now additionally drops the stored token, purges the admin datasets from the client query cache (admin-all / admin-verify) and navigates back to the public homepage, so refresh, browser Back/history and previously opened links cannot resurrect the dashboard, and the deleted server session makes the old token return UNAUTHORIZED everywhere. (5) COPY — every place that described #admin as the way in (Admin Login page, Staff Access tab, Technical Settings panel) now states there is no URL for the back office. NOT CHANGED: every admin action still enforces requireStaff + role server-side (admin-only actions still FORBIDDEN for manager/technician; technician data still scoped to own jobs); staff accounts, roles, PBKDF2 password hashing, 30-day SHA-256-hashed sessions, the one-time setup locked to the owner-authorized email, all 42 services, bookings/quotations, portals, videos, 11 languages and 6 themes are untouched; no migration, no data reset. SANDBOX VERIFICATION (isolated copy; production rows untouched): getState returned all 42 services; staffVerifySession with a bogus token → ok:false; adminGetAll with a bogus token → UNAUTHORIZED; staffLogin with a wrong password → invalid_credentials; a CUSTOMER session token → staffVerifySession ok:false, adminGetAll UNAUTHORIZED, adminSaveSettings UNAUTHORIZED (a client can never cross into staff functions); booking regression intact — booking BK-MW9OWKPR-UMYNS created, a duplicate date+slot rejected slot_taken, and the booking visible only in its owner's portal. ONE HONEST LIMIT: the sandbox data copy already contains a staff account (staffAuthStatus setup_required=false) whose password belongs to its owner and was neither used nor reset by this pass, so a throwaway bootstrap→login→verify→logout chain could not be re-run here; the accept path of staffVerifySession is the same requireStaff/session code whose full login→gating→role-scoping→logout chain was verified end-to-end in Reports 20, 22 and 23, and every reject path above was exercised live in this pass. Client-side behaviour (#admin loads the public site and is stripped; the Admin Login page opens from the drawer/footer; the dashboard stays gated on server verification) is covered by this build's audit. Owner-device confirmation of the final rendered behaviour remains the owner's check, as in Report 20 (F)."],
  ];
  return (
    <div className="mt-6 grid gap-3">
      {reports.map(([title, status, body]) => (
        <div key={title} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-display font-bold">{title}</h3>
            <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${status.startsWith("Completed") ? "bg-emerald-500/15 text-emerald-500" : status.includes("Partial") || status.includes("awaiting") ? "bg-amber-500/15 text-amber-500" : "bg-[var(--surface2)] text-[var(--dim)]"}`}>{status}</span>
          </div>
          <p className="mt-1 text-sm text-[var(--dim)]">{body}</p>
        </div>
      ))}
      <LiveVerification d={d} />
      <p className="text-xs text-[var(--dim)]">
        Service demand: electrical {d.bookings.filter((b) => b.category === "electrical").length} bookings · plumbing {d.bookings.filter((b) => b.category === "plumbing").length} bookings · emergencies {d.bookings.filter((b) => b.is_emergency).length}.
      </p>
    </div>
  );
}

/* Live, runtime-computed translation evidence (Report 14). Every number
   below is derived on the spot from the translation tables bundled with
   this page — the same tables the public site renders from — so the panel
   cannot claim coverage the shipped code does not have. "Italian leak"
   counts strings byte-identical to the Italian master in a non-Italian
   language; it must be 0 everywhere outside Italian itself. */
function LiveVerification({ d }: { d: All }) {
  const LANG_CODES = ["it", "en", "en-GB", "fr", "de", "es", "pt", "nl", "tr", "ar", "ur"] as const;
  const total = Object.keys(ALL_DETAILS).length;
  const itDict = DICTS.it!;
  const uiProbeKeys = ["emergencySub", "maintenanceSub", "noAreas", "noProjects", "footerNote", "safetyText"] as const;
  const sampleSlug = "residential-electrical-installation";
  const sampleDet = ALL_DETAILS[sampleSlug];

  const rows = LANG_CODES.map((code) => {
    const isMaster = code === "it" || code === "en" || code === "en-GB";
    const descs = isMaster ? total : Object.keys(SERVICE_DESC[code] ?? {}).length;
    const names = isMaster ? total : Object.keys(SERVICE_NAMES[code] ?? {}).length;
    const faqs = isMaster ? FAQS.length : (FAQ_LOCALIZED[code]?.length ?? 0);
    let leak = 0;
    if (!isMaster) {
      for (const [slug, det] of Object.entries(ALL_DETAILS)) {
        if (SERVICE_DESC[code]?.[slug] === det.descIt) leak += 1;
        const svc = d.services.find((s) => s.slug === slug);
        if (svc && SERVICE_NAMES[code]?.[slug] === svc.name_it) leak += 1;
      }
      const dict = DICTS[code];
      if (dict) {
        for (const k of uiProbeKeys) if (dict[k] === itDict[k]) leak += 1;
      } else leak += uiProbeKeys.length;
    }
    const scrolly = SCROLLY[code];
    const scrollyOk = !!scrolly && scrolly.scenes.length === 5 && scrolly.journey.length === 6;
    const pass = descs === total && names === total && faqs === FAQS.length && leak === 0 && scrollyOk;
    return { code, descs, names, faqs, leak, scrollyOk, pass, rtl: code === "ar" || code === "ur" };
  });
  const allPass = rows.every((r) => r.pass);

  return (
    <div className="rounded-2xl border-2 border-emerald-500/40 bg-[var(--surface)] p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="font-display font-bold">Live verification — translation coverage (computed now, from shipped data)</h3>
        <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${allPass ? "bg-emerald-500/15 text-emerald-500" : "bg-red-500/15 text-red-500"}`}>
          {allPass ? `PASS — ${total} services × 11 languages, 0 Italian leaks` : "CHECK ROWS BELOW"}
        </span>
      </div>
      <div className="mt-3 overflow-x-auto">
        <table className="w-full min-w-[560px] text-start text-sm">
          <thead>
            <tr className="text-xs text-[var(--dim)]">
              <th className="py-1 pe-3 text-start font-bold">Language</th>
              <th className="py-1 pe-3 text-start font-bold">Descriptions</th>
              <th className="py-1 pe-3 text-start font-bold">Names</th>
              <th className="py-1 pe-3 text-start font-bold">FAQs</th>
              <th className="py-1 pe-3 text-start font-bold">Cinematic</th>
              <th className="py-1 pe-3 text-start font-bold">Italian leak</th>
              <th className="py-1 text-start font-bold">Result</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.code} className="border-t border-[var(--border)]">
                <td className="py-1.5 pe-3 font-bold">{r.code.toUpperCase()}{r.rtl ? " · RTL" : ""}</td>
                <td className="py-1.5 pe-3">{r.descs}/{total}</td>
                <td className="py-1.5 pe-3">{r.names}/{total}</td>
                <td className="py-1.5 pe-3">{r.faqs}/{FAQS.length}</td>
                <td className="py-1.5 pe-3">{r.scrollyOk ? "5 scenes · 6 steps" : "—"}</td>
                <td className="py-1.5 pe-3">{r.code === "it" ? "— (master)" : r.leak}</td>
                <td className={`py-1.5 font-bold ${r.pass ? "text-emerald-500" : "text-red-500"}`}>{r.pass ? "✓ PASS" : "✗ FAIL"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h4 className="mt-4 font-display text-sm font-black">Spot-check samples — exactly what the detail page renders for “{sampleSlug}”</h4>
      <div className="mt-2 grid gap-2">
        {(["fr", "de", "ar"] as const).map((code) => (
          <div key={code} className="rounded-xl bg-[var(--surface2)] px-3 py-2.5" dir={code === "ar" ? "rtl" : "ltr"}>
            <p className="font-display text-sm font-bold">
              {code.toUpperCase()}{code === "ar" ? " · RTL" : ""} — {SERVICE_NAMES[code]?.[sampleSlug] ?? ""}
            </p>
            <p className="mt-0.5 text-sm text-[var(--dim)]">{SERVICE_DESC[code]?.[sampleSlug] ?? ""}</p>
            <p className="mt-0.5 text-xs text-[var(--dim)]">
              Italian master (for comparison): {sampleDet?.descIt ?? ""}
            </p>
          </div>
        ))}
      </div>
      <p className="mt-3 text-xs text-[var(--dim)]">
        Tablet widths (768px / 1024px) use the same wrapping header and tab strip captured at phone and desktop widths, with grids stepping at 640px and 1024px breakpoints; Report 14 above records the tablet verification method and its capture limitation exactly.
      </p>
    </div>
  );
}
