import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SafeAreaTopScrim } from "@hatch/space-sdk/client";
import { api, type ApiResponse } from "./api";
import { storageGet, storageSet } from "./storage";
import {
CURRENCIES,
DICTS,
LANGS,
THEMES,
isRtl,
money,
type Dict,
type LangCode,
} from "./i18n";
import { ALL_DETAILS, FAQS } from "./catalog";
import { FAQ_LOCALIZED, serviceDesc, serviceNameLocalized } from "./service-i18n";
import { BookingForm, ContactForm, QuoteForm, ReviewForm } from "./forms";
import { PortalView } from "./portal";
import { AdminView } from "./admin";
import { ScrollyBoundary, Scrollytelling } from "./scrolly";
import { ServiceAreaMap, directionsUrl as serviceDirectionsUrl } from "./service-map";

import heroElectrical from "./assets/hero-electrical.jpg";
import heroPlumbing from "./assets/hero-plumbing.jpg";
import heatingImg from "./assets/heating.jpg";
import solarImg from "./assets/solar.webp";
import evImg from "./assets/ev-wallbox.webp";
import kitchenImg from "./assets/kitchen-plumbing.jpg";
import pipesImg from "./assets/pipe-work.jpg";
import inspectionImg from "./assets/electrical-inspection.webp";
/* Built-in hero videos — Pexels free-licence clips chosen by the owner:
   electrical first ("Person Fixing Wires"), then plumbing ("A Person
   doing Plumbing"). Admin → Settings → Hero video can replace them with
   custom licensed URLs (see heroPlaylist below). */
import heroVideoElectrical from "./assets/hero-video-electrical.mp4";
import heroVideoPlumbing from "./assets/hero-video-plumbing.mp4";
/* AI-generated craft films (Option-1 upgrade): real MP4s generated for
   this site — an electrician wiring a panel, a plumber tightening a
   valve — web-encoded (720p, faststart) with poster frames extracted
   from the films themselves. Used in the homepage "craft" section and
   on the About page, always over a photo fallback. */
import craftElectrical from "./assets/craft-electrical.mp4";
import craftPlumbing from "./assets/craft-plumbing.mp4";
import craftElectricalPoster from "./assets/craft-electrical.jpg";
import craftPlumbingPoster from "./assets/craft-plumbing.jpg";
import { menuStrings, portalStrings, upgradeStrings } from "./upgrade-i18n";

const IMG: Record<string, string> = {
  electrical: heroElectrical,
  plumbing: heroPlumbing,
  heating: heatingImg,
  solar: solarImg,
  ev: evImg,
  kitchen: kitchenImg,
  pipes: pipesImg,
  inspection: inspectionImg,
};

const HERO_SLIDES = [heroElectrical, heroPlumbing, heatingImg, solarImg];

type View =
  | "home" | "services" | "detail" | "booking" | "quote"
  | "emergency" | "about" | "areas" | "contact" | "portal" | "admin";

type State = ApiResponse<typeof api, "getState">;
type Svc = State["services"][number];

function useReveal(dep: unknown) {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("in")),
      { threshold: 0.08 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [dep]);
}

function useCounter(target: number, run: boolean): number {
  // Settled value is ALWAYS exactly `target` (services published count,
  // 11 languages, 6 themes, active areas count). Before the stats row is
  // seen the final value is shown (no 0 / negative capture artefacts);
  // once seen it counts up once and lands exactly on target. Reduced
  // motion skips the count entirely.
  const [v, setV] = useState(target);
  useEffect(() => { setV(target); }, [target]);
  useEffect(() => {
    if (!run) return;
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true;
    if (reducedMotion || target <= 0) { setV(target); return; }
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / 1100);
      setV(Math.max(0, Math.round(target * (1 - Math.pow(1 - p, 3)))));
      if (p < 1) raf = requestAnimationFrame(tick);
      else setV(target);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, run]);
  return v;
}

export function App() {
  /* Retry the boot query a few times with backoff: a transient failure
     of the actions channel must not strand the whole site on the error
     line when a retry a second later would succeed. */
  const state = useQuery({
    queryKey: ["state"],
    queryFn: () => api.getState({}),
    retry: 2,
    retryDelay: (attempt: number) => Math.min(1500 * 2 ** attempt, 6000),
  });
  const d = state.data;
  const settings = d?.settings ?? {};

  const [lang, setLang] = useState<LangCode>(() => {
    const stored = storageGet("ss-lang");
    if (stored && DICTS[stored]) return stored as LangCode;
    return "it"; // Italian is the company default; browser language never overrides it.
  });
  const [theme, setTheme] = useState<string>(() => storageGet("ss-theme") ?? "");
  const [mode, setMode] = useState<"light" | "dark" | "system">(
    () => (storageGet("ss-mode") as "light" | "dark" | "system") || "system",
  );
  const [systemDark, setSystemDark] = useState(
    () => window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? true,
  );
  const [view, setView] = useState<View>("home");
  const [slug, setSlug] = useState<string>("");
  const [catFilter, setCatFilter] = useState<"all" | "electrical" | "plumbing">("all");
  const [query, setQuery] = useState("");
  const [themeOpen, setThemeOpen] = useState(false);
  const [heroVidIdx, setHeroVidIdx] = useState(0);
  const [failedVids, setFailedVids] = useState<ReadonlySet<string>>(new Set());
  const heroVidRefs = useRef<(HTMLVideoElement | null)[]>([]);
  const [reducedMotion, setReducedMotion] = useState(
    () => window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true,
  );
  const [slide, setSlide] = useState(0);
  /* Scroll progress is written straight to the bar's DOM node (rAF-
     throttled) instead of React state: the old version re-rendered the
     ENTIRE app on every scroll event, which was a real source of the
     animation stutter the owner reported. The app scrolls inside the
     SDK root element, so progress is measured against whichever
     element actually scrolls. */
  const progressRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const [statsVisible, setStatsVisible] = useState(false);
  /* Slow-boot escape hatch: if the first getState is still pending after
     8s, the spinner is replaced by an explanatory panel with a working
     reload button, so a stalled connection never looks like a dead,
     empty page. */
  const [slowLoad, setSlowLoad] = useState(false);
  useEffect(() => {
    if (!state.isPending) { setSlowLoad(false); return; }
    const id = setTimeout(() => setSlowLoad(true), 8000);
    return () => clearTimeout(id);
  }, [state.isPending]);

  const activeTheme = theme || settings["default_theme"] || "electric";
  const resolvedMode = mode === "system" ? (systemDark ? "dark" : "light") : mode;
  const t: Dict = DICTS[lang] ?? DICTS.en!;

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const fn = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener?.("change", fn);
    return () => mq.removeEventListener?.("change", fn);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = activeTheme;
    root.dataset.mode = resolvedMode;
    root.dir = isRtl(lang) ? "rtl" : "ltr";
    root.lang = lang;
    storageSet("ss-lang", lang);
  }, [activeTheme, resolvedMode, lang]);

  useEffect(() => {
    if (theme) storageSet("ss-theme", theme);
  }, [theme]);
  useEffect(() => {
    storageSet("ss-mode", mode);
  }, [mode]);

  useEffect(() => {
    const id = setInterval(() => setSlide((s) => (s + 1) % HERO_SLIDES.length), 6000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      const el = progressRef.current;
      if (!el) return;
      const sdkRoot = document.querySelector("[data-generated-space-root]");
      const candidates = [sdkRoot, document.documentElement].filter(
        (n): n is HTMLElement => n instanceof HTMLElement,
      );
      let pct = 0;
      for (const sc of candidates) {
        const max = sc.scrollHeight - sc.clientHeight;
        if (max > 0) pct = Math.max(pct, Math.min(100, (sc.scrollTop / max) * 100));
      }
      el.style.width = `${pct}%`;
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    window.addEventListener("scroll", onScroll, { passive: true, capture: true });
    update();
    return () => {
      window.removeEventListener("scroll", onScroll, { capture: true });
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  useEffect(() => {
    if (!statsRef.current) return;
    const io = new IntersectionObserver(
      (e) => e[0]?.isIntersecting && setStatsVisible(true),
      { threshold: 0.3 },
    );
    io.observe(statsRef.current);
    return () => io.disconnect();
  }, [view, d]);

  useReveal(view + (d ? "-ready" : ""));

  const go = (v: View) => {
    setView(v);
    window.scrollTo({ top: 0 });
  };

  const services = useMemo(() => d?.services ?? [], [d]);
  const published = useMemo(() => services.filter((s) => s.published), [services]);
  const serviceName = (s: Svc | string): string => {
    const svc = typeof s === "string" ? services.find((x) => x.slug === s) : s;
    if (!svc) return typeof s === "string" ? s : "";
    return serviceNameLocalized(svc.slug, lang, svc.name_it, svc.name_en);
  };
  const current = services.find((s) => s.slug === slug);
  const detail = ALL_DETAILS[slug];

  const cServices = useCounter(published.length, statsVisible);
  const cLangs = useCounter(11, statsVisible);
  const cThemes = useCounter(6, statsVisible);
  const cAreas = useCounter(d?.areas.length ?? 0, statsVisible);

  const filtered = published.filter((s) => {
    if (catFilter !== "all" && s.category !== catFilter) return false;
    if (query) {
      const q = query.toLowerCase();
      return s.name_it.toLowerCase().includes(q) || s.name_en.toLowerCase().includes(q);
    }
    return true;
  });

  const phone = settings["company_phone"] ?? "";
  const whatsapp = settings["company_whatsapp"] ?? "";
  const email = settings["company_email"] ?? "";
  /* Interactive service-area map configuration (Admin → Settings →
     Service area map). The server publishes the admin's saved values,
     or the clearly-labelled DEMO defaults (Rome, 25 km) until real
     coordinates are saved. */
  const mapCfg = {
    name: (settings["map_name"] ?? "").trim() || "Roma",
    address: (settings["map_address"] ?? "").trim() || "Roma, Italia",
    lat: Number.parseFloat(settings["map_lat"] ?? "") || 41.9028,
    lng: Number.parseFloat(settings["map_lng"] ?? "") || 12.4964,
    radiusKm: Number.parseFloat(settings["map_radius_km"] ?? "") || 25,
    isDemo: (settings["map_is_demo"] ?? "1") !== "0",
  };
  const mapDirUrl = serviceDirectionsUrl(mapCfg);
  /* Hero video playlist, configured in Admin → Settings → Hero video:
     two URL slots (clip 1 = electrical, clip 2 = plumbing) plus a mode
     selector — see heroVideoMode below for the exact semantics. */
  const customHeroVideos = [settings["hero_video_url"] ?? "", settings["hero_video_url_2"] ?? ""]
    .map((u) => u.trim())
    .filter((u) => u !== "");
  /* Admin → Settings → "Hero videos" mode decides the playlist:
     "builtin" (default) = the built-in Pexels pair, "custom" = exactly
     the saved URL(s) (a cleared slot removes that clip), "off" = no
     hero video at all, photo hero only. */
  const heroVideoMode = (settings["hero_video_mode"] ?? "builtin").trim() || "builtin";
  const heroPlaylist: string[] = heroVideoMode === "off"
    ? []
    : heroVideoMode === "custom"
      ? customHeroVideos
      : [heroVideoElectrical, heroVideoPlumbing];
  const heroPlaylistKey = heroPlaylist.join("|");
  const vidIdx = Math.min(heroVidIdx, heroPlaylist.length - 1);
  const showHeroVideos = !reducedMotion && heroPlaylist.some((src) => !failedVids.has(src));

  useEffect(() => { setHeroVidIdx(0); setFailedVids(new Set()); }, [heroPlaylistKey]);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const fn = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener?.("change", fn);
    return () => mq.removeEventListener?.("change", fn);
  }, []);
  /* Keep exactly one hero clip playing: the active one. The inactive
     clip stays mounted (paused, transparent) so the switch is a clean
     crossfade with no reload flash. */
  useEffect(() => {
    if (!showHeroVideos) return;
    heroVidRefs.current.forEach((v, i) => {
      if (!v) return;
      if (i === vidIdx) {
        if (v.ended) v.currentTime = 0;
        v.play().catch(() => { /* autoplay refusal → poster photos stay visible */ });
      } else {
        v.pause();
      }
    });
  }, [vidIdx, showHeroVideos, heroPlaylistKey]);
  /* If the active clip errored, move on to the next one. */
  useEffect(() => {
    const active = heroPlaylist[vidIdx];
    if (active && failedVids.has(active) && failedVids.size < heroPlaylist.length) {
      setHeroVidIdx((idx) => (idx + 1) % heroPlaylist.length);
    }
  }, [failedVids, vidIdx, heroPlaylist]);

  /* Below-fold films (craft section, About) only decode while they are
     on screen: an IntersectionObserver plays them when they enter the
     viewport and pauses them when they leave, instead of every video
     on the page decoding continuously (a steady source of scroll
     jank and battery/network cost). They also use preload="none", so
     not a single video byte is fetched before the visitor scrolls to
     them — the poster frame is what renders first. */
  useEffect(() => {
    if (reducedMotion || !d) return;
    const vids = Array.from(document.querySelectorAll<HTMLVideoElement>("video[data-io-video]"));
    if (vids.length === 0) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          const v = e.target as HTMLVideoElement;
          if (e.isIntersecting) v.play().catch(() => { /* poster stays */ });
          else v.pause();
        });
      },
      { threshold: 0.15 },
    );
    vids.forEach((v) => io.observe(v));
    return () => io.disconnect();
  }, [view, d, reducedMotion]);

  const emergencyOn = (settings["emergency_enabled"] ?? "") !== "";

  /* Option-1 upgrade state: services list/grid layout, About film
     fallback, and the protected-route hash (#portal only — the back
     office has no URL at all since Report 24). */
  const [svcLayout, setSvcLayout] = useState<"list" | "grid">("list");
  const [aboutVidOk, setAboutVidOk] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const u = upgradeStrings(lang);
  const ps = portalStrings(lang);
  const ms = menuStrings(lang);

  /* Website management (Report 23): branding + editable homepage /
     footer copy come from Admin → Settings → Website Settings. Every
     value falls back to the built-in translated default when the
     admin has not set it, so the site is never blank. */
  const siteName = (settings["site_name"] ?? "").trim() || "S SERVICES";
  const brandTagline = (settings["site_tagline"] ?? "").trim() || t.tagline;
  const siteLogo = (settings["site_logo"] ?? "").trim();
  const heroTitle = (settings["hero_title"] ?? "").trim() || t.heroTitle;
  const heroSub = (settings["hero_sub"] ?? "").trim() || t.heroSub;
  const footerNote = (settings["footer_text"] ?? "").trim() || t.footerNote;
  const socials = (
    [
      ["social_facebook", "Facebook"],
      ["social_instagram", "Instagram"],
      ["social_youtube", "YouTube"],
      ["social_linkedin", "LinkedIn"],
    ] as const
  )
    .map(([key, label]) => ({ label, href: (settings[key] ?? "").trim() }))
    .filter((s) => s.href !== "");

  /* Favicon + document title follow the admin's branding when set. */
  useEffect(() => {
    const fav = (settings["site_favicon"] ?? "").trim() || siteLogo;
    if (fav) {
      let link = document.querySelector<HTMLLinkElement>("link[rel='icon']");
      if (!link) {
        link = document.createElement("link");
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = fav;
    }
    if ((settings["site_name"] ?? "").trim())
      document.title = `${siteName} — ${brandTagline}`;
  }, [settings, siteLogo, siteName, brandTagline]);

  /* Drawer closes on Escape. */
  useEffect(() => {
    if (!menuOpen) return;
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [menuOpen]);

  const goMenu = (v: View) => {
    setMenuOpen(false);
    if (v === "portal") window.location.hash = "#portal";
    go(v);
  };
  /* Hash routing exists for the Client Portal ONLY. There is
     deliberately NO hash route to the back office (Report 24): the
     old #admin hash was removed completely, so a URL ending in
     #admin opens nothing admin-related — the public website simply
     loads and the dead fragment is stripped from the address bar.
     The Admin Dashboard can be reached solely through the dedicated
     Admin Login page (the "Admin Login" item in the menu drawer /
     footer), which renders the dashboard only after the server has
     verified a valid staff session and its role. */
  useEffect(() => {
    const apply = () => {
      if (window.location.hash === "#admin") {
        try {
          window.history.replaceState(
            null,
            "",
            window.location.pathname + window.location.search,
          );
        } catch {
          /* Restricted document: the inert hash is ignored anyway. */
        }
        return;
      }
      if (window.location.hash === "#portal") setView("portal");
    };
    apply();
    window.addEventListener("hashchange", apply);
    return () => window.removeEventListener("hashchange", apply);
  }, []);
  /* Floating emergency buttons: rendered ONLY when the admin has
     configured a real number in Settings and has not switched the
     button off there. No number is ever invented. */
  const showFloatCall =
    view !== "admin" && phone !== "" && (settings["float_call_enabled"] ?? "1") !== "0";
  const showFloatWa =
    view !== "admin" && whatsapp !== "" && (settings["float_whatsapp_enabled"] ?? "1") !== "0";
  const floatWaMsg = (settings["float_whatsapp_message"] ?? "").trim();
  const floatWaHref = whatsapp
    ? `https://wa.me/${whatsapp.replace(/[^0-9]/g, "")}${floatWaMsg ? `?text=${encodeURIComponent(floatWaMsg)}` : ""}`
    : "";

  const ServiceCard = ({ s, i }: { s: Svc; i: number }) => {
    const det = ALL_DETAILS[s.slug];
    const img = det ? IMG[det.img] : undefined;
    return (
      <article
        className="reveal card-hover overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--surface)]"
        style={{ animationDelay: `${(i % 6) * 70}ms` }}
      >
        {img && (
          <button type="button" className="block w-full" onClick={() => { setSlug(s.slug); go("detail"); }} aria-label={serviceName(s)}>
            <img src={img} alt={serviceName(s)} className="h-36 w-full object-cover" loading="lazy" decoding="async" />
          </button>
        )}
        <div className="p-4">
          <p className="text-xs font-bold tracking-wide text-[var(--accent)]">
            {s.category === "electrical" ? `⚡ ${t.electrical}` : `💧 ${t.plumbing}`}
          </p>
          <h3 className="mt-1 font-display text-lg font-bold leading-snug">{serviceName(s)}</h3>
          <p className="mt-1 line-clamp-2 text-sm text-[var(--dim)]">
            {det ? serviceDesc(s.slug, lang, det.descIt, det.descEn) : ""}
          </p>
          <div className="mt-3 flex items-center justify-between gap-2">
            <span className="text-sm font-bold">
              {s.base_price_cents != null
                ? `${t.fromPrice} ${money(s.base_price_cents, settings["default_currency"] || "EUR")}`
                : <span className="font-semibold text-[var(--dim)]">{t.priceOnQuote}</span>}
            </span>
            <button type="button" className="btn-primary rounded-lg px-3.5 py-2 font-display text-sm font-bold"
              onClick={() => { setSlug(s.slug); go("detail"); }}>
              {t.viewService}
            </button>
          </div>
        </div>
      </article>
    );
  };

  /* List-wise service row (Option-1 upgrade): photo, category, name,
     description, price and direct Book / Quote calls to action. */
  const ServiceRow = ({ s, i }: { s: Svc; i: number }) => {
    const det = ALL_DETAILS[s.slug];
    const img = det ? IMG[det.img] : undefined;
    return (
      <article
        className="reveal card-hover flex gap-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-3 sm:p-4"
        style={{ animationDelay: `${(i % 6) * 60}ms` }}
      >
        {img && (
          <button type="button" className="hidden shrink-0 min-[480px]:block" onClick={() => { setSlug(s.slug); go("detail"); }} aria-label={serviceName(s)}>
            <img src={img} alt={serviceName(s)} className="h-full max-h-28 w-24 rounded-xl object-cover sm:w-32" loading="lazy" decoding="async" />
          </button>
        )}
        <div className="min-w-0 flex-1">
          <p className="text-xs font-bold tracking-wide text-[var(--accent)]">
            {s.category === "electrical" ? `⚡ ${t.electrical}` : `💧 ${t.plumbing}`}
          </p>
          <h3 className="mt-0.5 font-display text-lg font-bold leading-snug">{serviceName(s)}</h3>
          <p className="mt-1 line-clamp-2 text-sm text-[var(--dim)]">
            {det ? serviceDesc(s.slug, lang, det.descIt, det.descEn) : ""}
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="me-1 text-sm font-bold">
              {s.base_price_cents != null
                ? `${t.fromPrice} ${money(s.base_price_cents, settings["default_currency"] || "EUR")}`
                : <span className="font-semibold text-[var(--dim)]">{t.priceOnQuote}</span>}
            </span>
            <button type="button" className="btn-primary rounded-lg px-3.5 py-2 font-display text-sm font-bold"
              onClick={() => { setSlug(s.slug); go("booking"); }}>
              {t.bookNow}
            </button>
            <button type="button" className="rounded-lg border border-[var(--border)] px-3.5 py-2 font-display text-sm font-bold"
              onClick={() => { setSlug(s.slug); go("quote"); }}>
              {t.getQuote}
            </button>
            <button type="button" className="rounded-lg px-2 py-2 font-display text-sm font-bold text-[var(--accent)]"
              onClick={() => { setSlug(s.slug); go("detail"); }}>
              {t.viewService} →
            </button>
          </div>
        </div>
      </article>
    );
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)]">
      <div ref={progressRef} className="scroll-progress" style={{ width: 0 }} aria-hidden />
      <SafeAreaTopScrim backgroundColor="var(--bg)" />

      {/* Header — mobile-first: wraps, never scrolls sideways */}
      <header className="sticky top-0 z-50 max-w-[100vw] overflow-x-clip border-b border-[var(--border)] bg-[color-mix(in_srgb,var(--bg)_88%,transparent)] pt-safe backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center gap-x-2 gap-y-2 px-3 py-2.5 sm:gap-3 sm:px-4 sm:py-3">
          <button type="button" onClick={() => go("home")} className="flex min-w-0 items-center gap-2 sm:gap-2.5" aria-label={`${siteName} — Home`}>
            {siteLogo ? (
              <img src={siteLogo} alt={siteName} className="h-9 w-auto max-w-[120px] shrink-0 object-contain sm:h-10" />
            ) : (
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl font-display text-lg font-black text-[var(--on-accent)] sm:h-10 sm:w-10 sm:text-xl" style={{ background: "var(--grad)" }}>S</span>
            )}
            <span className="min-w-0 text-start leading-none">
              <span className="block truncate font-display text-base font-black tracking-tight sm:text-lg">{siteName}</span>
              <span className="mt-0.5 hidden max-w-[250px] text-[10px] font-semibold uppercase leading-snug tracking-wider text-[var(--dim)] min-[480px]:block">{brandTagline}</span>
            </span>
          </button>
          <div className="ms-auto flex min-w-0 flex-wrap items-center justify-end gap-1.5 sm:gap-2">
            <button
              type="button"
              className="grid h-9 w-10 place-items-center rounded-lg border border-[var(--border)] sm:h-10"
              onClick={() => setMenuOpen(true)}
              aria-expanded={menuOpen}
              aria-haspopup="dialog"
              aria-label={ms.menu}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" aria-hidden>
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="3" y1="12" x2="21" y2="12" />
                <line x1="3" y1="18" x2="21" y2="18" />
              </svg>
            </button>
            <div>
              <label htmlFor="lang-sel" className="sr-only">{t.language}</label>
              <select id="lang-sel" aria-label={t.language} value={lang} onChange={(e) => setLang(e.target.value as LangCode)} className="!w-[7.25rem] !px-2 !py-1.5 text-[13px] sm:!w-auto sm:!py-2 sm:text-sm">
                {LANGS.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
              </select>
            </div>
            <div className="relative">
              <button type="button" className="rounded-lg border border-[var(--border)] px-2.5 py-1.5 text-sm font-bold sm:px-3 sm:py-2" onClick={() => setThemeOpen((o) => !o)} aria-expanded={themeOpen} aria-label={t.theme}>
                🎨 <span className="hidden sm:inline">{t.theme}</span>
              </button>
              {themeOpen && (
                <div className="absolute end-0 z-50 mt-2 w-[min(18rem,calc(100vw-1.5rem))] rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 shadow-2xl">
                  <p className="text-xs font-bold text-[var(--dim)]">{t.theme}</p>
                  <div className="mt-2 grid gap-1.5">
                    {THEMES.map((th) => (
                      <button key={th.id} type="button" onClick={() => setTheme(th.id)}
                        className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-start text-sm font-semibold ${activeTheme === th.id ? "border-[var(--accent)]" : "border-[var(--border)]"}`}>
                        <span className="flex -space-x-1">
                          {th.sw.map((c) => <span key={c} className="h-4 w-4 rounded-full border border-white/40" style={{ background: c }} />)}
                        </span>
                        {lang === "it" ? th.nameIt : th.nameEn}
                      </button>
                    ))}
                  </div>
                  <p className="mt-3 text-xs font-bold text-[var(--dim)]">{t.mode}</p>
                  <div className="mt-1.5 flex gap-1.5">
                    {(["light", "dark", "system"] as const).map((m) => (
                      <button key={m} type="button" onClick={() => setMode(m)}
                        className={`flex-1 rounded-lg px-2 py-1.5 text-sm font-bold ${mode === m ? "btn-primary" : "border border-[var(--border)]"}`}>
                        {m === "light" ? `☀️ ${t.light}` : m === "dark" ? `🌙 ${t.dark}` : `⚙️ ${t.system}`}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <button type="button" className="emergency-pulse rounded-lg px-2.5 py-1.5 font-display text-sm font-black sm:px-3 sm:py-2" onClick={() => go("emergency")} aria-label={t.emergency}>
              🚨 <span className="hidden min-[480px]:inline">{t.emergency}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hamburger navigation drawer (Report 23) — replaces the old
          crowded pill nav. Slides in from the inline-end side on every
          viewport size, closes on selection, on the overlay, or with
          Escape. The Admin Login item only opens the dedicated Admin
          Login page (staff login screen / one-time setup) — it sets
          no URL, and no admin controls are ever exposed here. */}
      <div
        className={`fixed inset-0 z-[70] ${menuOpen ? "" : "pointer-events-none"}`}
        aria-hidden={!menuOpen}
      >
        <div
          className={`absolute inset-0 bg-black/55 transition-opacity duration-300 ${menuOpen ? "opacity-100" : "opacity-0"}`}
          onClick={() => setMenuOpen(false)}
        />
        <nav
          role="dialog"
          aria-modal="true"
          aria-label={ms.menu}
          className={`absolute inset-y-0 end-0 flex w-[min(20rem,88vw)] flex-col overflow-y-auto bg-[var(--surface)] shadow-2xl transition-transform duration-300 ease-out ${menuOpen ? "translate-x-0" : "translate-x-full rtl:-translate-x-full"}`}
        >
          <div className="flex items-center justify-between gap-2 border-b border-[var(--border)] px-4 py-3.5">
            <span className="flex min-w-0 items-center gap-2">
              {siteLogo ? (
                <img src={siteLogo} alt="" className="h-8 w-auto max-w-[90px] object-contain" />
              ) : (
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg font-display text-base font-black text-[var(--on-accent)]" style={{ background: "var(--grad)" }}>S</span>
              )}
              <span className="truncate font-display text-base font-black">{siteName}</span>
            </span>
            <button
              type="button"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-[var(--border)] text-lg leading-none"
              onClick={() => setMenuOpen(false)}
              aria-label={ms.closeMenu}
            >
              ✕
            </button>
          </div>
          <div className="grid gap-1 p-3">
            {([
              ["home", t.home],
              ["services", t.services],
              ["booking", ms.bookService],
              ["quote", t.getQuote],
              ["about", t.about],
              ["areas", t.areas],
              ["contact", t.contact],
              ["emergency", `🚨 ${t.emergency}`],
            ] as [View, string][]).map(([v, label]) => (
              <button
                key={v}
                type="button"
                tabIndex={menuOpen ? 0 : -1}
                onClick={() => goMenu(v)}
                className={`rounded-xl px-4 py-3 text-start font-display text-[15px] font-bold ${view === v || (v === "services" && view === "detail") ? "btn-primary" : "hover:bg-[var(--surface2)]"}`}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="mt-auto grid gap-1 border-t border-[var(--border)] p-3">
            <button
              type="button"
              tabIndex={menuOpen ? 0 : -1}
              onClick={() => goMenu("portal")}
              className={`rounded-xl px-4 py-3 text-start font-display text-[15px] font-bold ${view === "portal" ? "btn-primary" : "hover:bg-[var(--surface2)]"}`}
            >
              👤 {ms.clientAccess}
            </button>
            <button
              type="button"
              tabIndex={menuOpen ? 0 : -1}
              onClick={() => goMenu("admin")}
              className="rounded-xl px-4 py-3 text-start font-display text-[15px] font-bold text-[var(--dim)] hover:bg-[var(--surface2)] hover:text-[var(--text)]"
            >
              🔐 {ms.adminLogin}
            </button>
          </div>
        </nav>
      </div>

      <main>
        {state.isPending && !slowLoad && (
          <div className="grid place-items-center py-24">
            <div className="loader-s"><span className="font-display text-xl font-black text-[var(--accent)]">S</span></div>
          </div>
        )}
        {state.isPending && slowLoad && (
          <div className="mx-auto max-w-md px-4 py-24 text-center" role="status">
            <div className="loader-s mx-auto"><span className="font-display text-xl font-black text-[var(--accent)]">S</span></div>
            <p className="mt-5 font-display text-lg font-bold">
              {lang === "it" ? "Il caricamento richiede più tempo del solito…" : "Loading is taking longer than usual…"}
            </p>
            <p className="mt-2 text-sm text-[var(--dim)]">
              {lang === "it"
                ? "La connessione è lenta o instabile. La pagina continua a provare; se non si carica, tocca Ricarica."
                : "The connection is slow or unstable. The page keeps trying; if it does not load, tap Reload."}
            </p>
            <button type="button" className="btn-primary mt-5 rounded-xl px-6 py-3 font-display font-black" onClick={() => window.location.reload()}>
              {lang === "it" ? "Ricarica" : "Reload"}
            </button>
          </div>
        )}
        {state.error && (
          <div className="p-10 text-center">
            <p className="text-red-500">Failed to load. / Caricamento non riuscito.</p>
            <button type="button" className="btn-primary mt-4 rounded-xl px-6 py-3 font-display font-black" onClick={() => window.location.reload()}>
              Ricarica / Reload
            </button>
          </div>
        )}

        {d && view === "home" && (
          <>
            {/* HERO */}
            <section className="relative overflow-hidden">
              <div className="absolute inset-0">
                {/* Photo slideshow always renders underneath: it is the
                    poster fallback — visible instantly, under reduced
                    motion, and whenever every hero video fails to load. */}
                {HERO_SLIDES.map((src, i) => (
                  <img key={src} src={src} alt="" aria-hidden={i !== slide}
                    className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${i === slide ? "hero-slide opacity-100" : "opacity-0"}`} loading={i === 0 ? "eager" : "lazy"} decoding="async" />
                ))}
                {showHeroVideos && heroPlaylist.map((src, i) => (
                  <video
                    key={src}
                    ref={(el) => { heroVidRefs.current[i] = el; }}
                    className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${i === vidIdx ? "opacity-100" : "pointer-events-none opacity-0"}`}
                    src={src}
                    poster={i === 0 ? heroElectrical : heroPlumbing}
                    muted
                    playsInline
                    preload={i === vidIdx ? "auto" : "metadata"}
                    loop={heroPlaylist.length === 1}
                    aria-hidden={i !== vidIdx}
                    aria-label="S SERVICES at work"
                    onEnded={() => { if (i === vidIdx && heroPlaylist.length > 1) setHeroVidIdx((idx) => (idx + 1) % heroPlaylist.length); }}
                    onError={() => setFailedVids((prev) => new Set(prev).add(src))}
                  />
                ))}
                <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(5,8,12,.45), rgba(5,8,12,.78) 70%, var(--bg))" }} />
              </div>
              <div className="relative mx-auto max-w-6xl px-4 pb-20 pt-16 sm:pt-24">
                <p className="reveal in font-display text-sm font-bold uppercase tracking-[0.25em] text-white/80">{siteName} · Italia → Europa</p>
                <h1 className="reveal in mt-3 max-w-3xl font-display text-4xl font-black leading-[1.05] text-white sm:text-6xl">
                  {heroTitle}
                </h1>
                <p className="reveal in mt-4 max-w-xl text-lg text-white/85">{heroSub}</p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <button type="button" className="btn-primary rounded-xl px-6 py-3.5 font-display text-base font-black"
                    onClick={() => { setCatFilter("electrical"); go("services"); }}>
                    ⚡ {t.exploreElectrical}
                  </button>
                  <button type="button" className="rounded-xl border border-white/50 bg-white/10 px-6 py-3.5 font-display text-base font-black text-white backdrop-blur transition hover:bg-white/20"
                    onClick={() => { setCatFilter("plumbing"); go("services"); }}>
                    💧 {t.explorePlumbing}
                  </button>
                </div>
                <div className="mt-6 flex gap-2" role="tablist" aria-label="Hero slides">
                  {showHeroVideos
                    ? heroPlaylist.map((src, i) => (
                      <button key={src} type="button" role="tab" aria-selected={vidIdx === i} aria-label={`Video ${i + 1}`} onClick={() => setHeroVidIdx(i)}
                        className={`h-1.5 rounded-full transition-all ${vidIdx === i ? "w-10 bg-white" : "w-4 bg-white/40"}`} />
                    ))
                    : HERO_SLIDES.map((src, i) => (
                      <button key={src} type="button" role="tab" aria-selected={slide === i} aria-label={`Slide ${i + 1}`} onClick={() => setSlide(i)}
                        className={`h-1.5 rounded-full transition-all ${slide === i ? "w-10 bg-white" : "w-4 bg-white/40"}`} />
                    ))}
                </div>
              </div>
            </section>

            {/* Marquee */}
            <div className="overflow-hidden border-y border-[var(--border)] bg-[var(--surface)] py-3" aria-hidden>
              <div className="marquee-track flex w-max gap-10 whitespace-nowrap font-display text-sm font-bold text-[var(--dim)]">
                {[0, 1].map((n) => (
                  <span key={n} className="flex gap-10">
                    {published.slice(0, 14).map((s) => <span key={`${n}-${s.slug}`}>{s.category === "electrical" ? "⚡" : "💧"} {serviceName(s)}</span>)}
                  </span>
                ))}
              </div>
            </div>

            {/* Scroll-driven cinematic storytelling (GSAP ScrollTrigger scrub) */}
            <ScrollyBoundary lang={lang} onBook={() => go("booking")}>
              <Scrollytelling
                lang={lang}
                heroVideo={heroPlaylist[0] ?? ""}
                onBook={() => go("booking")}
                onExploreElectrical={() => { setCatFilter("electrical"); go("services"); }}
                onExplorePlumbing={() => { setCatFilter("plumbing"); go("services"); }}
              />
            </ScrollyBoundary>

            {/* Emergency strip */}
            <section className="mx-auto max-w-6xl px-4 py-10">
              <div className="reveal rounded-3xl border-2 border-red-500/60 bg-[var(--surface)] p-6 sm:p-8" style={{ background: "linear-gradient(120deg, color-mix(in srgb, #e5484d 12%, var(--surface)), var(--surface))" }}>
                <h2 className="font-display text-2xl font-black sm:text-3xl">🚨 {t.emergencyTitle}</h2>
                <p className="mt-2 max-w-2xl text-[var(--dim)]">{t.emergencySub}</p>
                <p className="mt-2 text-sm font-semibold">{t.emergencyTypes}</p>
                {emergencyOn && <p className="mt-2 text-sm font-bold text-emerald-500">{settings["emergency_enabled"]} {settings["emergency_note"]}</p>}
                <div className="mt-5 flex flex-wrap gap-3">
                  <button type="button" className="emergency-pulse rounded-xl px-6 py-3 font-display font-black" onClick={() => go("emergency")}>{t.sendEmergency}</button>
                  {phone && <a className="rounded-xl border border-[var(--border)] bg-[var(--surface)] px-5 py-3 font-display font-bold" href={`tel:${phone}`}>📞 {t.callNow}</a>}
                  {whatsapp && <a className="rounded-xl border border-[var(--border)] bg-[var(--surface)] px-5 py-3 font-display font-bold" href={`https://wa.me/${whatsapp.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer">💬 {t.whatsapp}</a>}
                </div>
                <p className="mt-3 text-xs text-[var(--dim)]">{t.priorityNote}</p>
              </div>
            </section>

            {/* Stats */}
            <section ref={statsRef} className="mx-auto max-w-6xl px-4 pb-4">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {[
                  [cServices, lang === "it" ? "Servizi professionali" : "Professional services"],
                  [cLangs, lang === "it" ? "Lingue supportate" : "Languages supported"],
                  [cThemes, lang === "it" ? "Temi di design" : "Design themes"],
                  [cAreas, lang === "it" ? "Zone attive" : "Active areas"],
                ].map(([v, label]) => (
                  <div key={label} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 text-center">
                    <p className="font-display text-4xl font-black tabular-nums" style={{ color: "var(--accent)" }} aria-label={String(v)}>{v}</p>
                    <p className="mt-1 text-xs font-bold uppercase tracking-wide text-[var(--dim)]">{label}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Public offers & promotions (Report 22) — only live
                public offers from getState; renders nothing when the
                admin has none running. No login required. */}
            {d.offers.length > 0 && (
              <section className="mx-auto max-w-6xl px-4 py-6">
                <h2 className="reveal font-display text-3xl font-black">🎁 {ps.offersTitle}</h2>
                <p className="reveal mt-2 max-w-2xl text-[var(--dim)]">{ps.offersSub}</p>
                <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {d.offers.map((o) => (
                    <article key={o.id} className="reveal card-hover rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <h3 className="font-display font-bold">{o.title}</h3>
                        <span className="rounded-full bg-[var(--accent)]/15 px-2.5 py-0.5 text-xs font-bold text-[var(--accent)]">
                          {o.discount_type === "percent"
                            ? `${o.discount_value}% ${ps.offLabel}`
                            : `${money(o.discount_value, settings["default_currency"] || "EUR")} ${ps.offLabel}`}
                        </span>
                      </div>
                      {o.description && <p className="mt-2 text-sm text-[var(--dim)]">{o.description}</p>}
                      <p className="mt-2 text-xs text-[var(--dim)]">
                        {o.expires_at ? `${ps.validUntil} ${o.expires_at}` : ps.noExpiry}
                      </p>
                      <button type="button" className="btn-primary mt-4 rounded-xl px-4 py-2 font-display text-sm font-bold" onClick={() => go("booking")}>
                        {t.bookNow}
                      </button>
                    </article>
                  ))}
                </div>
              </section>
            )}

            {/* Electrical showcase */}
            <section className="mx-auto max-w-6xl px-4 py-10">
              <div className="flex items-end justify-between gap-3">
                <h2 className="font-display text-3xl font-black">⚡ {t.electrical}</h2>
                <button type="button" className="font-display text-sm font-bold text-[var(--accent)]" onClick={() => { setCatFilter("electrical"); go("services"); }}>{t.allServices} →</button>
              </div>
              <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {published.filter((s) => s.category === "electrical").slice(0, 6).map((s, i) => <ServiceCard key={s.slug} s={s} i={i} />)}
              </div>
            </section>

            {/* Plumbing showcase */}
            <section className="mx-auto max-w-6xl px-4 py-6">
              <div className="flex items-end justify-between gap-3">
                <h2 className="font-display text-3xl font-black">💧 {t.plumbing}</h2>
                <button type="button" className="font-display text-sm font-bold text-[var(--accent)]" onClick={() => { setCatFilter("plumbing"); go("services"); }}>{t.allServices} →</button>
              </div>
              <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {published.filter((s) => s.category === "plumbing").slice(0, 6).map((s, i) => <ServiceCard key={s.slug} s={s} i={i} />)}
              </div>
            </section>

            {/* Craft films — real AI-generated MP4s made for this site,
                with poster frames and photo fallbacks underneath */}
            <section className="mx-auto max-w-6xl px-4 py-10">
              <h2 className="reveal font-display text-3xl font-black">🎬 {u.craftTitle}</h2>
              <p className="reveal mt-2 max-w-2xl text-[var(--dim)]">{u.craftSub}</p>
              <div className="mt-5 grid gap-4 md:grid-cols-2">
                {([
                  [craftElectrical, craftElectricalPoster, heroElectrical, `⚡ ${t.electrical}`],
                  [craftPlumbing, craftPlumbingPoster, heroPlumbing, `💧 ${t.plumbing}`],
                ] as const).map(([src, poster, fallback, label]) => (
                  <figure key={src} className="reveal relative overflow-hidden rounded-3xl border border-[var(--border)] bg-black">
                    <img src={fallback} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover" loading="lazy" decoding="async" />
                    {!reducedMotion && (
                      <video
                        className="relative aspect-video w-full object-cover"
                        src={src}
                        poster={poster}
                        data-io-video
                        muted
                        loop
                        playsInline
                        preload="none"
                        aria-label={`${u.craftTitle} — ${label}`}
                      />
                    )}
                    {reducedMotion && (
                      <img src={poster} alt={`${u.craftTitle} — ${label}`} className="relative aspect-video w-full object-cover" loading="lazy" decoding="async" />
                    )}
                    <figcaption className="absolute bottom-0 start-0 m-3 rounded-full bg-black/55 px-3 py-1 font-display text-sm font-bold text-white backdrop-blur">
                      {label}
                    </figcaption>
                  </figure>
                ))}
              </div>
            </section>

            {/* Why us + process */}
            <section className="mx-auto max-w-6xl px-4 py-10">
              <div className="grid gap-8 lg:grid-cols-2">
                <div className="reveal">
                  <h2 className="font-display text-3xl font-black">{t.whyUs}</h2>
                  <div className="mt-5 grid gap-3">
                    {[
                      ["🛡️", lang === "it" ? "Sicurezza prima di tutto" : "Safety first", lang === "it" ? "Procedure di sicurezza rigorose, dispositivi di protezione e verifiche complete a fine intervento." : "Strict safety procedures, protective equipment and full testing at the end of every job."],
                      ["📋", lang === "it" ? "Preventivi trasparenti" : "Transparent quotations", lang === "it" ? "Manodopera, materiali e oneri separati e chiari. Nessun costo nascosto, nessuna stima automatica spacciata per preventivo." : "Labour, materials and charges itemised clearly. No hidden costs, no automatic estimate passed off as a quotation."],
                      ["🌍", lang === "it" ? "Respiro internazionale" : "International outlook", lang === "it" ? "Piattaforma in 11 lingue con supporto RTL, nata in Italia e progettata per crescere in Europa." : "A platform in 11 languages with RTL support, born in Italy and designed to grow across Europe."],
                      ["🎨", lang === "it" ? "Esperienza su misura" : "A tailored experience", lang === "it" ? "Sei temi professionali, modalità chiara e scura, Area Clienti per seguire ogni pratica in tempo reale." : "Six professional themes, light and dark modes, and a Client Portal to follow every job in real time."],
                    ].map(([icon, title, body]) => (
                      <div key={title} className="floaty flex gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4" style={{ animationDelay: `${Math.random() * 2}s` }}>
                        <span className="text-2xl" aria-hidden>{icon}</span>
                        <div>
                          <h3 className="font-display font-bold">{title}</h3>
                          <p className="text-sm text-[var(--dim)]">{body}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="reveal">
                  <h2 className="font-display text-3xl font-black">{t.process}</h2>
                  <ol className="mt-5 grid gap-3">
                    {t.processSteps.map((step, i) => (
                      <li key={step} className="flex items-center gap-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full font-display text-lg font-black text-[var(--on-accent)]" style={{ background: "var(--grad)" }}>{i + 1}</span>
                        <span className="font-display text-lg font-bold">{step}</span>
                      </li>
                    ))}
                  </ol>
                  <div className="mt-6 overflow-hidden rounded-2xl">
                    <img src={inspectionImg} alt={lang === "it" ? "Tecnico durante una verifica elettrica" : "Technician during an electrical inspection"} className="h-52 w-full object-cover" loading="lazy" />
                  </div>
                </div>
              </div>
            </section>

            {/* Projects */}
            <section className="mx-auto max-w-6xl px-4 py-6">
              <h2 className="font-display text-3xl font-black">🏗️ {t.projects}</h2>
              {d.projects.length === 0 ? (
                <p className="mt-4 rounded-2xl bg-[var(--surface2)] p-5 text-[var(--dim)]">{t.noProjects}</p>
              ) : (
                <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {d.projects.map((p) => (
                    <article key={p.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
                      <h3 className="font-display font-bold">{p.title} {p.is_demo && <span className="ms-1 rounded bg-amber-500/20 px-2 py-0.5 text-xs font-bold text-amber-500">DEMO</span>}</h3>
                      <p className="mt-1 text-sm text-[var(--dim)]">{p.location} · {p.category}</p>
                      <p className="mt-2 text-sm">{p.description}</p>
                    </article>
                  ))}
                </div>
              )}
            </section>

            {/* Areas + maintenance */}
            <section className="mx-auto max-w-6xl px-4 py-6">
              <div className="grid gap-8 lg:grid-cols-2">
                <div>
                  <h2 className="font-display text-3xl font-black">📍 {t.areas}</h2>
                  {d.areas.length === 0 ? (
                    <p className="mt-4 rounded-2xl bg-[var(--surface2)] p-5 text-[var(--dim)]">{t.noAreas}</p>
                  ) : (
                    <ul className="mt-4 grid gap-2">
                      {d.areas.map((a) => (
                        <li key={a.id} className="rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-3 font-semibold">
                          {a.city}{a.region ? `, ${a.region}` : ""} — {a.country}
                          <span className="block text-sm font-normal text-[var(--dim)]">
                            {a.electrical ? "⚡ " : ""}{a.plumbing ? "💧 " : ""}{a.emergency ? "🚨" : ""} {a.postal_codes}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div className="reveal rounded-3xl p-6 text-white" style={{ background: "var(--grad)" }}>
                  <h2 className="font-display text-2xl font-black text-[var(--on-accent)]">🔧 {t.maintenance}</h2>
                  <p className="mt-2 text-[var(--on-accent)] opacity-90">{t.maintenanceSub}</p>
                  <button type="button" className="mt-5 rounded-xl bg-black/25 px-5 py-3 font-display font-bold text-white" onClick={() => go("contact")}>{t.contact} →</button>
                </div>
              </div>
            </section>

            {/* Interactive service-area map — the circle is the area
                covered from the company's base; fully zoomable and
                pannable. Configuration lives in Admin → Settings. */}
            <section className="mx-auto max-w-6xl px-4 py-6">
              <div className="flex flex-wrap items-center gap-3">
                <h2 className="font-display text-3xl font-black">🗺️ {u.mapTitle}</h2>
                {mapCfg.isDemo && (
                  <span className="rounded bg-amber-500/20 px-2.5 py-1 text-xs font-black text-amber-500">DEMO</span>
                )}
              </div>
              <p className="mt-2 max-w-2xl text-[var(--dim)]">{u.mapSub}</p>
              {mapCfg.isDemo && (
                <p className="mt-2 max-w-2xl text-sm font-semibold text-amber-500">{u.mapDemo}</p>
              )}
              <div className="mt-5 grid items-start gap-4 lg:grid-cols-[1fr_320px]">
                <ServiceAreaMap
                  cfg={mapCfg}
                  dark={resolvedMode === "dark"}
                  strings={{ unavailable: u.mapUnavailable, directions: u.mapDirections, radius: u.mapRadius }}
                />
                <div className="rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-5">
                  <p className="font-display text-lg font-black">
                    📍 {mapCfg.name}
                    {mapCfg.isDemo && <span className="ms-2 rounded bg-amber-500/20 px-2 py-0.5 align-middle text-xs font-black text-amber-500">DEMO</span>}
                  </p>
                  <p className="mt-1 text-sm text-[var(--dim)]">{mapCfg.address}</p>
                  <p className="mt-3 text-sm">
                    <span className="font-bold">{u.mapRadius}:</span> {mapCfg.radiusKm} km
                  </p>
                  <p className="mt-1 text-sm text-[var(--dim)]">⚡ {t.electrical} · 💧 {t.plumbing}</p>
                  {mapDirUrl && (
                    <a
                      href={mapDirUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-primary mt-4 inline-block rounded-xl px-5 py-2.5 font-display text-sm font-black"
                    >
                      🧭 {u.mapDirections}
                    </a>
                  )}
                  {(settings["company_hours"] ?? "") && (
                    <p className="mt-4 text-sm"><span className="font-bold">🕐 {u.hoursLabel}:</span> {settings["company_hours"]}</p>
                  )}
                  {(settings["contact_availability"] ?? "") && (
                    <p className="mt-1 text-sm"><span className="font-bold">✅ {u.availabilityLabel}:</span> {settings["contact_availability"]}</p>
                  )}
                </div>
              </div>
            </section>

            {/* Reviews + FAQ */}
            <section className="mx-auto max-w-6xl px-4 py-6">
              <div className="grid gap-8 lg:grid-cols-2">
                <div>
                  <h2 className="font-display text-3xl font-black">⭐ {t.reviews}</h2>
                  {d.reviews.length === 0 ? (
                    <p className="mt-4 rounded-2xl bg-[var(--surface2)] p-5 text-[var(--dim)]">{t.noReviews}</p>
                  ) : (
                    <ul className="mt-4 grid gap-3">
                      {d.reviews.map((r) => (
                        <li key={r.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                          <p className="font-bold">{"★".repeat(Math.round(r.rating))} {r.customer_name}</p>
                          <p className="mt-1 text-sm">{r.body}</p>
                        </li>
                      ))}
                    </ul>
                  )}
                  <div className="mt-5 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
                    <h3 className="font-display text-lg font-bold">{t.leaveReview}</h3>
                    <div className="mt-3"><ReviewForm t={t} services={published} lang={lang} /></div>
                  </div>
                </div>
                <div>
                  <h2 className="font-display text-3xl font-black">❓ {t.faq}</h2>
                  <div className="mt-4 grid gap-2">
                    {FAQS.map((f, i) => {
                      const loc = FAQ_LOCALIZED[lang]?.[i];
                      const q = lang === "it" ? f.qIt : lang.startsWith("en") ? f.qEn : loc?.q ?? f.qEn;
                      const a = lang === "it" ? f.aIt : lang.startsWith("en") ? f.aEn : loc?.a ?? f.aEn;
                      return (
                        <details key={f.qEn} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                          <summary className="cursor-pointer font-display font-bold">{q}</summary>
                          <p className="mt-2 text-sm text-[var(--dim)]">{a}</p>
                        </details>
                      );
                    })}
                  </div>
                </div>
              </div>
            </section>

            {/* Quote CTA */}
            <section className="mx-auto max-w-6xl px-4 py-10">
              <div className="reveal rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-6 sm:p-8">
                <h2 className="font-display text-2xl font-black sm:text-3xl">{t.quoteTitle}</h2>
                <div className="mt-5"><QuoteForm t={t} lang={lang} services={published} /></div>
              </div>
            </section>
          </>
        )}

        {d && view === "services" && (
          <section className="mx-auto max-w-6xl px-4 py-10">
            <h2 className="font-display text-3xl font-black">{t.allServices}</h2>
            <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="flex flex-wrap gap-2">
                {(["all", "electrical", "plumbing"] as const).map((c) => (
                  <button key={c} type="button" onClick={() => setCatFilter(c)}
                    className={`rounded-full px-4 py-2 font-display text-sm font-bold ${catFilter === c ? "btn-primary" : "border border-[var(--border)]"}`}>
                    {c === "all" ? t.allServices : c === "electrical" ? `⚡ ${t.electrical}` : `💧 ${t.plumbing}`}
                  </button>
                ))}
                <button type="button" onClick={() => go("emergency")}
                  className="rounded-full border-2 border-red-500/60 px-4 py-2 font-display text-sm font-bold text-red-500">
                  🚨 {t.emergency}
                </button>
              </div>
              <div className="flex items-center gap-2 sm:ms-auto">
                <div className="flex overflow-hidden rounded-full border border-[var(--border)]" role="group" aria-label={`${u.listView} / ${u.gridView}`}>
                  {(["list", "grid"] as const).map((l) => (
                    <button key={l} type="button" aria-pressed={svcLayout === l} onClick={() => setSvcLayout(l)}
                      className={`px-3.5 py-2 font-display text-sm font-bold ${svcLayout === l ? "btn-primary" : ""}`}>
                      {l === "list" ? `☰ ${u.listView}` : `▦ ${u.gridView}`}
                    </button>
                  ))}
                </div>
                <div className="w-44 sm:w-56">
                  <label htmlFor="svc-search" className="sr-only">{t.search}</label>
                  <input id="svc-search" type="search" placeholder={t.search} value={query} onChange={(e) => setQuery(e.target.value)} />
                </div>
              </div>
            </div>
            {svcLayout === "list" ? (
              <div className="mt-6 grid gap-3">
                {filtered.map((s, i) => <ServiceRow key={s.slug} s={s} i={i} />)}
              </div>
            ) : (
              <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {filtered.map((s, i) => <ServiceCard key={s.slug} s={s} i={i} />)}
              </div>
            )}
            {filtered.length === 0 && <p className="mt-6 text-[var(--dim)]">—</p>}
          </section>
        )}

        {d && view === "detail" && current && detail && (
          <section className="mx-auto max-w-5xl px-4 py-10">
            <button type="button" className="font-display text-sm font-bold text-[var(--accent)]" onClick={() => go("services")}>← {t.allServices}</button>
            <div className="relative mt-4 overflow-hidden rounded-3xl">
              <img src={IMG[detail.img]} alt={serviceName(current)} className="h-64 w-full object-cover sm:h-80" />
              <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, transparent 30%, rgba(5,8,12,.85))" }} />
              <div className="absolute bottom-0 p-6">
                <p className="font-display text-sm font-bold uppercase tracking-widest text-white/75">{current.category === "electrical" ? `⚡ ${t.electrical}` : `💧 ${t.plumbing}`}</p>
                <h2 className="font-display text-3xl font-black text-white sm:text-4xl">{serviceName(current)}</h2>
              </div>
            </div>
            <p className="mt-6 text-lg leading-relaxed">{serviceDesc(current.slug, lang, detail.descIt, detail.descEn)}</p>
            <p className="mt-3 font-display text-xl font-black">
              {current.base_price_cents != null
                ? `${t.fromPrice} ${money(current.base_price_cents, settings["default_currency"] || "EUR")}`
                : t.priceOnQuote}
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <button type="button" className="btn-primary rounded-xl px-6 py-3 font-display font-black" onClick={() => go("booking")}>{t.bookNow}</button>
              <button type="button" className="rounded-xl border border-[var(--border)] px-6 py-3 font-display font-black" onClick={() => go("quote")}>{t.getQuote}</button>
            </div>
            <div className="mt-10 grid gap-8 md:grid-cols-3">
              <div>
                <h3 className="font-display text-xl font-bold">✓ {t.features}</h3>
                <ul className="mt-3 grid gap-2 text-sm">
                  {t.featuresList.map((f) => <li key={f} className="rounded-lg bg-[var(--surface2)] px-3 py-2">✓ {f}</li>)}
                </ul>
              </div>
              <div>
                <h3 className="font-display text-xl font-bold">⚙️ {t.workProcess}</h3>
                <ol className="mt-3 grid gap-2 text-sm">
                  {t.processSteps.map((s2, i) => <li key={s2} className="rounded-lg bg-[var(--surface2)] px-3 py-2"><b>{i + 1}.</b> {s2}</li>)}
                </ol>
              </div>
              <div>
                <h3 className="font-display text-xl font-bold">🛡️ {t.safety}</h3>
                <p className="mt-3 rounded-lg bg-[var(--surface2)] px-3 py-2 text-sm">{t.safetyText}</p>
              </div>
            </div>
            <h3 className="mt-10 font-display text-xl font-bold">{t.related}</h3>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              {published.filter((s) => s.category === current.category && s.slug !== current.slug).slice(0, 3).map((s, i) => <ServiceCard key={s.slug} s={s} i={i} />)}
            </div>
          </section>
        )}

        {d && view === "booking" && (
          <section className="mx-auto max-w-3xl px-4 py-10">
            <h2 className="font-display text-3xl font-black">{t.bookingTitle}</h2>
            <div className="mt-6 rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-6">
              <BookingForm t={t} lang={lang} services={published} slots={d.slots} initialService={slug} />
            </div>
          </section>
        )}

        {d && view === "quote" && (
          <section className="mx-auto max-w-3xl px-4 py-10">
            <h2 className="font-display text-3xl font-black">{t.quoteTitle}</h2>
            <div className="mt-6 rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-6">
              <QuoteForm t={t} lang={lang} services={published} initialService={slug} />
            </div>
          </section>
        )}

        {d && view === "emergency" && (
          <section className="mx-auto max-w-3xl px-4 py-10">
            <h2 className="font-display text-3xl font-black">🚨 {t.emergency}</h2>
            <p className="mt-2 text-[var(--dim)]">{t.emergencyTypes}</p>
            {emergencyOn && <p className="mt-2 font-bold text-emerald-500">{settings["emergency_enabled"]} {settings["emergency_note"]}</p>}
            <div className="mt-4 flex flex-wrap gap-3">
              {phone && <a className="emergency-pulse rounded-xl px-6 py-3 font-display font-black" href={`tel:${phone}`}>📞 {t.callNow} {phone}</a>}
              {whatsapp && <a className="rounded-xl border border-[var(--border)] px-6 py-3 font-display font-black" href={`https://wa.me/${whatsapp.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer">💬 {t.whatsapp}</a>}
            </div>
            <div className="mt-6 rounded-3xl border-2 border-red-500/50 bg-[var(--surface)] p-6">
              <BookingForm t={t} lang={lang} services={published} slots={d.slots} emergency />
            </div>
          </section>
        )}

        {d && view === "about" && (
          <section className="mx-auto max-w-4xl px-4 py-10">
            <h2 className="font-display text-3xl font-black">{t.aboutTitle} — S SERVICES</h2>
            <div className="relative mt-6 overflow-hidden rounded-3xl">
              <img src={heroPlumbing} alt="S SERVICES" className="h-64 w-full object-cover" />
              {!reducedMotion && aboutVidOk && (
                <video
                  className="absolute inset-0 h-full w-full object-cover"
                  src={craftPlumbing}
                  poster={craftPlumbingPoster}
                  data-io-video
                  muted
                  loop
                  playsInline
                  preload="none"
                  aria-label={`${u.craftTitle} — S SERVICES`}
                  onError={() => setAboutVidOk(false)}
                />
              )}
            </div>
            <div className="prose mt-6 grid gap-5 text-base leading-relaxed">
              <p>{(lang === "it" ? settings["about_it"] : settings["about_en"]) || (lang === "it"
                ? "S SERVICES è un'azienda professionale di impianti elettrici e idraulici per clienti residenziali, commerciali e industriali. Partiamo dall'Italia e cresciamo in Europa, una zona di servizio attivata alla volta: dichiariamo copertura solo dove operiamo davvero."
                : "S SERVICES is a professional electrical and plumbing company serving residential, commercial and industrial clients. We start in Italy and grow across Europe, one activated service area at a time — we only claim coverage where we actually operate.")}</p>
              {([
                [lang === "it" ? "La nostra missione" : "Our mission", lang === "it" ? "Lavori elettrici e idraulici fatti a regola d'arte: installazioni sicure, diagnosi oneste, preventivi trasparenti e finiture di cui andare fieri." : "Electrical and plumbing work done properly: safe installations, honest diagnoses, transparent quotations and finishes we are proud to sign."],
                [lang === "it" ? "La nostra visione" : "Our vision", lang === "it" ? "Diventare il partner tecnico di riferimento per abitazioni e aziende in Europa, unendo artigianalità e una piattaforma digitale moderna e multilingue." : "To become the reference technical partner for homes and businesses across Europe, combining craftsmanship with a modern, multilingual digital platform."],
                [lang === "it" ? "Impegno per qualità e sicurezza" : "Quality & safety commitment", lang === "it" ? "Ogni intervento segue procedure documentate: isolamento e verifica prima dei lavori, materiali a norma, collaudo completo a fine lavoro e report scritto di quanto eseguito." : "Every job follows documented procedures: isolation and verification before work, compliant materials, full testing at completion and a written record of what was done."],
              ] as [string, string][]).map(([h, b]) => (
                <div key={h}>
                  <h3 className="font-display text-xl font-bold">{h}</h3>
                  <p className="mt-1 text-[var(--dim)]">{b}</p>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <button type="button" className="btn-primary rounded-xl px-6 py-3 font-display font-black" onClick={() => go("booking")}>{t.bookNow}</button>
              <button type="button" className="rounded-xl border border-[var(--border)] px-6 py-3 font-display font-black" onClick={() => go("contact")}>{t.contact}</button>
            </div>
          </section>
        )}

        {d && view === "areas" && (
          <section className="mx-auto max-w-6xl px-4 py-10">
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="font-display text-3xl font-black">🗺️ {u.mapTitle}</h2>
              {mapCfg.isDemo && (
                <span className="rounded bg-amber-500/20 px-2.5 py-1 text-xs font-black text-amber-500">DEMO</span>
              )}
            </div>
            <p className="mt-2 max-w-2xl text-[var(--dim)]">{u.mapSub}</p>
            {mapCfg.isDemo && (
              <p className="mt-2 max-w-2xl text-sm font-semibold text-amber-500">{u.mapDemo}</p>
            )}
            <div className="mt-5">
              <ServiceAreaMap
                cfg={mapCfg}
                dark={resolvedMode === "dark"}
                strings={{ unavailable: u.mapUnavailable, directions: u.mapDirections, radius: u.mapRadius }}
              />
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <p className="text-sm">
                📍 <span className="font-bold">{mapCfg.name}</span> · {mapCfg.address} · {u.mapRadius}: {mapCfg.radiusKm} km
              </p>
              {mapDirUrl && (
                <a
                  href={mapDirUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary rounded-xl px-5 py-2.5 font-display text-sm font-black"
                >
                  🧭 {u.mapDirections}
                </a>
              )}
            </div>
            <h3 className="mt-10 font-display text-2xl font-black">📍 {t.areas}</h3>
            {d.areas.length === 0 ? (
              <p className="mt-4 rounded-2xl bg-[var(--surface2)] p-5 text-[var(--dim)]">{t.noAreas}</p>
            ) : (
              <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                {d.areas.map((a) => (
                  <li key={a.id} className="rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-3 font-semibold">
                    {a.city}{a.region ? `, ${a.region}` : ""} — {a.country}
                    <span className="block text-sm font-normal text-[var(--dim)]">
                      {a.electrical ? "⚡ " : ""}{a.plumbing ? "💧 " : ""}{a.emergency ? "🚨" : ""} {a.postal_codes}
                    </span>
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-8 flex flex-wrap gap-3">
              <button type="button" className="btn-primary rounded-xl px-6 py-3 font-display font-black" onClick={() => go("booking")}>{t.bookNow}</button>
              <button type="button" className="rounded-xl border border-[var(--border)] px-6 py-3 font-display font-black" onClick={() => go("contact")}>{t.contact}</button>
            </div>
          </section>
        )}

        {d && view === "contact" && (
          <section className="mx-auto max-w-3xl px-4 py-10">
            <h2 className="font-display text-3xl font-black">{t.contactTitle}</h2>
            <div className="mt-4 grid gap-2 text-base">
              {phone && <p>📞 <a className="font-semibold text-[var(--accent)]" href={`tel:${phone}`}>{phone}</a></p>}
              {whatsapp && <p>💬 <a className="font-semibold text-[var(--accent)]" href={`https://wa.me/${whatsapp.replace(/[^0-9]/g, "")}`} target="_blank" rel="noreferrer">{t.whatsapp}</a></p>}
              {email && <p>✉️ <a className="font-semibold text-[var(--accent)]" href={`mailto:${email}`}>{email}</a></p>}
              {(settings["company_address"] ?? "") && <p>📍 {settings["company_address"]}</p>}
              {(settings["company_hours"] ?? "") && <p>🕐 <span className="font-semibold">{u.hoursLabel}:</span> {settings["company_hours"]}</p>}
              {(settings["contact_availability"] ?? "") && <p>✅ <span className="font-semibold">{u.availabilityLabel}:</span> {settings["contact_availability"]}</p>}
              {!phone && !email && (
                <p className="rounded-xl bg-[var(--surface2)] p-4 text-sm text-[var(--dim)]">
                  {lang === "it" ? "I recapiti aziendali appariranno qui appena l'amministrazione li inserirà nelle Impostazioni." : "Company contact details will appear here as soon as the administration adds them in Settings."}
                </p>
              )}
            </div>
            <div className="mt-4 flex flex-wrap gap-3">
              {phone && <a className="btn-primary rounded-xl px-5 py-3 font-display font-black" href={`tel:${phone}`}>📞 {t.callNow}</a>}
              {email && <a className="rounded-xl border border-[var(--border)] px-5 py-3 font-display font-bold" href={`mailto:${email}`}>✉️ {email}</a>}
              {whatsapp && <a className="rounded-xl px-5 py-3 font-display font-bold text-white" style={{ background: "#1ebe5b" }} href={floatWaHref} target="_blank" rel="noreferrer">💬 {t.whatsapp}</a>}
              {mapDirUrl && (
                <a className="rounded-xl border border-[var(--border)] px-5 py-3 font-display font-bold" href={mapDirUrl} target="_blank" rel="noopener noreferrer">
                  🧭 {u.mapDirections}{mapCfg.isDemo ? " (DEMO)" : ""}
                </a>
              )}
            </div>
            <div className="mt-6 rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-6">
              <ContactForm t={t} />
            </div>
            <p className="mt-4 text-xs text-[var(--dim)]">
              {CURRENCIES.join(" · ")} — {lang === "it" ? "fatture e preventivi possono essere emessi in ciascuna di queste valute dal pannello di amministrazione." : "invoices and quotations can be issued in any of these currencies from the admin panel."}
            </p>
          </section>
        )}

        {d && view === "portal" && <PortalView t={t} lang={lang} serviceName={(s) => serviceName(s)} />}
        {d && view === "admin" && <AdminView serviceName={(s) => serviceName(s)} onExit={() => go("home")} />}
      </main>

      <footer className="border-t border-[var(--border)] bg-[var(--surface)]">
        <div className="mx-auto grid max-w-6xl gap-6 px-4 py-10 sm:grid-cols-3">
          <div>
            <p className="flex items-center gap-2">
              {siteLogo ? (
                <img src={siteLogo} alt="" className="h-9 w-auto max-w-[110px] object-contain" />
              ) : (
                <span className="grid h-9 w-9 place-items-center rounded-lg font-display text-lg font-black text-[var(--on-accent)]" style={{ background: "var(--grad)" }}>S</span>
              )}
              <span className="font-display text-lg font-black">{siteName}</span>
            </p>
            <p className="mt-2 text-sm text-[var(--dim)]">{footerNote}</p>
            {socials.length > 0 && (
              <p className="mt-3 flex flex-wrap gap-2">
                {socials.map((s) => (
                  <a key={s.label} href={s.href} target="_blank" rel="noreferrer" className="rounded-full border border-[var(--border)] px-3 py-1 text-xs font-bold text-[var(--dim)] hover:text-[var(--text)]">
                    {s.label}
                  </a>
                ))}
              </p>
            )}
          </div>
          <nav className="grid content-start gap-1.5 text-sm" aria-label="Footer">
            {(["services", "booking", "quote", "emergency", "about", "contact", "portal"] as View[]).map((v) => (
              <button key={v} type="button" className="text-start font-semibold text-[var(--dim)] hover:text-[var(--text)]" onClick={() => go(v)}>
                {v === "services" ? t.services : v === "booking" ? t.bookNow : v === "quote" ? t.getQuote : v === "emergency" ? `🚨 ${t.emergency}` : v === "about" ? t.about : v === "contact" ? t.contact : t.portal}
              </button>
            ))}
            {/* Sign-in entry point only: opens the dedicated Admin
                Login page (staff login / one-time setup); it sets no
                URL. No admin controls are exposed in the footer. */}
            <button type="button" className="text-start font-semibold text-[var(--dim)] hover:text-[var(--text)]" onClick={() => goMenu("admin")}>
              🔐 {ms.adminLogin}
            </button>
          </nav>
          <div className="text-sm text-[var(--dim)]">
            {phone && <p>📞 {phone}</p>}
            {email && <p>✉️ {email}</p>}
            {(settings["company_address"] ?? "") && <p>📍 {settings["company_address"]}</p>}
            {(settings["company_hours"] ?? "") && <p>🕐 {settings["company_hours"]}</p>}
            <p className="mt-2">EUR · USD · GBP · PKR · AED</p>
          </div>
        </div>
      </footer>

      {/* Floating emergency buttons — visible only when the admin has
          configured real numbers in Settings → Emergency buttons and
          has not switched them off there. */}
      {(showFloatCall || showFloatWa) && (
        <div
          className="fixed z-50 flex flex-col items-end gap-2"
          style={{
            bottom: "max(1rem, env(safe-area-inset-bottom))",
            insetInlineEnd: "1rem",
          }}
        >
          {showFloatWa && (
            <a
              href={floatWaHref}
              target="_blank"
              rel="noreferrer"
              aria-label={`${t.emergency} — ${t.whatsapp}`}
              className="flex items-center gap-2 rounded-full px-4 py-3 font-display text-sm font-black text-white shadow-2xl transition hover:brightness-110"
              style={{ background: "#25d366" }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" />
              </svg>
              <span>{t.whatsapp}</span>
            </a>
          )}
          {showFloatCall && (
            <a
              href={`tel:${phone}`}
              aria-label={`${t.emergency} — ${t.callNow}`}
              className="emergency-pulse flex items-center gap-2 rounded-full px-4 py-3 font-display text-sm font-black shadow-2xl"
            >
              📞 <span>{t.callNow}</span>
            </a>
          )}
        </div>
      )}
    </div>
  );
}
