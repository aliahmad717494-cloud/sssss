import { useState, type FormEvent } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { api, type ApiResponse } from "./api";
import { LANGS, type Dict } from "./i18n";

type State = ApiResponse<typeof api, "getState">;
type Svc = State["services"][number];

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label>{label}</label>
      {children}
    </div>
  );
}

export function ServiceSelect({
  services,
  value,
  onChange,
  lang,
  label,
}: {
  services: Svc[];
  value: string;
  onChange: (v: string) => void;
  lang: string;
  label: string;
}) {
  return (
    <Field label={label}>
      <select
        aria-label={label}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required
      >
        <option value="">—</option>
        {(["electrical", "plumbing"] as const).map((cat) => (
          <optgroup key={cat} label={cat === "electrical" ? "⚡ Electrical" : "💧 Plumbing"}>
            {services
              .filter((s) => s.category === cat && s.published)
              .map((s) => (
                <option key={s.slug} value={s.slug}>
                  {lang === "it" ? s.name_it : s.name_en}
                </option>
              ))}
          </optgroup>
        ))}
      </select>
    </Field>
  );
}

export function BookingForm({
  t,
  lang,
  services,
  slots,
  initialService = "",
  emergency = false,
}: {
  t: Dict;
  lang: string;
  services: Svc[];
  slots: string[];
  initialService?: string;
  emergency?: boolean;
}) {
  const [service, setService] = useState(initialService);
  const [date, setDate] = useState("");
  const [slot, setSlot] = useState("");
  const [done, setDone] = useState("");
  const [error, setError] = useState("");

  const taken = useQuery({
    queryKey: ["taken", date],
    queryFn: () => api.getBookedSlots({ date }),
    enabled: !!date && !emergency,
  });

  const mut = useMutation({
    mutationFn: api.createBooking,
    onSuccess: (r) => {
      if (r.ok) setDone(r.ref);
      else if (r.error === "slot_taken") setError(t.slotTaken);
      else setError(r.error);
    },
    onError: (e) => setError(String(e)),
  });

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError("");
    const fd = new FormData(e.currentTarget);
    const g = (k: string) => String(fd.get(k) ?? "");
    mut.mutate({
      service_slug: service,
      property_type: g("property_type"),
      description: g("description"),
      customer_name: g("customer_name"),
      customer_email: g("customer_email"),
      customer_phone: g("customer_phone"),
      address: g("address"),
      city: g("city"),
      postal_code: g("postal_code"),
      date: emergency ? "" : date,
      slot: emergency ? "" : slot,
      language: g("language"),
      is_emergency: emergency,
      photo_name: g("photo_name"),
    });
  };

  if (done) {
    return (
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 text-center">
        <div className="text-4xl" aria-hidden>✅</div>
        <p className="mt-3 font-semibold">
          {t.submitted} <span className="text-[var(--accent)]">{done}</span>
        </p>
        <p className="mt-1 text-sm text-[var(--dim)]">{t.notifications} · {t.portal}</p>
      </div>
    );
  }

  const takenSet = new Set(taken.data?.taken ?? []);

  return (
    <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2">
      <ServiceSelect services={services} value={service} onChange={setService} lang={lang} label={t.service} />
      <Field label={t.propertyType}>
        <select name="property_type" aria-label={t.propertyType} defaultValue="residential">
          <option value="residential">{t.residential}</option>
          <option value="commercial">{t.commercial}</option>
          <option value="industrial">{t.industrial}</option>
        </select>
      </Field>
      <div className="sm:col-span-2">
        <Field label={t.description}>
          <textarea name="description" aria-label={t.description} rows={3} required={!emergency} />
        </Field>
      </div>
      <Field label={t.name}>
        <input name="customer_name" aria-label={t.name} required autoComplete="name" />
      </Field>
      <Field label={t.email}>
        <input name="customer_email" type="email" aria-label={t.email} required autoComplete="email" />
      </Field>
      <Field label={t.phone}>
        <input name="customer_phone" type="tel" aria-label={t.phone} autoComplete="tel" />
      </Field>
      <Field label={t.city}>
        <input name="city" aria-label={t.city} />
      </Field>
      <Field label={t.address}>
        <input name="address" aria-label={t.address} autoComplete="street-address" />
      </Field>
      <Field label={t.postal}>
        <input name="postal_code" aria-label={t.postal} />
      </Field>
      {!emergency && (
        <>
          <Field label={t.date}>
            <input name="date" type="date" aria-label={t.date} value={date} onChange={(e) => setDate(e.target.value)} required />
          </Field>
          <Field label={t.slot}>
            <select name="slot" aria-label={t.slot} value={slot} onChange={(e) => setSlot(e.target.value)} required>
              <option value="">—</option>
              {slots.map((s) => (
                <option key={s} value={s} disabled={takenSet.has(s)}>
                  {s}{takenSet.has(s) ? " ✕" : ""}
                </option>
              ))}
            </select>
          </Field>
        </>
      )}
      <Field label={t.language}>
        <select name="language" aria-label={t.language} defaultValue={lang}>
          {LANGS.map((l) => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </Field>
      <Field label={t.photo}>
        <input name="photo_name" aria-label={t.photo} placeholder="IMG_2041.jpg" />
      </Field>
      {error && <p className="text-sm font-semibold text-red-500 sm:col-span-2">{error}</p>}
      <div className="sm:col-span-2">
        <button type="submit" disabled={mut.isPending || !service} className={`w-full rounded-xl px-5 py-3.5 font-display text-base font-bold disabled:opacity-50 ${emergency ? "emergency-pulse" : "btn-primary"}`}>
          {emergency ? `🚨 ${t.sendEmergency}` : t.submit}
        </button>
      </div>
    </form>
  );
}

export function QuoteForm({
  t,
  lang,
  services,
  initialService = "",
}: {
  t: Dict;
  lang: string;
  services: Svc[];
  initialService?: string;
}) {
  const [service, setService] = useState(initialService);
  const [done, setDone] = useState("");
  const [error, setError] = useState("");
  const mut = useMutation({
    mutationFn: api.createQuoteRequest,
    onSuccess: (r) => (r.ok ? setDone(r.ref) : setError(r.error)),
    onError: (e) => setError(String(e)),
  });
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const g = (k: string) => String(fd.get(k) ?? "");
    mut.mutate({
      service_slug: service,
      description: g("description"),
      property_type: g("property_type"),
      measurements: g("measurements"),
      address: g("address"),
      city: g("city"),
      customer_name: g("customer_name"),
      customer_email: g("customer_email"),
      customer_phone: g("customer_phone"),
      language: lang,
      photo_name: g("photo_name"),
    });
  };
  if (done) {
    return (
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 text-center">
        <div className="text-4xl" aria-hidden>📋</div>
        <p className="mt-3 font-semibold">{t.submitted} <span className="text-[var(--accent)]">{done}</span></p>
      </div>
    );
  }
  return (
    <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2">
      <ServiceSelect services={services} value={service} onChange={setService} lang={lang} label={t.service} />
      <Field label={t.propertyType}>
        <select name="property_type" aria-label={t.propertyType} defaultValue="residential">
          <option value="residential">{t.residential}</option>
          <option value="commercial">{t.commercial}</option>
          <option value="industrial">{t.industrial}</option>
        </select>
      </Field>
      <div className="sm:col-span-2">
        <Field label={t.description}>
          <textarea name="description" aria-label={t.description} rows={3} required />
        </Field>
      </div>
      <Field label={t.measurements}>
        <input name="measurements" aria-label={t.measurements} />
      </Field>
      <Field label={t.photo}>
        <input name="photo_name" aria-label={t.photo} placeholder="IMG_2041.jpg" />
      </Field>
      <Field label={t.name}>
        <input name="customer_name" aria-label={t.name} required autoComplete="name" />
      </Field>
      <Field label={t.email}>
        <input name="customer_email" type="email" aria-label={t.email} required autoComplete="email" />
      </Field>
      <Field label={t.phone}>
        <input name="customer_phone" type="tel" aria-label={t.phone} />
      </Field>
      <Field label={t.city}>
        <input name="city" aria-label={t.city} />
      </Field>
      <div className="sm:col-span-2">
        <Field label={t.address}>
          <input name="address" aria-label={t.address} />
        </Field>
      </div>
      <p className="text-xs text-[var(--dim)] sm:col-span-2">{t.quoteNote}</p>
      {error && <p className="text-sm font-semibold text-red-500 sm:col-span-2">{error}</p>}
      <div className="sm:col-span-2">
        <button type="submit" disabled={mut.isPending || !service} className="btn-primary w-full rounded-xl px-5 py-3.5 font-display text-base font-bold disabled:opacity-50">
          {t.getQuote}
        </button>
      </div>
    </form>
  );
}

export function ContactForm({
  t,
  kind = "contact",
}: {
  t: Dict;
  kind?: "contact" | "support";
}) {
  const [sent, setSent] = useState(false);
  const mut = useMutation({
    mutationFn: api.submitMessage,
    onSuccess: () => setSent(true),
  });
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const g = (k: string) => String(fd.get(k) ?? "");
    mut.mutate({ kind, name: g("name"), email: g("email"), subject: g("subject"), body: g("body") });
  };
  if (sent) return <p className="rounded-xl bg-[var(--surface2)] p-4 font-semibold">✅ {t.sentOk}</p>;
  return (
    <form onSubmit={onSubmit} className="grid gap-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={t.name}>
          <input name="name" aria-label={t.name} required />
        </Field>
        <Field label={t.email}>
          <input name="email" type="email" aria-label={t.email} required />
        </Field>
      </div>
      <Field label={t.subject}>
        <input name="subject" aria-label={t.subject} />
      </Field>
      <Field label={t.message}>
        <textarea name="body" aria-label={t.message} rows={4} required />
      </Field>
      <button type="submit" disabled={mut.isPending} className="btn-primary rounded-xl px-5 py-3 font-display font-bold disabled:opacity-50">
        {t.send}
      </button>
    </form>
  );
}

export function ReviewForm({ t, services, lang }: { t: Dict; services: Svc[]; lang: string }) {
  const [sent, setSent] = useState(false);
  const [service, setService] = useState("");
  const mut = useMutation({
    mutationFn: api.submitReview,
    onSuccess: () => setSent(true),
  });
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const g = (k: string) => String(fd.get(k) ?? "");
    mut.mutate({
      customer_name: g("customer_name"),
      service_slug: service,
      rating: Number(g("rating") || 5),
      body: g("body"),
    });
  };
  if (sent) return <p className="rounded-xl bg-[var(--surface2)] p-4 font-semibold">⭐ {t.reviewPending}</p>;
  return (
    <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2">
      <Field label={t.yourName}>
        <input name="customer_name" aria-label={t.yourName} required />
      </Field>
      <Field label={t.rating}>
        <select name="rating" aria-label={t.rating} defaultValue="5">
          {[5, 4, 3, 2, 1].map((n) => (
            <option key={n} value={n}>{"★".repeat(n)}{"☆".repeat(5 - n)}</option>
          ))}
        </select>
      </Field>
      <ServiceSelect services={services} value={service} onChange={setService} lang={lang} label={t.service} />
      <Field label={t.reviewText}>
        <input name="body" aria-label={t.reviewText} required />
      </Field>
      <div className="sm:col-span-2">
        <button type="submit" disabled={mut.isPending} className="btn-primary rounded-xl px-5 py-3 font-display font-bold disabled:opacity-50">
          {t.leaveReview}
        </button>
      </div>
    </form>
  );
}
