/* Safe browser-storage access.
 *
 * WHY THIS EXISTS: the artifact runs inside a sandboxed iframe, and in
 * restricted documents (sandboxed frame without allow-same-origin,
 * blocked third-party storage, some private modes) merely READING
 * `window.localStorage` throws a SecurityError —
 * "Failed to read the 'localStorage' property from 'Window': Access is
 * denied for this document." An unguarded `localStorage.getItem(...)`
 * in a useState initializer therefore crashed the ENTIRE app during
 * first render and the visitor only saw the root error boundary's
 * recovery panel ("Something went wrong while loading this page").
 *
 * Every storage access in the app goes through these helpers instead:
 *  - availability is probed once (the object may exist yet throw on
 *    use in some contexts, so the probe performs a real write+remove);
 *  - when real storage is unavailable, values fall back to an
 *    in-memory map, so the site still loads and works for the whole
 *    session (language, theme and login sessions behave normally —
 *    they simply do not persist across a reload in that environment);
 *  - when real storage IS available it is used exactly as before —
 *    nothing stored by earlier versions is overwritten, moved or
 *    deleted by this layer; reads and writes hit the same keys.
 */
const memory = new Map<string, string>();

function probe(): Storage | null {
  try {
    const s = window.localStorage;
    const k = "__ss_storage_probe__";
    s.setItem(k, "1");
    s.removeItem(k);
    return s;
  } catch {
    return null;
  }
}

let cached: Storage | null | undefined;
function store(): Storage | null {
  if (cached === undefined) cached = probe();
  return cached;
}

export function storageGet(key: string): string | null {
  const s = store();
  if (s) {
    try {
      const v = s.getItem(key);
      if (v !== null) return v;
    } catch {
      /* fall through to the in-memory copy */
    }
  }
  return memory.get(key) ?? null;
}

export function storageSet(key: string, value: string): void {
  memory.set(key, value);
  const s = store();
  if (s) {
    try {
      s.setItem(key, value);
    } catch {
      /* quota/blocked write — the in-memory copy stands for the session */
    }
  }
}

export function storageRemove(key: string): void {
  memory.delete(key);
  const s = store();
  if (s) {
    try {
      s.removeItem(key);
    } catch {
      /* ignore — removal is best-effort when storage is restricted */
    }
  }
}
