import { useEffect, useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, type ApiResponse } from "./api";
import { storageGet, storageRemove, storageSet } from "./storage";
import { CURRENCIES, LANGS, money, type Dict } from "./i18n";
import { portalStrings, upgradeStrings } from "./upgrade-i18n";

type Portal = ApiResponse<typeof api, "getPortal">;

const STATUS_LABEL: Record<string, string> = {
  new: "New Request",
  pending: "Pending Confirmation",
  confirmed: "Confirmed",
  assigned: "Assigned",
  in_progress: "In Progress",
  completed: "Completed",
  cancelled: "Cancelled",
  reviewing: "Reviewing",
  quoted: "Quoted",
  closed: "Closed",
  draft: "Draft",
  sent: "Sent",
  accepted: "Accepted",
  rejected: "Rejected",
  expired: "Expired",
  unpaid: "Unpaid",
  paid: "Paid",
  overdue: "Overdue",
  void: "Void",
};

export function statusLabel(s: string): string {
  return STATUS_LABEL[s] ?? s;
}

function Badge({ s }: { s: string }) {
  const color =
    s === "completed" || s === "accepted" || s === "paid"
      ? "bg-emerald-500/15 text-emerald-500"
      : s === "cancelled" || s === "rejected" || s === "overdue"
        ? "bg-red-500/15 text-red-500"
        : s === "new"
          ? "bg-[var(--accent)]/15 text-[var(--accent)]"
          : "bg-[var(--surface2)] text-[var(--dim)]";
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-bold ${color}`}>
      {statusLabel(s)}
    </span>
  );
}

export function PortalView({
  t,
  lang,
  serviceName,
}: {
  t: Dict;
  lang: string;
  serviceName: (slug: string) => string;
}) {
  const u = upgradeStrings(lang);
  const ps = portalStrings(lang);
  const qc = useQueryClient();

  /* Customer session (real backend login): the raw token lives only in
     this browser's local storage; the server stores its SHA-256 hash. */
  const [custToken, setCustToken] = useState(
    () => storageGet("ss-customer-token") ?? "",
  );
  const [custEmail, setCustEmail] = useState(
    () => storageGet("ss-customer-email") ?? "",
  );
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [authError, setAuthError] = useState("");
  const [resetSent, setResetSent] = useState(false);
  const [pwMsg, setPwMsg] = useState("");

  const [email, setEmail] = useState(
    () => storageGet("ss-portal-email") ?? "",
  );
  const [lookup, setLookup] = useState(custEmail || email);

  const portal = useQuery({
    queryKey: ["portal", lookup, custToken],
    queryFn: () => api.getPortal({ email: lookup, token: custToken }),
    enabled: lookup.includes("@"),
  });

  /* If the server says this account needs a login but our stored token
     did not satisfy it, the session is stale — drop it. */
  useEffect(() => {
    if (portal.data?.requires_login && custToken) {
      storageRemove("ss-customer-token");
      storageRemove("ss-customer-email");
      setCustToken("");
      setCustEmail("");
    }
  }, [portal.data?.requires_login, custToken]);

  const applySession = (token: string, em: string) => {
    storageSet("ss-customer-token", token);
    storageSet("ss-customer-email", em);
    storageSet("ss-portal-email", em);
    setCustToken(token);
    setCustEmail(em);
    setEmail(em);
    setLookup(em);
    setAuthError("");
  };

  const login = useMutation({
    mutationFn: api.customerLogin,
    onSuccess: (res, vars) => {
      if (res.ok) applySession(res.token, vars.email.toLowerCase());
      else
        setAuthError(
          res.error === "no_password_set" ? u.noPasswordSet : u.loginFailed,
        );
    },
    onError: () => setAuthError(u.loginFailed),
  });
  const register = useMutation({
    mutationFn: api.customerRegister,
    onSuccess: (res, vars) => {
      if (res.ok) applySession(res.token, vars.email.toLowerCase());
      else
        setAuthError(
          res.error === "account_exists" ? u.accountExists : u.loginFailed,
        );
    },
    onError: () => setAuthError(u.loginFailed),
  });
  const requestReset = useMutation({
    mutationFn: api.customerRequestReset,
    onSuccess: () => setResetSent(true),
  });
  const changePw = useMutation({
    mutationFn: api.customerChangePassword,
    onSuccess: (res) =>
      setPwMsg(
        res.ok
          ? "✓"
          : res.error === "wrong_current_password"
            ? u.loginFailed
            : res.error,
      ),
  });
  const logout = useMutation({
    mutationFn: api.customerLogout,
    onSuccess: () => {
      storageRemove("ss-customer-token");
      storageRemove("ss-customer-email");
      setCustToken("");
      setCustEmail("");
      setLookup("");
      qc.removeQueries({ queryKey: ["portal"] });
    },
  });

  const respond = useMutation({
    mutationFn: (args: { id: number; email: string; accept: boolean }) =>
      api.respondQuotation({ ...args, token: custToken }),
    onSuccess: () =>
      qc.invalidateQueries({ queryKey: ["portal", lookup] }),
  });
  const saveProfile = useMutation({
    mutationFn: (args: {
      email: string;
      name: string;
      phone: string;
      address: string;
      language: string;
      currency: string;
    }) => api.updateCustomerProfile({ ...args, token: custToken }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["portal", lookup] }),
  });

  const onLookup = (e: FormEvent) => {
    e.preventDefault();
    storageSet("ss-portal-email", email);
    setLookup(email.trim().toLowerCase());
  };

  const data: Portal | undefined = portal.data;
  const signedIn = custToken !== "" && custEmail !== "";

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-3xl font-black">{t.portal}</h2>
        {signedIn && (
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-[var(--dim)]">{custEmail}</span>
            <button
              type="button"
              className="rounded-lg border border-[var(--border)] px-3.5 py-2 font-display text-sm font-bold"
              onClick={() => logout.mutate({ token: custToken })}
            >
              {u.logout}
            </button>
          </div>
        )}
      </div>

      {!signedIn && (
        <div className="mt-5 rounded-3xl border border-[var(--border)] bg-[var(--surface)] p-5">
          <div className="flex gap-2" role="tablist" aria-label={u.signIn}>
            {(["login", "register"] as const).map((m) => (
              <button
                key={m}
                type="button"
                role="tab"
                aria-selected={authMode === m}
                onClick={() => { setAuthMode(m); setAuthError(""); }}
                className={`rounded-full px-4 py-2 font-display text-sm font-bold ${authMode === m ? "btn-primary" : "border border-[var(--border)]"}`}
              >
                {m === "login" ? u.signIn : u.createAccount}
              </button>
            ))}
          </div>

          {authMode === "login" ? (
            <form
              className="mt-4 grid gap-3 sm:grid-cols-2"
              onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                login.mutate({
                  email: String(fd.get("email") ?? ""),
                  password: String(fd.get("password") ?? ""),
                });
              }}
            >
              <div>
                <label htmlFor="li-email">{t.email}</label>
                <input id="li-email" name="email" type="email" required autoComplete="email" />
              </div>
              <div>
                <label htmlFor="li-pw">{u.password}</label>
                <input id="li-pw" name="password" type="password" required autoComplete="current-password" />
              </div>
              <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
                <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold" disabled={login.isPending}>
                  {u.signIn}
                </button>
                <button
                  type="button"
                  className="text-sm font-semibold text-[var(--accent)]"
                  onClick={() => {
                    const em = (document.getElementById("li-email") as HTMLInputElement | null)?.value ?? "";
                    if (em.includes("@")) requestReset.mutate({ email: em });
                  }}
                >
                  {u.forgotPassword}
                </button>
                <span className="text-sm text-[var(--dim)]">{u.noAccount}</span>
              </div>
            </form>
          ) : (
            <form
              className="mt-4 grid gap-3 sm:grid-cols-2"
              onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                register.mutate({
                  name: String(fd.get("name") ?? ""),
                  email: String(fd.get("email") ?? ""),
                  phone: String(fd.get("phone") ?? ""),
                  password: String(fd.get("password") ?? ""),
                  language: lang,
                  currency: "EUR",
                });
              }}
            >
              <div>
                <label htmlFor="rg-name">{t.name}</label>
                <input id="rg-name" name="name" required autoComplete="name" />
              </div>
              <div>
                <label htmlFor="rg-email">{t.email}</label>
                <input id="rg-email" name="email" type="email" required autoComplete="email" />
              </div>
              <div>
                <label htmlFor="rg-phone">{t.phone}</label>
                <input id="rg-phone" name="phone" type="tel" autoComplete="tel" />
              </div>
              <div>
                <label htmlFor="rg-pw">{u.password} (min 8)</label>
                <input id="rg-pw" name="password" type="password" required minLength={8} autoComplete="new-password" />
              </div>
              <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
                <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold" disabled={register.isPending}>
                  {u.createAccount}
                </button>
                <span className="text-sm text-[var(--dim)]">{u.haveAccount}</span>
              </div>
            </form>
          )}

          {authError && (
            <p className="mt-3 rounded-xl bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-500" role="alert">
              {authError}
            </p>
          )}
          {resetSent && (
            <p className="mt-3 rounded-xl bg-emerald-500/10 px-4 py-3 text-sm font-semibold text-emerald-500" role="status">
              {u.resetRequested}
            </p>
          )}
        </div>
      )}

      {!signedIn && (
        <>
          <p className="mt-6 text-sm text-[var(--dim)]">{u.lookupHint}</p>
          <form onSubmit={onLookup} className="mt-3 flex flex-col gap-3 sm:flex-row">
            <div className="flex-1">
              <label htmlFor="portal-email">{t.yourEmail}</label>
              <input
                id="portal-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="nome@esempio.it"
              />
            </div>
            <button
              type="submit"
              className="btn-primary self-end rounded-xl px-5 py-3 font-display font-bold"
            >
              {t.viewMyRecords}
            </button>
          </form>
        </>
      )}

      {portal.isPending && lookup && <p className="mt-6 text-[var(--dim)]">…</p>}
      {data?.requires_login && (
        <p className="mt-6 rounded-xl bg-amber-500/10 p-4 text-sm font-semibold text-amber-500">
          {u.protectedAccount}
        </p>
      )}
      {data && !data.found && !data.requires_login && lookup && (
        <p className="mt-6 rounded-xl bg-[var(--surface2)] p-4 text-sm text-[var(--dim)]">
          {t.portal}: no records for {lookup}. / Nessun record per {lookup}.
        </p>
      )}

      {data?.found && (
        <div className="mt-8 grid gap-8">
          {data.customer && (
            <section className="rounded-3xl border-2 border-[var(--accent)] bg-[var(--surface)] p-5">
              <h3 className="font-display text-2xl font-black sm:text-3xl">
                {ps.salam}, {data.customer.name}!
              </h3>
              <p className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-sm text-[var(--dim)]">
                <span>
                  {ps.registeredEmail}:{" "}
                  <span className="font-semibold text-[var(--text)]">{data.customer.email}</span>
                </span>
                {data.customer.phone && (
                  <span>
                    {ps.registeredMobile}:{" "}
                    <span className="font-semibold text-[var(--text)]">{data.customer.phone}</span>
                  </span>
                )}
              </p>
            </section>
          )}

          {data.offers.length > 0 && (
            <section>
              <h3 className="font-display text-xl font-bold">🎁 {ps.offersTitle}</h3>
              <ul className="mt-3 grid gap-3 sm:grid-cols-2">
                {data.offers.map((o) => (
                  <li key={o.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-display font-bold">{o.title}</span>
                      <span className="rounded-full bg-[var(--accent)]/15 px-2.5 py-0.5 text-xs font-bold text-[var(--accent)]">
                        {o.discount_type === "percent"
                          ? `${o.discount_value}% ${ps.offLabel}`
                          : `${money(o.discount_value, data.customer?.currency ?? "EUR")} ${ps.offLabel}`}
                      </span>
                    </div>
                    {o.description && <p className="mt-1 text-sm">{o.description}</p>}
                    <p className="mt-1 text-xs text-[var(--dim)]">
                      {o.scope === "selected" ? `${ps.forYou} · ` : ""}
                      {o.expires_at ? `${ps.validUntil} ${o.expires_at}` : ps.noExpiry}
                    </p>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {data.notifications.length > 0 && (
            <section>
              <h3 className="font-display text-xl font-bold">🔔 {t.notifications}</h3>
              <ul className="mt-3 grid gap-2">
                {data.notifications.slice(0, 8).map((n) => (
                  <li key={n.id} className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-3 text-sm">
                    <span className="font-semibold">{n.title}</span>
                    <span className="text-[var(--dim)]"> — {n.body}</span>
                    <span className="block text-xs text-[var(--dim)]">
                      {new Date(n.created_at).toLocaleString()}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <section>
            <h3 className="font-display text-xl font-bold">📅 {t.myBookings}</h3>
            {data.bookings.length === 0 && <p className="mt-2 text-sm text-[var(--dim)]">—</p>}
            <ul className="mt-3 grid gap-3">
              {data.bookings.map((b) => (
                <li key={b.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-display font-bold">
                      {b.is_emergency ? "🚨 " : ""}{serviceName(b.service_slug)}
                    </span>
                    <Badge s={b.status} />
                  </div>
                  <p className="mt-1 text-sm text-[var(--dim)]">
                    {b.ref}
                    {b.date ? ` · ${b.date} ${b.slot}` : ""} · {b.city}
                  </p>
                  {b.description && <p className="mt-1 text-sm">{b.description}</p>}
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h3 className="font-display text-xl font-bold">📋 {t.myQuotes}</h3>
            {data.quote_requests.length === 0 && data.quotations.length === 0 && (
              <p className="mt-2 text-sm text-[var(--dim)]">—</p>
            )}
            <ul className="mt-3 grid gap-3">
              {data.quote_requests.map((q) => (
                <li key={q.id} className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold">{serviceName(q.service_slug)}</span>
                    <Badge s={q.status} />
                  </div>
                  <p className="mt-1 text-sm text-[var(--dim)]">{q.ref} · {q.description}</p>
                </li>
              ))}
              {data.quotations.map((q) => (
                <li key={q.id} className="rounded-2xl border-2 border-[var(--accent)] bg-[var(--surface)] p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-display font-bold">{q.title}</span>
                    <Badge s={q.status} />
                  </div>
                  <p className="mt-1 text-sm text-[var(--dim)]">
                    {q.ref}
                    {q.expiry_date ? ` · expires ${q.expiry_date}` : ""}
                  </p>
                  <p className="mt-2 font-display text-2xl font-black">
                    {money(q.total_cents, q.currency)}
                  </p>
                  {q.status === "sent" && (
                    <div className="mt-3 flex gap-2">
                      <button
                        type="button"
                        className="btn-primary rounded-lg px-4 py-2 font-display font-bold"
                        onClick={() => respond.mutate({ id: q.id, email: lookup, accept: true })}
                      >
                        ✓ {t.accept}
                      </button>
                      <button
                        type="button"
                        className="rounded-lg border border-[var(--border)] px-4 py-2 font-display font-bold"
                        onClick={() => respond.mutate({ id: q.id, email: lookup, accept: false })}
                      >
                        ✕ {t.reject}
                      </button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h3 className="font-display text-xl font-bold">🧾 {t.myInvoices}</h3>
            {data.invoices.length === 0 && <p className="mt-2 text-sm text-[var(--dim)]">—</p>}
            <ul className="mt-3 grid gap-3">
              {data.invoices.map((inv) => (
                <li key={inv.id} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
                  <span className="font-semibold">
                    {inv.ref} · {money(inv.amount_cents, inv.currency)}
                    {inv.due_date ? ` · due ${inv.due_date}` : ""}
                  </span>
                  <Badge s={inv.status} />
                </li>
              ))}
            </ul>
          </section>

          {data.customer && (
            <section>
              <h3 className="font-display text-xl font-bold">👤 {t.profile}</h3>
              <form
                className="mt-3 grid gap-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  const fd = new FormData(e.currentTarget);
                  const g = (k: string) => String(fd.get(k) ?? "");
                  saveProfile.mutate({
                    email: lookup,
                    name: g("name"),
                    phone: g("phone"),
                    address: g("address"),
                    language: g("language"),
                    currency: g("currency"),
                  });
                }}
              >
                <div>
                  <label htmlFor="pf-name">{t.name}</label>
                  <input id="pf-name" name="name" defaultValue={data.customer.name} required />
                </div>
                <div>
                  <label htmlFor="pf-phone">{t.phone}</label>
                  <input id="pf-phone" name="phone" defaultValue={data.customer.phone} />
                </div>
                <div className="sm:col-span-2">
                  <label htmlFor="pf-address">{t.address}</label>
                  <input id="pf-address" name="address" defaultValue={data.customer.address} />
                </div>
                <div>
                  <label htmlFor="pf-lang">{t.language}</label>
                  <select id="pf-lang" name="language" defaultValue={data.customer.language}>
                    {LANGS.map((l) => (
                      <option key={l.code} value={l.code}>{l.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="pf-cur">{t.currency}</label>
                  <select id="pf-cur" name="currency" defaultValue={data.customer.currency}>
                    {CURRENCIES.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <button type="submit" className="btn-primary rounded-xl px-5 py-2.5 font-display font-bold" disabled={saveProfile.isPending}>
                    {t.save}
                  </button>
                </div>
              </form>

              {signedIn && (
                <form
                  className="mt-4 grid gap-4 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 sm:grid-cols-2"
                  onSubmit={(e) => {
                    e.preventDefault();
                    const fd = new FormData(e.currentTarget);
                    changePw.mutate({
                      token: custToken,
                      current_password: String(fd.get("current_password") ?? ""),
                      new_password: String(fd.get("new_password") ?? ""),
                    });
                    e.currentTarget.reset();
                  }}
                >
                  <h4 className="font-display font-bold sm:col-span-2">🔑 {u.changePassword}</h4>
                  <div>
                    <label htmlFor="cp-cur">{u.currentPassword}</label>
                    <input id="cp-cur" name="current_password" type="password" required autoComplete="current-password" />
                  </div>
                  <div>
                    <label htmlFor="cp-new">{u.newPassword} (min 8)</label>
                    <input id="cp-new" name="new_password" type="password" required minLength={8} autoComplete="new-password" />
                  </div>
                  <div className="flex items-center gap-3 sm:col-span-2">
                    <button type="submit" className="rounded-xl border border-[var(--border)] px-5 py-2.5 font-display font-bold" disabled={changePw.isPending}>
                      {u.changePassword}
                    </button>
                    {pwMsg && <span className="text-sm font-semibold" role="status">{pwMsg}</span>}
                  </div>
                </form>
              )}
            </section>
          )}
        </div>
      )}
    </div>
  );
}
