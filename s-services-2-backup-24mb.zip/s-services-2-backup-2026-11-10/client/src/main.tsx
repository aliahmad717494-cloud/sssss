import { spaceQueryClient } from "@hatch/space-sdk/client";
import { QueryClientProvider } from "@tanstack/react-query";
import { Component, StrictMode, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";
import "./theme.css";

const rootEl = document.querySelector<HTMLElement>("[data-generated-space-root]");
if (!rootEl) {
  throw new Error("missing generated space root element");
}

/* Root error boundary: the LAST line of defence against a blank/black
   view. Any render or lifecycle error anywhere in the tree (App, forms,
   portals, admin — the cinematic module has its own inner boundary)
   degrades to this visible recovery panel with a working reload button,
   instead of React unmounting everything onto the dark page background.
   The panel is styled inline so it renders correctly even if the CSS
   bundle itself is part of the failure. */
class RootBoundary extends Component<
  { children: ReactNode },
  { failed: boolean; message: string }
> {
  state = { failed: false, message: "" };
  static getDerivedStateFromError(err: unknown): { failed: boolean; message: string } {
    /* Keep the real error message: the panel shows it (small, technical)
       so a screenshot of the failure is itself a diagnosis, instead of
       the generic dead end the owner hit in Report 18. */
    const raw = err instanceof Error ? err.message : String(err ?? "");
    return { failed: true, message: raw.slice(0, 240) };
  }
  componentDidCatch(err: unknown) {
    console.error("S SERVICES root boundary caught an error; recovery panel shown.", err);
  }
  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div
        role="alert"
        style={{
          minHeight: "100svh",
          display: "grid",
          placeItems: "center",
          padding: "24px",
          background: "#0e1216",
          color: "#eef2f6",
          fontFamily: "system-ui, -apple-system, 'Segoe UI', sans-serif",
          textAlign: "center",
        }}
      >
        <div style={{ maxWidth: "26rem" }}>
          <div
            aria-hidden
            style={{
              width: "56px",
              height: "56px",
              margin: "0 auto 16px",
              display: "grid",
              placeItems: "center",
              borderRadius: "16px",
              background: "linear-gradient(120deg, #2f7bff, #38b6ff 55%, #ffb02e 130%)",
              color: "#ffffff",
              fontSize: "28px",
              fontWeight: 900,
            }}
          >
            S
          </div>
          <h1 style={{ fontSize: "22px", fontWeight: 800, margin: "0 0 8px" }}>
            S SERVICES
          </h1>
          <p style={{ fontSize: "15px", lineHeight: 1.55, opacity: 0.85, margin: "0 0 6px" }}>
            Qualcosa è andato storto durante il caricamento della pagina.
          </p>
          <p style={{ fontSize: "15px", lineHeight: 1.55, opacity: 0.85, margin: "0 0 20px" }}>
            Something went wrong while loading this page. Your data is safe — please reload.
          </p>
          <div style={{ display: "flex", gap: "10px", justifyContent: "center", flexWrap: "wrap" }}>
            <button
              type="button"
              onClick={() => this.setState({ failed: false, message: "" })}
              style={{
                border: "1px solid rgba(255,255,255,0.35)",
                cursor: "pointer",
                borderRadius: "12px",
                padding: "12px 22px",
                fontSize: "15px",
                fontWeight: 800,
                color: "#ffffff",
                background: "transparent",
              }}
            >
              Riprova / Retry
            </button>
            <button
              type="button"
              onClick={() => window.location.reload()}
              style={{
                border: "none",
                cursor: "pointer",
                borderRadius: "12px",
                padding: "12px 26px",
                fontSize: "15px",
                fontWeight: 800,
                color: "#ffffff",
                background: "linear-gradient(120deg, #2f7bff, #38b6ff 55%, #ffb02e 130%)",
              }}
            >
              Ricarica / Reload
            </button>
          </div>
          {this.state.message && (
            <p style={{ marginTop: "18px", fontSize: "11px", lineHeight: 1.5, opacity: 0.5, fontFamily: "ui-monospace, monospace", overflowWrap: "anywhere" }}>
              {this.state.message}
            </p>
          )}
        </div>
      </div>
    );
  }
}

// If you edit this file: keep `<QueryClientProvider client={spaceQueryClient}>`
// wrapping the app (every space shares the SDK's QueryClient), and keep
// BOTH the `hatch-space-root` class AND the `data-hatch-space-root`
// attribute on the outer div. The SDK styles select on
// `.hatch-space-root[data-hatch-space-root]` to apply mobile safe-area
// insets (notches, gesture bars, etc.), correct viewport sizing, and the
// hosting header/chrome offsets — dropping either breaks layout silently.
createRoot(rootEl).render(
  <StrictMode>
    <QueryClientProvider client={spaceQueryClient}>
      <div className="hatch-space-root" data-hatch-space-root>
        <RootBoundary>
          <App />
        </RootBoundary>
      </div>
    </QueryClientProvider>
  </StrictMode>,
);
