import { Component, useEffect, useRef, useState, type ErrorInfo, type ReactNode } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import * as THREE from "three";

import heroElectrical from "./assets/hero-electrical.jpg";
import heroPlumbing from "./assets/hero-plumbing.jpg";
import heatingImg from "./assets/heating.jpg";
import solarImg from "./assets/solar.webp";
import evImg from "./assets/ev-wallbox.webp";
import kitchenImg from "./assets/kitchen-plumbing.jpg";
import pipesImg from "./assets/pipe-work.jpg";
import inspectionImg from "./assets/electrical-inspection.webp";
import { SCROLLY } from "./scrolly-i18n";

gsap.registerPlugin(ScrollTrigger);

/* ------------------------------------------------------------------ */
/*  S SERVICES — Scroll-Driven Storytelling (Scrollytelling)           */
/*  Every animation below is driven by GSAP ScrollTrigger with        */
/*  scrub: progress is locked to scroll position, in both directions.  */
/*  Pinning uses sticky stages inside tall wrappers (transform-safe    */
/*  inside the artifact iframe), bound to the SDK root scroller.       */
/*  Lenis was tested and rejected here (it hijacks wheel/key input     */
/*  and froze scrolling in this shell); smoothness comes from native   */
/*  scrolling + ScrollTrigger scrub catch-up. Reduced motion gets a    */
/*  fully static layout.                                               */
/* ------------------------------------------------------------------ */

/* Error boundary for the whole cinematic module. Before this existed, ANY
   synchronous throw inside the scrollytelling tree (the known trigger class
   on desktop laptops: WebGL context creation failing on blocklisted GPUs,
   which the audit logs corroborate with software-WebGL fallback warnings)
   unmounted the ENTIRE React app and left the dark page background — a
   completely black preview — while mobile, which takes different code
   paths, rendered fine. Now a cinematic failure degrades to a static
   section and the rest of the site (hero, services, booking) always
   renders. Animations are never disabled by this boundary unless they
   actually crash. */
export class ScrollyBoundary extends Component<
  { lang: string; onBook: () => void; children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError(): { failed: boolean } {
    return { failed: true };
  }
  componentDidCatch(error: Error, _info: ErrorInfo): void {
    // Keep the failure visible in the console for diagnosis; the page lives.
    console.error("Scrollytelling failed; static fallback shown.", error);
  }
  render(): ReactNode {
    if (!this.state.failed) return this.props.children;
    const c = SCROLLY[this.props.lang] ?? SCROLLY.en!;
    return (
      <section className="mx-auto max-w-6xl px-4 py-10" aria-label={c.filmAria}>
        <p className="font-display text-xs font-bold uppercase tracking-[0.3em] text-[var(--accent)]">{c.filmKicker}</p>
        <h2 className="mt-2 max-w-xl font-display text-3xl font-black leading-tight sm:text-4xl">{c.filmTitle}</h2>
        <p className="mt-2 max-w-md text-[var(--dim)]">{c.filmSub}</p>
        <img src={heroElectrical} alt={c.filmAria} className="mt-5 h-64 w-full rounded-3xl object-cover" loading="lazy" decoding="async" />
        <button type="button" className="btn-primary mt-5 rounded-xl px-5 py-3 font-display font-black" onClick={this.props.onBook}>
          {c.bookThisWork}
        </button>
      </section>
    );
  }
}

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState<boolean>(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true,
  );
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const fn = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener?.("change", fn);
    return () => mq.removeEventListener?.("change", fn);
  }, []);
  return reduced;
}

const SCENE_IMGS: { img: string; icon: string }[] = [
  { img: heroElectrical, icon: "⚡" },
  { img: inspectionImg, icon: "🔍" },
  { img: heroPlumbing, icon: "💧" },
  { img: pipesImg, icon: "🔧" },
  { img: heatingImg, icon: "🔥" },
];

/** Canvas "video" sequence — real S SERVICES trade photography drawn
 *  frame-by-frame onto a canvas; scroll position IS the playhead. */
const SEQ_SRCS: string[] = [heroElectrical, inspectionImg, solarImg, evImg, heroPlumbing, pipesImg, kitchenImg, heatingImg];

const JOURNEY_IMGS: { img: string; icon: string }[] = [
  { img: inspectionImg, icon: "🔍" },
  { img: heroElectrical, icon: "⚡" },
  { img: solarImg, icon: "☀️" },
  { img: evImg, icon: "🔌" },
  { img: kitchenImg, icon: "🚿" },
  { img: heatingImg, icon: "🔥" },
];

type Props = {
  lang: string;
  heroVideo: string;
  onBook: () => void;
  onExploreElectrical: () => void;
  onExplorePlumbing: () => void;
};

export function Scrollytelling({ lang, heroVideo, onBook, onExploreElectrical, onExplorePlumbing }: Props) {
  const c = SCROLLY[lang] ?? SCROLLY.en!;
  const reduced = usePrefersReducedMotion();
  const [videoFailed, setVideoFailed] = useState(false);
  const [videoReady, setVideoReady] = useState(false);
  useEffect(() => { setVideoFailed(false); setVideoReady(false); }, [heroVideo]);
  const rootRef = useRef<HTMLDivElement>(null);
  const seqWrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const seqPctRef = useRef<HTMLSpanElement>(null);
  const seqLabelRef = useRef<HTMLSpanElement>(null);
  const storyWrapRef = useRef<HTMLDivElement>(null);
  const sceneRefs = useRef<(HTMLDivElement | null)[]>([]);
  const captionRefs = useRef<(HTMLDivElement | null)[]>([]);
  const storyBarRef = useRef<HTMLDivElement>(null);
  const storyIdxRef = useRef<HTMLSpanElement>(null);
  const horizWrapRef = useRef<HTMLDivElement>(null);
  const horizTrackRef = useRef<HTMLDivElement>(null);
  const horizBarRef = useRef<HTMLDivElement>(null);
  const threeWrapRef = useRef<HTMLDivElement>(null);
  const threeMountRef = useRef<HTMLDivElement>(null);
  const [threeFailed, setThreeFailed] = useState(false);
  const [seqFailed, setSeqFailed] = useState(false);
  const [seqReady, setSeqReady] = useState(false);
  const [engineFailed, setEngineFailed] = useState(false);
  const threeGroupRef = useRef<THREE.Group | null>(null);

  /* ---------------------------- Three.js scene ---------------------------- */
  useEffect(() => {
    if (reduced) return;
    const mount = threeMountRef.current;
    if (!mount) return;
    /* WebGL preflight: on desktop laptops with blocklisted GPUs/drivers,
       context creation can fail or return null. Probe first — if WebGL is
       unavailable, use the photo fallback instead of mounting a renderer
       that paints a black rectangle (or throws). */
    try {
      const probe = document.createElement("canvas");
      const gl = probe.getContext("webgl2") || probe.getContext("webgl");
      if (!gl) { setThreeFailed(true); return; }
    } catch { setThreeFailed(true); return; }
    let renderer: THREE.WebGLRenderer | null = null;
    let raf = 0;
    let visible = true;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
      camera.position.set(0, 1.4, 8.2);
      camera.lookAt(0, 0.4, 0);

      const group = new THREE.Group();
      threeGroupRef.current = group;
      const copper = new THREE.MeshStandardMaterial({ color: 0xb87333, metalness: 0.85, roughness: 0.32 });
      const steel = new THREE.MeshStandardMaterial({ color: 0x9fb4c8, metalness: 0.9, roughness: 0.25 });
      const blue = new THREE.MeshStandardMaterial({ color: 0x2f7bff, metalness: 0.4, roughness: 0.35 });
      const amber = new THREE.MeshStandardMaterial({ color: 0xffb02e, emissive: 0xcc7a00, emissiveIntensity: 0.7, metalness: 0.3, roughness: 0.4 });

      const pipe = (x: number, y: number, len: number, r: number, mat: THREE.Material, vertical = false) => {
        const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 28), mat);
        m.position.set(x, y, 0);
        if (!vertical) m.rotation.z = Math.PI / 2;
        group.add(m);
        return m;
      };
      pipe(-1.7, 1.15, 3.6, 0.21, copper); // top horizontal pipe
      pipe(0.1, -1.25, 3.4, 0.21, steel); // bottom horizontal pipe
      pipe(-1.7, 0, 2.3, 0.21, copper, true); // left riser
      pipe(1.75, -0.1, 2.5, 0.21, steel, true); // right riser
      const elbow = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.21, 20, 36, Math.PI / 2), copper);
      elbow.position.set(-1.15, 1.15, 0);
      group.add(elbow);
      const valve = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.09, 16, 40), blue);
      valve.position.set(0.35, 1.15, 0.3);
      valve.rotation.x = Math.PI / 2.4;
      group.add(valve);
      // Lightning bolt (extruded polygon) floating in the middle
      const s = new THREE.Shape();
      s.moveTo(0.12, 1.35); s.lineTo(0.62, 1.35); s.lineTo(0.3, 0.32); s.lineTo(0.66, 0.32);
      s.lineTo(-0.28, -1.35); s.lineTo(-0.02, -0.18); s.lineTo(-0.42, -0.18); s.closePath();
      const bolt = new THREE.Mesh(new THREE.ExtrudeGeometry(s, { depth: 0.22, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.03 }), amber);
      bolt.position.set(-0.15, 0, 0.55);
      group.add(bolt);
      const floor = new THREE.Mesh(
        new THREE.CircleGeometry(3.4, 48),
        new THREE.MeshStandardMaterial({ color: 0x1a222c, metalness: 0.2, roughness: 0.9 }),
      );
      floor.rotation.x = -Math.PI / 2;
      floor.position.y = -1.85;
      group.add(floor);
      group.position.y = 0.35;
      scene.add(group);
      scene.add(new THREE.AmbientLight(0xffffff, 0.55));
      const key = new THREE.DirectionalLight(0xffffff, 1.6);
      key.position.set(4, 6, 6);
      scene.add(key);
      const rim = new THREE.PointLight(0x2f7bff, 30, 30);
      rim.position.set(-5, 2, 4);
      scene.add(rim);

      const resize = () => {
        const w = mount.clientWidth || 600;
        const h = mount.clientHeight || 420;
        renderer!.setSize(w, h);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      };
      resize();
      const onCtxLost = (e: Event) => { e.preventDefault(); setThreeFailed(true); };
      renderer.domElement.addEventListener("webglcontextlost", onCtxLost);
      mount.appendChild(renderer.domElement);
      renderer.domElement.style.width = "100%";
      renderer.domElement.style.height = "100%";
      renderer.domElement.style.display = "block";
      const io = new IntersectionObserver((e) => { visible = e[0]?.isIntersecting ?? true; }, { threshold: 0.02 });
      io.observe(mount);
      const loop = () => {
        raf = requestAnimationFrame(loop);
        if (visible) renderer!.render(scene, camera);
      };
      loop();
      window.addEventListener("resize", resize);
      return () => {
        cancelAnimationFrame(raf);
        io.disconnect();
        window.removeEventListener("resize", resize);
        renderer!.domElement.removeEventListener("webglcontextlost", onCtxLost);
        renderer!.dispose();
        mount.removeChild(renderer!.domElement);
        threeGroupRef.current = null;
      };
    } catch {
      setThreeFailed(true);
      return undefined;
    }
  }, [reduced]);

  /* --------------------- GSAP scrub engine + Lenis --------------------- */
  useEffect(() => {
    if (reduced || !rootRef.current) return;
    /* The artifact's scroll container is the SDK root element
       ([data-generated-space-root], position:fixed + overflow:auto), NOT
       the window: every ScrollTrigger binds to it as `scroller`.
       Lenis was evaluated and REJECTED for this platform (the brief allows
       it "only if compatible"): it preventDefaults wheel/key input and
       replays it through its own rAF loop — in this shell that froze all
       scrolling in live probe tests. Native scrolling plus ScrollTrigger's
       scrub:1 catch-up smoothing gives the same buttery feel with zero
       input hijacking, on wheel, touch and keyboard alike. */
    const scrollerEl = (rootRef.current.closest("[data-generated-space-root]") as HTMLElement | null) ?? undefined;
    const S = scrollerEl ? { scroller: scrollerEl } : {};

    /* Canvas image-sequence scrub (the scroll-synchronised "video").
       Fallback contract: the stage always shows a poster photograph under
       the canvas, and the canvas only fades in after a real frame has
       drawn. If the 2D context is unavailable, or every sequence image
       fails to load, the poster stays — the section can never present as
       a pure-black slab. */
    const canvas = canvasRef.current;
    if (!canvas || !canvas.getContext("2d")) setSeqFailed(true);
    let seqErrCount = 0;
    const imgs: HTMLImageElement[] = SEQ_SRCS.map((src) => {
      const im = new Image();
      im.decoding = "async";
      im.addEventListener("error", () => {
        seqErrCount += 1;
        if (seqErrCount >= SEQ_SRCS.length) setSeqFailed(true);
      });
      /* Redraw as each frame arrives so the canvas fades in over its
         poster as soon as the first real frame is paintable. drawSeq and
         seqProgress are declared below; load events are always async, so
         the closure runs after they exist. */
      im.addEventListener("load", () => { drawSeq(seqProgress); });
      im.src = src;
      return im;
    });
    let seqProgress = 0;
    let drewFrame = false;
    const drawSeq = (p: number) => {
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const w = canvas.width;
      const h = canvas.height;
      if (!w || !h) return;
      const total = imgs.length - 1;
      const f = Math.min(total, Math.max(0, p * total));
      const i = Math.min(total - 1, Math.floor(f));
      const frac = f - i;
      const cover = (im: HTMLImageElement, zoom: number, pan: number) => {
        if (!im.complete || !im.naturalWidth) return;
        const sc = Math.max(w / im.naturalWidth, h / im.naturalHeight) * zoom;
        const dw = im.naturalWidth * sc;
        const dh = im.naturalHeight * sc;
        ctx.drawImage(im, (w - dw) / 2 + pan, (h - dh) / 2, dw, dh);
      };
      ctx.fillStyle = "#05080c";
      ctx.fillRect(0, 0, w, h);
      cover(imgs[i]!, 1.1 + frac * 0.09, -frac * w * 0.02);
      if (!drewFrame && imgs[i]!.complete && imgs[i]!.naturalWidth > 0) {
        drewFrame = true;
        setSeqReady(true);
      }
      if (frac > 0.01 && imgs[i + 1]) {
        ctx.save();
        ctx.globalAlpha = frac;
        cover(imgs[i + 1]!, 1.19 - frac * 0.09, (1 - frac) * w * 0.02);
        ctx.restore();
      }
      if (seqPctRef.current) seqPctRef.current.textContent = `${Math.round(p * 100)}%`;
      if (seqLabelRef.current) {
        const idx = Math.round(f);
        seqLabelRef.current.textContent = c.seqLabels[idx] ?? "";
      }
    };
    const sizeCanvas = () => {
      if (!canvas || !seqWrapRef.current) return;
      const stage = canvas.parentElement;
      if (!stage) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
      canvas.width = Math.round(stage.clientWidth * dpr);
      canvas.height = Math.round(stage.clientHeight * dpr);
      drawSeq(seqProgress);
    };
    imgs.forEach((im) => im.addEventListener("load", () => drawSeq(seqProgress)));
    sizeCanvas();
    window.addEventListener("resize", sizeCanvas);

    /* Real <video> scrub: scroll position drives currentTime (lerped) */
    const video = videoRef.current;
    let videoTarget = 0;
    let videoRaf = 0;
    const videoLoop = () => {
      videoRaf = requestAnimationFrame(videoLoop);
      if (video && video.duration && Number.isFinite(video.duration)) {
        const target = videoTarget * video.duration;
        if (Math.abs(video.currentTime - target) > 0.045) {
          try { video.currentTime = target; } catch { /* metadata not ready */ }
        }
      }
    };
    if (video) videoLoop();

    let ctxGsap: ReturnType<typeof gsap.context> | undefined;
    try {
    ctxGsap = gsap.context(() => {
      if (seqWrapRef.current) {
        ScrollTrigger.create({
          ...S,
          trigger: seqWrapRef.current,
          start: "top top",
          end: "bottom bottom",
          scrub: true,
          onUpdate: (self) => {
            seqProgress = self.progress;
            drawSeq(self.progress);
            videoTarget = self.progress;
          },
        });
      }
      /* Pinned cinematic story: crossfading scenes, camera zoom, parallax */
      if (storyWrapRef.current) {
        const scenes = sceneRefs.current.filter(Boolean) as HTMLDivElement[];
        const caps = captionRefs.current.filter(Boolean) as HTMLDivElement[];
        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: {
            ...S,
            trigger: storyWrapRef.current,
            start: "top top",
            end: "bottom bottom",
            scrub: 1,
            onUpdate: (self) => {
              if (storyBarRef.current) storyBarRef.current.style.transform = `scaleX(${self.progress})`;
              if (storyIdxRef.current) {
                const idx = Math.min(SCENE_IMGS.length, Math.floor(self.progress * SCENE_IMGS.length) + 1);
                storyIdxRef.current.textContent = `0${idx} / 0${SCENE_IMGS.length}`;
              }
              sceneRefs.current.forEach((el, i) => {
                if (!el) return;
                const active = Math.floor(self.progress * SCENE_IMGS.length) === i || (self.progress >= 0.999 && i === SCENE_IMGS.length - 1);
                el.setAttribute("aria-hidden", active ? "false" : "true");
              });
            },
          },
        });
        scenes.forEach((scene, i) => {
          const img = scene.querySelector("img");
          if (img) {
            tl.fromTo(img, { scale: 1.14, yPercent: -3.5 }, { scale: 1.02, yPercent: 3.5, duration: 1, ease: "none" }, i);
          }
          if (caps[i]) {
            if (i > 0) {
              tl.fromTo(caps[i]!, { y: 56, opacity: 0 }, { y: 0, opacity: 1, duration: 0.32, ease: "power2.out" }, i + 0.08);
            }
            if (i < scenes.length - 1) tl.to(caps[i]!, { y: -38, opacity: 0, duration: 0.3, ease: "power2.in" }, i + 0.72);
          }
          if (i > 0) {
            tl.fromTo(scene, { opacity: 0 }, { opacity: 1, duration: 0.42, ease: "power1.inOut" }, i);
            tl.to(scenes[i - 1]!, { opacity: 0, duration: 0.42, ease: "power1.inOut" }, i);
          }
          tl.to({}, { duration: 0.16 }, i + 0.84); // hold beat at each scene's end
        });
      }
      /* Horizontal journey */
      const track = horizTrackRef.current;
      if (track && horizWrapRef.current) {
        const dist = () => Math.max(0, track.scrollWidth - (horizWrapRef.current?.clientWidth ?? window.innerWidth) + 48);
        gsap.to(track, {
          x: () => -dist(),
          ease: "none",
          scrollTrigger: {
            ...S,
            trigger: horizWrapRef.current,
            start: "top top",
            end: "bottom bottom",
            scrub: 1,
            invalidateOnRefresh: true,
            onUpdate: (self) => {
              if (horizBarRef.current) horizBarRef.current.style.transform = `scaleX(${self.progress})`;
            },
          },
        });
        gsap.utils.toArray<HTMLElement>(".journey-card").forEach((card, i) => {
          gsap.fromTo(card, { y: i % 2 ? 26 : -10 }, {
            y: i % 2 ? -10 : 26, ease: "none",
            scrollTrigger: { ...S, trigger: horizWrapRef.current, start: "top top", end: "bottom bottom", scrub: 1.4 },
          });
        });
      }
      /* 3D rotation scrubbed by scroll */
      if (threeWrapRef.current && threeGroupRef.current) {
        gsap.to(threeGroupRef.current.rotation, {
          y: Math.PI * 2.5,
          x: 0.38,
          ease: "none",
          scrollTrigger: { ...S, trigger: threeWrapRef.current, start: "top bottom", end: "bottom top", scrub: 1 },
        });
      }
      /* Parallax on section headings inside scrolly */
      gsap.utils.toArray<HTMLElement>(".scrolly-parallax").forEach((el) => {
        gsap.fromTo(el, { y: 44 }, {
          y: -44, ease: "none",
          scrollTrigger: { ...S, trigger: el, start: "top bottom", end: "bottom top", scrub: 1.2 },
        });
      });
    }, rootRef);
    } catch (err) {
      /* GSAP/ScrollTrigger failed to initialise: kill any partial triggers
         and degrade the whole module to its static layout (rendered by
         the `engineFailed` branch) rather than leaving broken pinned
         stages on the page. */
      console.error("Scrollytelling engine failed; static fallback shown.", err);
      try { ScrollTrigger.getAll().forEach((st) => st.kill()); } catch { /* nothing to kill */ }
      setEngineFailed(true);
    }

    const refresh = () => ScrollTrigger.refresh();
    window.addEventListener("load", refresh);
    const t = setTimeout(refresh, 600);

    return () => {
      clearTimeout(t);
      window.removeEventListener("load", refresh);
      window.removeEventListener("resize", sizeCanvas);
      cancelAnimationFrame(videoRaf);
      ctxGsap?.revert();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduced, heroVideo, lang, c]);

  /* ------------- Static layout: reduced-motion OR engine failure ---------- */
  if (reduced || engineFailed) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-10">
        <h2 className="font-display text-3xl font-black">
          🎬 {c.reducedTitle}
        </h2>
        {heroVideo && (
          <video className="mt-5 w-full rounded-3xl" src={heroVideo} poster={heroElectrical} controls muted loop playsInline aria-label={c.videoAria} />
        )}
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {SCENE_IMGS.map((s, i) => (
            <article key={c.scenes[i]!.title} className="overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)]">
              <img src={s.img} alt={c.scenes[i]!.title} className="h-44 w-full object-cover" loading="lazy" decoding="async" />
              <div className="p-5">
                <h3 className="font-display text-xl font-bold">{s.icon} {c.scenes[i]!.title}</h3>
                <p className="mt-1 text-sm text-[var(--dim)]">{c.scenes[i]!.body}</p>
              </div>
            </article>
          ))}
        </div>
        <div className="mt-6 flex gap-4 overflow-x-auto pb-2" role="region" aria-label={c.reducedJourneyAria}>
          {JOURNEY_IMGS.map((j, i) => (
            <article key={c.journey[i]!.title} className="w-72 shrink-0 overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--surface)]">
              <img src={j.img} alt={c.journey[i]!.title} className="h-36 w-full object-cover" loading="lazy" decoding="async" />
              <div className="p-4">
                <h3 className="font-display font-bold">{c.journey[i]!.title}</h3>
                <p className="mt-1 text-sm text-[var(--dim)]">{c.journey[i]!.body}</p>
              </div>
            </article>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <button type="button" className="btn-primary rounded-xl px-6 py-3 font-display font-black" onClick={onBook}>{c.bookService}</button>
          <button type="button" className="rounded-xl border border-[var(--border)] px-6 py-3 font-display font-black" onClick={onExploreElectrical}>⚡ {c.electrical}</button>
          <button type="button" className="rounded-xl border border-[var(--border)] px-6 py-3 font-display font-black" onClick={onExplorePlumbing}>💧 {c.plumbing}</button>
        </div>
      </div>
    );
  }

  /* ------------------------------ Full layout ---------------------------- */
  return (
    <div ref={rootRef}>
      {/* ===== 1 · Scroll-synchronised video / canvas sequence (pinned) ===== */}
      <section aria-label={c.filmAria}>
        <div ref={seqWrapRef} className="relative" style={{ height: "340vh" }}>
          <div className="sticky top-0 h-[100svh] overflow-hidden bg-black">
            {heroVideo && !videoFailed ? (
              <>
                {/* Poster photograph underlay: the stage shows this photo
                    from the first paint, and the scrub video only fades in
                    over it once it can actually display a frame. If the
                    video stalls, is blocked, or cannot decode on this
                    device, the photo stays — the stage is never a black
                    slab waiting on the video. */}
                <img src={heroElectrical} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover" />
                <video ref={videoRef} className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${videoReady ? "opacity-100" : "opacity-0"}`} src={heroVideo} poster={heroElectrical} muted playsInline preload="auto" aria-label={c.videoAria} data-scrub-video="ready" onLoadedMetadata={() => setVideoReady(true)} onError={() => setVideoFailed(true)} />
                <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full opacity-0" aria-hidden />
                {!videoReady && <span className="absolute bottom-24 start-4 rounded-full bg-black/60 px-3 py-1 text-xs font-bold text-white" role="status">…</span>}
              </>
            ) : (
              <>
                {/* Poster underlay: visible instantly and permanently if the
                    canvas sequence cannot run — never a black stage. */}
                <img src={heroElectrical} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover" />
                {!seqFailed && (
                  <canvas
                    ref={canvasRef}
                    role="img"
                    aria-label={c.filmAria}
                    className={`absolute inset-0 h-full w-full transition-opacity duration-700 ${seqReady ? "opacity-100" : "opacity-0"}`}
                  />
                )}
              </>
            )}
            <div className="pointer-events-none absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(5,8,12,.5), transparent 32%, transparent 55%, rgba(5,8,12,.82))" }} />
            <div className="absolute inset-x-0 top-0 mx-auto flex max-w-6xl items-start justify-between px-4 pt-20 sm:pt-24">
              <div>
                <p className="font-display text-xs font-bold uppercase tracking-[0.3em] text-white/70">
                  {c.filmKicker}
                </p>
                <h2 className="mt-2 max-w-xl font-display text-3xl font-black leading-tight text-white sm:text-5xl">
                  {c.filmTitle}
                </h2>
                <p className="mt-2 max-w-md text-sm text-white/80 sm:text-base">
                  {c.filmSub}
                </p>
              </div>
              <div className="hidden text-end sm:block" aria-hidden>
                <span ref={seqPctRef} className="font-display text-5xl font-black text-white/90">0%</span>
                <span ref={seqLabelRef} className="block text-sm font-semibold text-white/70">{c.seqLabels[0]}</span>
              </div>
            </div>
            <div className="absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-4 pb-8">
              <div className="flex flex-wrap items-center gap-3">
                <button type="button" className="btn-primary rounded-xl px-5 py-3 font-display font-black" onClick={onBook}>
                  {c.bookThisWork}
                </button>
                <span className="text-sm font-semibold text-white/75" aria-hidden>↓ {c.keepScrolling} ↓</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== 2 · Pinned cinematic story: 5 connected scenes ===== */}
      <section aria-label={c.storyAria}>
        <div ref={storyWrapRef} className="relative" style={{ height: "560vh" }}>
          <div className="sticky top-0 h-[100svh] overflow-hidden bg-black">
            {SCENE_IMGS.map((s, i) => (
              <div
                key={c.scenes[i]!.title}
                ref={(el) => { sceneRefs.current[i] = el; }}
                className="absolute inset-0"
                style={{ opacity: i === 0 ? 1 : 0 }}
                aria-hidden={i !== 0}
              >
                <img src={s.img} alt="" className="h-full w-full scale-[1.08] object-cover will-change-transform" loading={i === 0 ? "eager" : "lazy"} decoding="async" />
                <div className="absolute inset-0" style={{ background: "linear-gradient(200deg, rgba(5,8,12,.28) 40%, rgba(5,8,12,.88) 88%)" }} />
              </div>
            ))}
            <div className="absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-4 pb-10">
              {SCENE_IMGS.map((s, i) => (
                <div
                  key={c.scenes[i]!.title}
                  ref={(el) => { captionRefs.current[i] = el; }}
                  className="absolute inset-x-4 bottom-24 max-w-2xl sm:inset-x-0"
                  style={i === 0 ? undefined : { opacity: 0 }}
                >
                  <p className="font-display text-sm font-bold uppercase tracking-[0.25em] text-white/70">{s.icon} {c.sceneWord} {i + 1}</p>
                  <h3 className="mt-2 font-display text-3xl font-black leading-tight text-white sm:text-5xl">{c.scenes[i]!.title}</h3>
                  <p className="mt-3 max-w-xl text-base text-white/85 sm:text-lg">{c.scenes[i]!.body}</p>
                </div>
              ))}
              <div className="relative mt-[46svh] flex items-center gap-4 sm:mt-[52svh]">
                <span ref={storyIdxRef} className="font-display text-sm font-black text-white/85" aria-hidden>01 / 05</span>
                <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/25" aria-hidden>
                  <div ref={storyBarRef} className="h-full w-full origin-left bg-white" style={{ transform: "scaleX(0)" }} />
                </div>
                <div className="flex gap-2">
                  <button type="button" className="rounded-lg bg-white/15 px-3 py-2 text-sm font-bold text-white backdrop-blur transition hover:bg-white/25" onClick={onExploreElectrical}>⚡ {c.electrical}</button>
                  <button type="button" className="rounded-lg bg-white/15 px-3 py-2 text-sm font-bold text-white backdrop-blur transition hover:bg-white/25" onClick={onExplorePlumbing}>💧 {c.plumbing}</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== 3 · Horizontal scroll journey ===== */}
      <section aria-label={c.journeyAria} className="bg-[var(--surface)]">
        <div ref={horizWrapRef} className="relative" style={{ height: "340vh" }}>
          <div className="sticky top-0 flex h-[100svh] flex-col justify-center overflow-hidden">
            <div className="scrolly-parallax mx-auto w-full max-w-6xl px-4">
              <p className="font-display text-xs font-bold uppercase tracking-[0.3em] text-[var(--accent)]">{c.journeyKicker}</p>
              <h2 className="mt-2 font-display text-3xl font-black sm:text-4xl">{c.journeyTitle}</h2>
              <p className="mt-2 max-w-xl text-[var(--dim)]">{c.journeySub}</p>
              <div className="mt-4 h-1 w-56 overflow-hidden rounded-full bg-[var(--border)]" aria-hidden>
                <div ref={horizBarRef} className="h-full w-full origin-left" style={{ background: "var(--grad)", transform: "scaleX(0)" }} />
              </div>
            </div>
            <div ref={horizTrackRef} className="mt-8 flex w-max gap-5 px-4 will-change-transform sm:px-[max(1rem,calc((100vw_-_72rem)/2_+_1rem))]">
              {JOURNEY_IMGS.map((j, i) => (
                <article key={c.journey[i]!.title} className="journey-card w-[78vw] max-w-sm shrink-0 overflow-hidden rounded-3xl border border-[var(--border)] bg-[var(--bg)] shadow-xl">
                  <img src={j.img} alt={c.journey[i]!.title} className="h-48 w-full object-cover sm:h-56" loading="lazy" decoding="async" />
                  <div className="p-5">
                    <h3 className="font-display text-xl font-bold">{j.icon} {c.journey[i]!.title}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-[var(--dim)]">{c.journey[i]!.body}</p>
                  </div>
                </article>
              ))}
              <article className="flex w-[78vw] max-w-sm shrink-0 flex-col justify-center rounded-3xl p-6 text-[var(--on-accent)]" style={{ background: "var(--grad)" }}>
                <h3 className="font-display text-2xl font-black">{c.journeyCtaTitle}</h3>
                <p className="mt-2 opacity-90">{c.journeyCtaBody}</p>
                <button type="button" className="mt-5 self-start rounded-xl bg-black/25 px-5 py-3 font-display font-black text-white" onClick={onBook}>{c.journeyCtaBtn}</button>
              </article>
            </div>
          </div>
        </div>
      </section>

      {/* ===== 4 · Scroll-rotated 3D: pipes + lightning ===== */}
      <section aria-label={c.threeAria} className="mx-auto w-full max-w-6xl overflow-x-clip px-4 py-14">
        <div ref={threeWrapRef} className="grid items-center gap-8 lg:grid-cols-2">
          <div className="scrolly-parallax">
            <p className="font-display text-xs font-bold uppercase tracking-[0.3em] text-[var(--accent)]">{c.threeKicker}</p>
            <h2 className="mt-2 font-display text-3xl font-black sm:text-4xl">{c.threeTitle}</h2>
            <p className="mt-3 max-w-lg leading-relaxed text-[var(--dim)]">
              {c.threeBody}
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <button type="button" className="btn-primary rounded-xl px-5 py-3 font-display font-black" onClick={onExploreElectrical}>⚡ {c.electricalServices}</button>
              <button type="button" className="rounded-xl border border-[var(--border)] px-5 py-3 font-display font-black" onClick={onExplorePlumbing}>💧 {c.plumbingServices}</button>
            </div>
          </div>
          <div className="relative overflow-hidden rounded-3xl border border-[var(--border)]" style={{ background: "radial-gradient(120% 120% at 30% 20%, var(--surface2), var(--surface))" }}>
            {threeFailed ? (
              <img src={pipesImg} alt={c.threeImgAlt} className="h-[420px] w-full object-cover" loading="lazy" />
            ) : (
              <div ref={threeMountRef} className="h-[420px] w-full" role="img" aria-label={c.threeImgAlt} />
            )}
            <p className="absolute bottom-3 end-4 text-xs font-bold text-[var(--dim)]" aria-hidden>↕ {c.scrollToRotate}</p>
          </div>
        </div>
      </section>
    </div>
  );
}
