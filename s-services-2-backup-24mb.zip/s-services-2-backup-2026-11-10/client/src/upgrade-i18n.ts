/* Strings for the Option-1 upgrade surfaces (services list/grid toggle,
   craft films section, Client Portal sign-in). Complete in all 11
   languages, same pattern as scrolly-i18n.ts — no fallback to Italian. */

export interface UpgradeStrings {
  listView: string;
  gridView: string;
  craftTitle: string;
  craftSub: string;
  signIn: string;
  createAccount: string;
  password: string;
  forgotPassword: string;
  resetRequested: string;
  protectedAccount: string;
  logout: string;
  changePassword: string;
  currentPassword: string;
  newPassword: string;
  mapTitle: string;
  mapSub: string;
  mapDemo: string;
  mapUnavailable: string;
  mapDirections: string;
  mapRadius: string;
  hoursLabel: string;
  availabilityLabel: string;
  haveAccount: string;
  noAccount: string;
  loginFailed: string;
  noPasswordSet: string;
  accountExists: string;
  lookupHint: string;
}

const en: UpgradeStrings = {
  listView: "List",
  gridView: "Grid",
  craftTitle: "The craft, in motion",
  craftSub:
    "Two short films from the field: an electrical panel wired to standard and a plumbing valve tightened by hand. Real video, with poster frames and a photo fallback.",
  mapTitle: "Where we work",
  mapSub: "Our base and the area covered by our electrical and plumbing teams. Zoom and pan the map to explore the service area.",
  mapDemo: "DEMO location — the administrator will replace it with the company's real base.",
  mapUnavailable: "The interactive map is unavailable right now. You can still reach us at the address below, or open directions.",
  mapDirections: "Directions",
  mapRadius: "Service radius",
  hoursLabel: "Opening hours",
  availabilityLabel: "Availability",
  signIn: "Sign in",
  createAccount: "Create account",
  password: "Password",
  forgotPassword: "Forgot your password?",
  resetRequested:
    "Request sent: the administration will set a temporary password and contact you.",
  protectedAccount:
    "This account is password-protected: sign in to see your bookings, quotations and invoices.",
  logout: "Sign out",
  changePassword: "Change password",
  currentPassword: "Current password",
  newPassword: "New password",
  haveAccount: "Already have an account?",
  noAccount: "No account yet?",
  loginFailed: "Incorrect email or password.",
  noPasswordSet:
    "This email has bookings but no password yet: create an account with the same email to claim and protect them.",
  accountExists:
    "An account with this email already exists — please sign in instead.",
  lookupHint:
    "Booked before passwords existed? Enter your email to view your records, or create an account to protect them.",
};

const it: UpgradeStrings = {
  listView: "Elenco",
  gridView: "Griglia",
  craftTitle: "Il mestiere, in movimento",
  craftSub:
    "Due brevi film dal campo: un quadro elettrico cablato a regola d'arte e una valvola idraulica serrata a mano. Video reali, con immagini di anteprima e alternativa fotografica.",
  mapTitle: "Dove operiamo",
  mapSub: "La nostra sede e l'area coperta dalle nostre squadre elettriche e idrauliche. Ingrandisci e sposta la mappa per esplorare la zona di servizio.",
  mapDemo: "Sede DEMO — l'amministratore la sostituirà con la sede reale dell'azienda.",
  mapUnavailable: "La mappa interattiva non è disponibile al momento. Puoi comunque raggiungerci all'indirizzo qui sotto o aprire le indicazioni stradali.",
  mapDirections: "Indicazioni stradali",
  mapRadius: "Raggio di servizio",
  hoursLabel: "Orari di apertura",
  availabilityLabel: "Disponibilità",
  signIn: "Accedi",
  createAccount: "Crea account",
  password: "Password",
  forgotPassword: "Password dimenticata?",
  resetRequested:
    "Richiesta inviata: l'amministrazione imposterà una password temporanea e ti contatterà.",
  protectedAccount:
    "Questo account è protetto da password: accedi per vedere prenotazioni, preventivi e fatture.",
  logout: "Esci",
  changePassword: "Cambia password",
  currentPassword: "Password attuale",
  newPassword: "Nuova password",
  haveAccount: "Hai già un account?",
  noAccount: "Non hai ancora un account?",
  loginFailed: "Email o password non corretti.",
  noPasswordSet:
    "Questa email ha prenotazioni ma ancora nessuna password: crea un account con la stessa email per proteggerle.",
  accountExists:
    "Esiste già un account con questa email: accedi invece di registrarti.",
  lookupHint:
    "Hai prenotato prima che esistessero le password? Inserisci la tua email per vedere le pratiche, oppure crea un account per proteggerle.",
};

const fr: UpgradeStrings = {
  listView: "Liste",
  gridView: "Grille",
  craftTitle: "Le métier, en mouvement",
  craftSub:
    "Deux courts films de terrain : un tableau électrique câblé dans les règles de l'art et une vanne de plomberie serrée à la main. Vidéo réelle, avec affiches et solution de repli photo.",
  mapTitle: "Où nous intervenons",
  mapSub: "Notre base et la zone couverte par nos équipes d'électriciens et de plombiers. Zoomez et déplacez la carte pour explorer la zone de service.",
  mapDemo: "Emplacement DÉMO — l'administrateur le remplacera par la base réelle de l'entreprise.",
  mapUnavailable: "La carte interactive n'est pas disponible pour le moment. Vous pouvez toujours nous rejoindre à l'adresse ci-dessous ou ouvrir l'itinéraire.",
  mapDirections: "Itinéraire",
  mapRadius: "Rayon de service",
  hoursLabel: "Horaires d'ouverture",
  availabilityLabel: "Disponibilité",
  signIn: "Se connecter",
  createAccount: "Créer un compte",
  password: "Mot de passe",
  forgotPassword: "Mot de passe oublié ?",
  resetRequested:
    "Demande envoyée : l'administration définira un mot de passe temporaire et vous contactera.",
  protectedAccount:
    "Ce compte est protégé par un mot de passe : connectez-vous pour voir vos réservations, devis et factures.",
  logout: "Se déconnecter",
  changePassword: "Changer le mot de passe",
  currentPassword: "Mot de passe actuel",
  newPassword: "Nouveau mot de passe",
  haveAccount: "Vous avez déjà un compte ?",
  noAccount: "Pas encore de compte ?",
  loginFailed: "E-mail ou mot de passe incorrect.",
  noPasswordSet:
    "Cet e-mail a des réservations mais pas encore de mot de passe : créez un compte avec le même e-mail pour les protéger.",
  accountExists:
    "Un compte avec cet e-mail existe déjà — connectez-vous plutôt.",
  lookupHint:
    "Vous avez réservé avant l'arrivée des mots de passe ? Saisissez votre e-mail pour voir vos dossiers, ou créez un compte pour les protéger.",
};

const de: UpgradeStrings = {
  listView: "Liste",
  gridView: "Raster",
  craftTitle: "Das Handwerk in Bewegung",
  craftSub:
    "Zwei kurze Filme von der Baustelle: ein fachgerecht verdrahteter Schaltschrank und ein von Hand angezogenes Sanitärventil. Echtes Video, mit Posterbild und Foto-Fallback.",
  mapTitle: "Wo wir arbeiten",
  mapSub: "Unser Standort und das Gebiet, das unsere Elektro- und Sanitärteams abdecken. Zoomen und verschieben Sie die Karte, um das Einsatzgebiet zu erkunden.",
  mapDemo: "DEMO-Standort — der Administrator ersetzt ihn durch den echten Firmensitz.",
  mapUnavailable: "Die interaktive Karte ist derzeit nicht verfügbar. Sie erreichen uns weiterhin unter der Adresse unten oder über die Wegbeschreibung.",
  mapDirections: "Wegbeschreibung",
  mapRadius: "Einsatzradius",
  hoursLabel: "Öffnungszeiten",
  availabilityLabel: "Verfügbarkeit",
  signIn: "Anmelden",
  createAccount: "Konto erstellen",
  password: "Passwort",
  forgotPassword: "Passwort vergessen?",
  resetRequested:
    "Anfrage gesendet: Die Verwaltung vergibt ein temporäres Passwort und kontaktiert Sie.",
  protectedAccount:
    "Dieses Konto ist passwortgeschützt: Melden Sie sich an, um Buchungen, Angebote und Rechnungen zu sehen.",
  logout: "Abmelden",
  changePassword: "Passwort ändern",
  currentPassword: "Aktuelles Passwort",
  newPassword: "Neues Passwort",
  haveAccount: "Haben Sie bereits ein Konto?",
  noAccount: "Noch kein Konto?",
  loginFailed: "E-Mail oder Passwort falsch.",
  noPasswordSet:
    "Diese E-Mail hat Buchungen, aber noch kein Passwort: Erstellen Sie ein Konto mit derselben E-Mail, um sie zu schützen.",
  accountExists:
    "Ein Konto mit dieser E-Mail existiert bereits — melden Sie sich bitte an.",
  lookupHint:
    "Vor der Passwort-Einführung gebucht? Geben Sie Ihre E-Mail ein, um Ihre Vorgänge zu sehen, oder erstellen Sie ein Konto, um sie zu schützen.",
};

const es: UpgradeStrings = {
  listView: "Lista",
  gridView: "Cuadrícula",
  craftTitle: "El oficio, en movimiento",
  craftSub:
    "Dos cortometrajes de campo: un cuadro eléctrico cableado según norma y una válvula de fontanería apretada a mano. Vídeo real, con pósteres y alternativa fotográfica.",
  mapTitle: "Dónde trabajamos",
  mapSub: "Nuestra base y la zona que cubren nuestros equipos de electricidad y fontanería. Amplía y desplaza el mapa para explorar el área de servicio.",
  mapDemo: "Ubicación DEMO — el administrador la reemplazará por la base real de la empresa.",
  mapUnavailable: "El mapa interactivo no está disponible ahora. Aun así puedes llegar a la dirección siguiente o abrir las indicaciones.",
  mapDirections: "Cómo llegar",
  mapRadius: "Radio de servicio",
  hoursLabel: "Horario de apertura",
  availabilityLabel: "Disponibilidad",
  signIn: "Iniciar sesión",
  createAccount: "Crear cuenta",
  password: "Contraseña",
  forgotPassword: "¿Olvidaste tu contraseña?",
  resetRequested:
    "Solicitud enviada: la administración establecerá una contraseña temporal y te contactará.",
  protectedAccount:
    "Esta cuenta está protegida con contraseña: inicia sesión para ver tus reservas, presupuestos y facturas.",
  logout: "Cerrar sesión",
  changePassword: "Cambiar contraseña",
  currentPassword: "Contraseña actual",
  newPassword: "Nueva contraseña",
  haveAccount: "¿Ya tienes una cuenta?",
  noAccount: "¿Aún no tienes cuenta?",
  loginFailed: "Correo o contraseña incorrectos.",
  noPasswordSet:
    "Este correo tiene reservas pero aún no contraseña: crea una cuenta con el mismo correo para protegerlas.",
  accountExists:
    "Ya existe una cuenta con este correo: inicia sesión en su lugar.",
  lookupHint:
    "¿Reservaste antes de que existieran las contraseñas? Introduce tu correo para ver tus trámites o crea una cuenta para protegerlos.",
};

const pt: UpgradeStrings = {
  listView: "Lista",
  gridView: "Grelha",
  craftTitle: "O ofício, em movimento",
  craftSub:
    "Dois pequenos filmes de campo: um quadro elétrico ligado segundo as normas e uma válvula de canalização apertada à mão. Vídeo real, com pósteres e alternativa fotográfica.",
  mapTitle: "Onde trabalhamos",
  mapSub: "A nossa base e a área coberta pelas nossas equipas de eletricidade e canalização. Amplie e arraste o mapa para explorar a área de serviço.",
  mapDemo: "Localização DEMO — o administrador irá substituí-la pela base real da empresa.",
  mapUnavailable: "O mapa interativo não está disponível neste momento. Pode ainda assim chegar ao endereço abaixo ou abrir as direções.",
  mapDirections: "Direções",
  mapRadius: "Raio de serviço",
  hoursLabel: "Horário de abertura",
  availabilityLabel: "Disponibilidade",
  signIn: "Entrar",
  createAccount: "Criar conta",
  password: "Palavra-passe",
  forgotPassword: "Esqueceu a palavra-passe?",
  resetRequested:
    "Pedido enviado: a administração definirá uma palavra-passe temporária e entrará em contacto.",
  protectedAccount:
    "Esta conta está protegida por palavra-passe: entre para ver as suas reservas, orçamentos e faturas.",
  logout: "Sair",
  changePassword: "Alterar palavra-passe",
  currentPassword: "Palavra-passe atual",
  newPassword: "Nova palavra-passe",
  haveAccount: "Já tem uma conta?",
  noAccount: "Ainda não tem conta?",
  loginFailed: "E-mail ou palavra-passe incorretos.",
  noPasswordSet:
    "Este e-mail tem reservas mas ainda não tem palavra-passe: crie uma conta com o mesmo e-mail para as proteger.",
  accountExists:
    "Já existe uma conta com este e-mail — entre em vez de se registar.",
  lookupHint:
    "Reservou antes de existirem palavras-passe? Introduza o seu e-mail para ver os seus processos ou crie uma conta para os proteger.",
};

const nl: UpgradeStrings = {
  listView: "Lijst",
  gridView: "Raster",
  craftTitle: "Het vak in beweging",
  craftSub:
    "Twee korte films uit het veld: een volgens de regels bedraad schakelpaneel en een met de hand aangedraaide loodgietersafsluiter. Echte video, met posters en fotoalternatief.",
  mapTitle: "Waar wij werken",
  mapSub: "Onze basis en het gebied dat onze elektro- en loodgietersteams bestrijken. Zoom en schuif de kaart om het werkgebied te verkennen.",
  mapDemo: "DEMO-locatie — de beheerder vervangt deze door de echte bedrijfsbasis.",
  mapUnavailable: "De interactieve kaart is momenteel niet beschikbaar. U kunt ons nog steeds bereiken op het onderstaande adres of de routebeschrijving openen.",
  mapDirections: "Routebeschrijving",
  mapRadius: "Werkstraal",
  hoursLabel: "Openingstijden",
  availabilityLabel: "Beschikbaarheid",
  signIn: "Inloggen",
  createAccount: "Account aanmaken",
  password: "Wachtwoord",
  forgotPassword: "Wachtwoord vergeten?",
  resetRequested:
    "Aanvraag verzonden: het beheer stelt een tijdelijk wachtwoord in en neemt contact met u op.",
  protectedAccount:
    "Dit account is met een wachtwoord beveiligd: log in om uw boekingen, offertes en facturen te zien.",
  logout: "Uitloggen",
  changePassword: "Wachtwoord wijzigen",
  currentPassword: "Huidig wachtwoord",
  newPassword: "Nieuw wachtwoord",
  haveAccount: "Hebt u al een account?",
  noAccount: "Nog geen account?",
  loginFailed: "Onjuist e-mailadres of wachtwoord.",
  noPasswordSet:
    "Dit e-mailadres heeft boekingen maar nog geen wachtwoord: maak een account met hetzelfde e-mailadres om ze te beveiligen.",
  accountExists:
    "Er bestaat al een account met dit e-mailadres — log in plaats daarvan in.",
  lookupHint:
    "Geboekt voordat er wachtwoorden waren? Vul uw e-mail in om uw dossiers te bekijken, of maak een account om ze te beveiligen.",
};

const tr: UpgradeStrings = {
  listView: "Liste",
  gridView: "Izgara",
  craftTitle: "Ustalık hareket hâlinde",
  craftSub:
    "Sahadan iki kısa film: standartlara uygun kablolanmış bir elektrik panosu ve elle sıkılmış bir tesisat vanası. Gerçek video; poster kareleri ve fotoğraf yedeğiyle.",
  mapTitle: "Nerede çalışıyoruz",
  mapSub: "Üssümüz ve elektrik ile tesisat ekiplerimizin kapsadığı alan. Hizmet alanını keşfetmek için haritayı yakınlaştırın ve kaydırın.",
  mapDemo: "DEMO konumu — yönetici bunu şirketin gerçek üssüyle değiştirecek.",
  mapUnavailable: "Etkileşimli harita şu anda kullanılamıyor. Aşağıdaki adresten bize yine de ulaşabilir veya yol tarifini açabilirsiniz.",
  mapDirections: "Yol tarifi",
  mapRadius: "Hizmet yarıçapı",
  hoursLabel: "Çalışma saatleri",
  availabilityLabel: "Müsaitlik",
  signIn: "Giriş yap",
  createAccount: "Hesap oluştur",
  password: "Parola",
  forgotPassword: "Parolanızı mı unuttunuz?",
  resetRequested:
    "Talep gönderildi: yönetim geçici bir parola belirleyip sizinle iletişime geçecek.",
  protectedAccount:
    "Bu hesap parola korumalıdır: rezervasyonlarınızı, tekliflerinizi ve faturalarınızı görmek için giriş yapın.",
  logout: "Çıkış yap",
  changePassword: "Parolayı değiştir",
  currentPassword: "Mevcut parola",
  newPassword: "Yeni parola",
  haveAccount: "Zaten hesabınız var mı?",
  noAccount: "Henüz hesabınız yok mu?",
  loginFailed: "E-posta veya parola hatalı.",
  noPasswordSet:
    "Bu e-postada rezervasyonlar var ancak henüz parola yok: aynı e-postayla hesap oluşturarak onları koruyun.",
  accountExists:
    "Bu e-postayla bir hesap zaten var — lütfen giriş yapın.",
  lookupHint:
    "Parolalardan önce mi rezervasyon yaptınız? Kayıtlarınızı görmek için e-postanızı girin veya korumak için bir hesap oluşturun.",
};

const ar: UpgradeStrings = {
  listView: "قائمة",
  gridView: "شبكة",
  craftTitle: "الحرفة في حركة",
  craftSub:
    "فيلمان قصيران من الميدان: لوحة كهربائية موصّلة وفق المعايير وصمام سباكة مشدود باليد. فيديو حقيقي، مع صور ملصق وبديل فوتوغرافي.",
  mapTitle: "أين نعمل",
  mapSub: "قاعدتنا والمنطقة التي تغطيها فرق الكهرباء والسباكة لدينا. كبّر الخريطة وحرّكها لاستكشاف منطقة الخدمة.",
  mapDemo: "موقع تجريبي (DEMO) — سيستبدله المسؤول بالقاعدة الحقيقية للشركة.",
  mapUnavailable: "الخريطة التفاعلية غير متاحة الآن. لا يزال بإمكانك الوصول إلينا عبر العنوان أدناه أو فتح الاتجاهات.",
  mapDirections: "الاتجاهات",
  mapRadius: "نطاق الخدمة",
  hoursLabel: "ساعات العمل",
  availabilityLabel: "التوفر",
  signIn: "تسجيل الدخول",
  createAccount: "إنشاء حساب",
  password: "كلمة المرور",
  forgotPassword: "نسيت كلمة المرور؟",
  resetRequested:
    "تم إرسال الطلب: ستعيّن الإدارة كلمة مرور مؤقتة وتتواصل معك.",
  protectedAccount:
    "هذا الحساب محمي بكلمة مرور: سجّل الدخول لرؤية حجوزاتك وعروض الأسعار والفواتير.",
  logout: "تسجيل الخروج",
  changePassword: "تغيير كلمة المرور",
  currentPassword: "كلمة المرور الحالية",
  newPassword: "كلمة المرور الجديدة",
  haveAccount: "هل لديك حساب بالفعل؟",
  noAccount: "ليس لديك حساب بعد؟",
  loginFailed: "البريد الإلكتروني أو كلمة المرور غير صحيحة.",
  noPasswordSet:
    "هذا البريد لديه حجوزات لكن لا توجد كلمة مرور بعد: أنشئ حسابًا بنفس البريد لحمايتها.",
  accountExists:
    "يوجد حساب بهذا البريد بالفعل — سجّل الدخول بدلاً من ذلك.",
  lookupHint:
    "حجزت قبل وجود كلمات المرور؟ أدخل بريدك الإلكتروني لعرض سجلاتك، أو أنشئ حسابًا لحمايتها.",
};

const ur: UpgradeStrings = {
  listView: "فہرست",
  gridView: "گرڈ",
  craftTitle: "حرکت میں ہنر",
  craftSub:
    "میدان سے دو مختصر فلمیں: معیار کے مطابق وائرنگ شدہ بجلی کا پینل اور ہاتھ سے کسا گیا پلمبنگ والو۔ اصلی ویڈیو، پوسٹر فریموں اور تصویری متبادل کے ساتھ۔",
  mapTitle: "ہم کہاں کام کرتے ہیں",
  mapSub: "ہمارا مرکز اور وہ علاقہ جہاں ہماری بجلی اور پلمبنگ ٹیمیں کام کرتی ہیں۔ سروس ایریا دیکھنے کے لیے نقشے کو زوم اور حرکت دیں۔",
  mapDemo: "ڈیمو مقام — منتظم اسے کمپنی کے اصل مرکز سے بدل دے گا۔",
  mapUnavailable: "انٹرایکٹو نقشہ اس وقت دستیاب نہیں۔ آپ پھر بھی نیچے دیے گئے پتے پر پہنچ سکتے ہیں یا راستہ کھول سکتے ہیں۔",
  mapDirections: "راستہ",
  mapRadius: "سروس کا دائرہ",
  hoursLabel: "اوقات کار",
  availabilityLabel: "دستیابی",
  signIn: "سائن ان",
  createAccount: "اکاؤنٹ بنائیں",
  password: "پاس ورڈ",
  forgotPassword: "پاس ورڈ بھول گئے؟",
  resetRequested:
    "درخواست بھیج دی گئی: انتظامیہ عارضی پاس ورڈ مقرر کر کے آپ سے رابطہ کرے گی۔",
  protectedAccount:
    "یہ اکاؤنٹ پاس ورڈ سے محفوظ ہے: اپنی بکنگ، کوٹیشن اور انوائسز دیکھنے کے لیے سائن ان کریں۔",
  logout: "سائن آؤٹ",
  changePassword: "پاس ورڈ تبدیل کریں",
  currentPassword: "موجودہ پاس ورڈ",
  newPassword: "نیا پاس ورڈ",
  haveAccount: "کیا آپ کا پہلے سے اکاؤنٹ ہے؟",
  noAccount: "ابھی اکاؤنٹ نہیں ہے؟",
  loginFailed: "ای میل یا پاس ورڈ غلط ہے۔",
  noPasswordSet:
    "اس ای میل پر بکنگز موجود ہیں مگر ابھی پاس ورڈ نہیں: اسی ای میل سے اکاؤنٹ بنا کر انہیں محفوظ کریں۔",
  accountExists:
    "اس ای میل سے پہلے ہی ایک اکاؤنٹ موجود ہے — براہ کرم سائن ان کریں۔",
  lookupHint:
    "پاس ورڈ آنے سے پہلے بکنگ کی تھی؟ اپنے ریکارڈ دیکھنے کے لیے ای میل درج کریں، یا انہیں محفوظ کرنے کے لیے اکاؤنٹ بنائیں۔",
};

export const UPGRADE: Record<string, UpgradeStrings> = {
  it,
  en,
  "en-GB": en,
  fr,
  de,
  es,
  pt,
  nl,
  tr,
  ar,
  ur,
};

export function upgradeStrings(lang: string): UpgradeStrings {
  return UPGRADE[lang] ?? en;
}

/* Report 22 strings: the personalized Salam greeting (with the real
   registered email / mobile from the signed-in account) and the
   Offers & Promotions surfaces (public section + Client Portal).
   Complete in all 11 languages; the greeting itself is the traditional
   Salam in Latin script, and in Arabic script for AR / Urdu script
   for UR. */
export interface PortalStrings {
  salam: string;
  registeredEmail: string;
  registeredMobile: string;
  offersTitle: string;
  offersSub: string;
  validUntil: string;
  noExpiry: string;
  offLabel: string;
  forYou: string;
}

const PORTAL_STRINGS: Record<string, PortalStrings> = {
  en: {
    salam: "Assalamu Alaikum",
    registeredEmail: "Registered email",
    registeredMobile: "Registered mobile number",
    offersTitle: "Offers & promotions",
    offersSub: "Current promotions from S SERVICES. Mention the offer when you book or request a quote.",
    validUntil: "Valid until",
    noExpiry: "No expiry date",
    offLabel: "off",
    forYou: "Reserved for you",
  },
  it: {
    salam: "Assalamu Alaikum",
    registeredEmail: "Email registrata",
    registeredMobile: "Numero di cellulare registrato",
    offersTitle: "Offerte e promozioni",
    offersSub: "Promozioni attive di S SERVICES. Menziona l'offerta quando prenoti o richiedi un preventivo.",
    validUntil: "Valida fino al",
    noExpiry: "Nessuna scadenza",
    offLabel: "di sconto",
    forYou: "Riservata a te",
  },
  fr: {
    salam: "Assalamu Alaikum",
    registeredEmail: "E-mail enregistré",
    registeredMobile: "Numéro de mobile enregistré",
    offersTitle: "Offres et promotions",
    offersSub: "Promotions en cours de S SERVICES. Mentionnez l'offre lors de votre réservation ou demande de devis.",
    validUntil: "Valable jusqu'au",
    noExpiry: "Sans date d'expiration",
    offLabel: "de remise",
    forYou: "Réservée pour vous",
  },
  de: {
    salam: "Assalamu Alaikum",
    registeredEmail: "Registrierte E-Mail",
    registeredMobile: "Registrierte Mobilnummer",
    offersTitle: "Angebote & Aktionen",
    offersSub: "Aktuelle Aktionen von S SERVICES. Erwähnen Sie das Angebot bei Ihrer Buchung oder Angebotsanfrage.",
    validUntil: "Gültig bis",
    noExpiry: "Kein Ablaufdatum",
    offLabel: "Rabatt",
    forYou: "Für Sie reserviert",
  },
  es: {
    salam: "Assalamu Alaikum",
    registeredEmail: "Correo electrónico registrado",
    registeredMobile: "Número de móvil registrado",
    offersTitle: "Ofertas y promociones",
    offersSub: "Promociones actuales de S SERVICES. Mencione la oferta al reservar o solicitar un presupuesto.",
    validUntil: "Válida hasta el",
    noExpiry: "Sin fecha de caducidad",
    offLabel: "de descuento",
    forYou: "Reservada para usted",
  },
  pt: {
    salam: "Assalamu Alaikum",
    registeredEmail: "E-mail registado",
    registeredMobile: "Número de telemóvel registado",
    offersTitle: "Ofertas e promoções",
    offersSub: "Promoções atuais da S SERVICES. Mencione a oferta ao reservar ou pedir um orçamento.",
    validUntil: "Válida até",
    noExpiry: "Sem data de validade",
    offLabel: "de desconto",
    forYou: "Reservada para si",
  },
  nl: {
    salam: "Assalamu Alaikum",
    registeredEmail: "Geregistreerd e-mailadres",
    registeredMobile: "Geregistreerd mobiel nummer",
    offersTitle: "Aanbiedingen & promoties",
    offersSub: "Actuele promoties van S SERVICES. Vermeld de aanbieding bij uw boeking of offerteaanvraag.",
    validUntil: "Geldig tot",
    noExpiry: "Geen vervaldatum",
    offLabel: "korting",
    forYou: "Voor u gereserveerd",
  },
  tr: {
    salam: "Assalamu Alaikum",
    registeredEmail: "Kayıtlı e-posta",
    registeredMobile: "Kayıtlı cep telefonu numarası",
    offersTitle: "Teklifler ve promosyonlar",
    offersSub: "S SERVICES'in güncel promosyonları. Rezervasyon veya fiyat teklifi talebinizde tekliften bahsedin.",
    validUntil: "Geçerlilik",
    noExpiry: "Son kullanma tarihi yok",
    offLabel: "indirim",
    forYou: "Size özel",
  },
  ar: {
    salam: "السلام عليكم",
    registeredEmail: "البريد الإلكتروني المسجل",
    registeredMobile: "رقم الجوال المسجل",
    offersTitle: "العروض والتخفيضات",
    offersSub: "العروض الحالية من S SERVICES. اذكر العرض عند الحجز أو طلب عرض السعر.",
    validUntil: "صالح حتى",
    noExpiry: "بدون تاريخ انتهاء",
    offLabel: "خصم",
    forYou: "مخصص لك",
  },
  ur: {
    salam: "السلام علیکم",
    registeredEmail: "رجسٹرڈ ای میل",
    registeredMobile: "رجسٹرڈ موبائل نمبر",
    offersTitle: "آفرز اور پروموزنز",
    offersSub: "S SERVICES کی موجودہ پروموزنز۔ بکنگ یا کوٹیشن کی درخواست کرتے وقت آفر کا ذکر کریں۔",
    validUntil: "درست تا",
    noExpiry: "کوئی اختتامی تاریخ نہیں",
    offLabel: "رعایت",
    forYou: "آپ کے لیے مخصوص",
  },
};
PORTAL_STRINGS["en-GB"] = PORTAL_STRINGS.en!;

export function portalStrings(lang: string): PortalStrings {
  return PORTAL_STRINGS[lang] ?? PORTAL_STRINGS.en!;
}

/* Report 23 strings: the hamburger navigation drawer (menu button,
   close label, the Client Login / Signup entry and the Admin Login
   entry). The remaining drawer items reuse the main dictionary
   (home / services / bookNow / getQuote / about / areas / contact /
   emergency). Complete in all 11 languages, no Italian fallback. */
export interface MenuStrings {
  menu: string;
  closeMenu: string;
  clientAccess: string;
  adminLogin: string;
  bookService: string;
}

const MENU_STRINGS: Record<string, MenuStrings> = {
  en: {
    menu: "Menu",
    closeMenu: "Close menu",
    clientAccess: "Client Login / Sign Up",
    adminLogin: "Admin Login",
    bookService: "Book a Service",
  },
  it: {
    menu: "Menu",
    closeMenu: "Chiudi menu",
    clientAccess: "Accesso Clienti / Registrazione",
    adminLogin: "Accesso Admin",
    bookService: "Prenota un servizio",
  },
  fr: {
    menu: "Menu",
    closeMenu: "Fermer le menu",
    clientAccess: "Connexion client / Inscription",
    adminLogin: "Connexion Admin",
    bookService: "Réserver un service",
  },
  de: {
    menu: "Menü",
    closeMenu: "Menü schließen",
    clientAccess: "Kunden-Login / Registrierung",
    adminLogin: "Admin-Login",
    bookService: "Service buchen",
  },
  es: {
    menu: "Menú",
    closeMenu: "Cerrar menú",
    clientAccess: "Acceso clientes / Registro",
    adminLogin: "Acceso Admin",
    bookService: "Reservar un servicio",
  },
  pt: {
    menu: "Menu",
    closeMenu: "Fechar menu",
    clientAccess: "Acesso do cliente / Registo",
    adminLogin: "Acesso Admin",
    bookService: "Marcar um serviço",
  },
  nl: {
    menu: "Menu",
    closeMenu: "Menu sluiten",
    clientAccess: "Klantlogin / Registreren",
    adminLogin: "Admin-login",
    bookService: "Dienst boeken",
  },
  tr: {
    menu: "Menü",
    closeMenu: "Menüyü kapat",
    clientAccess: "Müşteri Girişi / Kayıt",
    adminLogin: "Yönetici Girişi",
    bookService: "Servis rezervasyonu",
  },
  ar: {
    menu: "القائمة",
    closeMenu: "إغلاق القائمة",
    clientAccess: "دخول العميل / إنشاء حساب",
    adminLogin: "دخول المسؤول",
    bookService: "احجز خدمة",
  },
  ur: {
    menu: "مینیو",
    closeMenu: "مینیو بند کریں",
    clientAccess: "کلائنٹ لاگ ان / سائن اپ",
    adminLogin: "ایڈمن لاگ ان",
    bookService: "سروس بک کریں",
  },
};
MENU_STRINGS["en-GB"] = MENU_STRINGS.en!;

export function menuStrings(lang: string): MenuStrings {
  return MENU_STRINGS[lang] ?? MENU_STRINGS.en!;
}
