import { useEffect, useRef, useState } from "react";
/* The platform map runtime is a large file (~1.3 MB): it is imported
   as a FILE asset, so it is emitted as its own file and fetched only
   when a map actually mounts — it never joins the initial bundle.
   This keeps the homepage's first load exactly as fast as before. */
import mapsJsUrl from "./assets/hatch-maps.bin" with { type: "file" };
import mapsCssUrl from "./assets/hatch-maps-css.bin" with { type: "file" };
import { mapsDirectionsUrl, mountMap } from "./map-helpers.mjs";

interface MapHandle {
  destroy: () => void;
  selectPlace: (index: number | null) => void;
}

export interface ServiceMapConfig {
  name: string;
  address: string;
  lat: number;
  lng: number;
  radiusKm: number;
  isDemo: boolean;
}

export interface ServiceMapStrings {
  unavailable: string;
  directions: string;
  radius: string;
}

/* Load the runtime once per page; every later map mount reuses it.
   The runtime bytes ship as .bin file assets (copied verbatim by the
   build, like the videos): they are fetched, then the stylesheet is
   injected as a <style> element and the script runs from a Blob URL —
   so no server content-type is involved and nothing about the map
   touches the initial page load. Any failure (offline, blocked,
   unsupported WebGL) resolves false so the component can show its
   fallback panel instead of crashing. */
let runtimePromise: Promise<boolean> | null = null;
function loadMapRuntime(): Promise<boolean> {
  const w = window as unknown as { HatchMaps?: unknown };
  if (w.HatchMaps) return Promise.resolve(true);
  runtimePromise ??= (async () => {
    try {
      const [jsBuf, cssText] = await Promise.all([
        fetch(mapsJsUrl).then((r) => {
          if (!r.ok) throw new Error("map runtime fetch failed");
          return r.arrayBuffer();
        }),
        fetch(mapsCssUrl).then((r) => (r.ok ? r.text() : "")),
      ]);
      if (cssText && !document.querySelector("style[data-ss-maps]")) {
        const style = document.createElement("style");
        style.dataset.ssMaps = "1";
        style.textContent = cssText;
        document.head.appendChild(style);
      }
      const blobUrl = URL.createObjectURL(
        new Blob([jsBuf], { type: "text/javascript" }),
      );
      return await new Promise<boolean>((resolve) => {
        const script = document.createElement("script");
        script.src = blobUrl;
        script.async = true;
        script.onload = () =>
          resolve(!!(window as unknown as { HatchMaps?: unknown }).HatchMaps);
        script.onerror = () => resolve(false);
        document.head.appendChild(script);
      });
    } catch {
      return false;
    }
  })();
  return runtimePromise;
}

/* GeoJSON ring approximating a circle of `radiusKm` around the base.
   GeoJSON coordinates are [lng, lat]; the map control's places take
   named {lat, lng} — the conversion happens only here. */
function circleFeature(lat: number, lng: number, radiusKm: number) {
  const points = 72;
  const dLat = radiusKm / 110.574;
  const cosLat = Math.cos((lat * Math.PI) / 180);
  const dLng = radiusKm / (111.32 * (Math.abs(cosLat) < 0.01 ? 0.01 : cosLat));
  const ring: [number, number][] = [];
  for (let i = 0; i <= points; i++) {
    const a = (i / points) * 2 * Math.PI;
    ring.push([lng + dLng * Math.cos(a), lat + dLat * Math.sin(a)]);
  }
  return {
    type: "Feature" as const,
    properties: {},
    geometry: { type: "Polygon" as const, coordinates: [ring] },
  };
}

function zoomForRadius(radiusKm: number): number {
  const z = Math.round(14.5 - Math.log2(Math.max(1, radiusKm)));
  return Math.min(14, Math.max(6, z));
}

export function directionsUrl(cfg: ServiceMapConfig): string | null {
  return mapsDirectionsUrl({
    label: cfg.name,
    address: cfg.address,
    lat: cfg.lat,
    lng: cfg.lng,
  });
}

export function ServiceAreaMap({
  cfg,
  dark,
  strings,
}: {
  cfg: ServiceMapConfig;
  dark: boolean;
  strings: ServiceMapStrings;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [unavailable, setUnavailable] = useState(false);
  const cfgKey = `${cfg.lat}|${cfg.lng}|${cfg.radiusKm}|${cfg.name}|${dark ? "d" : "l"}`;

  useEffect(() => {
    let cancelled = false;
    let handle: MapHandle | null = null;
    setUnavailable(false);
    void loadMapRuntime().then((ok) => {
      if (cancelled) return;
      const el = containerRef.current;
      if (!ok || !el) {
        setUnavailable(true);
        return;
      }
      try {
        handle = mountMap(
          el,
          {
            places: [{ label: cfg.name, lat: cfg.lat, lng: cfg.lng }],
            center: { lat: cfg.lat, lng: cfg.lng },
            zoom: zoomForRadius(cfg.radiusKm),
            baseStyle: dark ? "dark" : "light",
            overlays: [
              {
                id: "service-area",
                data: {
                  type: "FeatureCollection",
                  features: [circleFeature(cfg.lat, cfg.lng, cfg.radiusKm)],
                },
                layers: [
                  {
                    id: "service-area-fill",
                    type: "fill",
                    source: "service-area",
                    paint: { "fill-color": "#2f7bff", "fill-opacity": 0.22 },
                  },
                  {
                    id: "service-area-line",
                    type: "line",
                    source: "service-area",
                    paint: { "line-color": "#2f7bff", "line-width": 2.5 },
                  },
                ],
              },
            ],
          },
          () => {
            if (!cancelled) setUnavailable(true);
          },
        );
        if (!handle && !cancelled) setUnavailable(true);
      } catch {
        if (!cancelled) setUnavailable(true);
      }
    });
    return () => {
      cancelled = true;
      try {
        handle?.destroy();
      } catch {
        /* a half-mounted map must never take the page down with it */
      }
    };
    // cfgKey captures every value the mount depends on.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cfgKey]);

  const dir = directionsUrl(cfg);

  if (unavailable) {
    return (
      <div className="grid place-items-center rounded-3xl border border-[var(--border)] bg-[var(--surface2)] p-6 text-center" style={{ minHeight: 320 }}>
        <div className="max-w-md">
          <p className="text-4xl" aria-hidden>📍</p>
          <p className="mt-3 font-display text-lg font-black">{cfg.name}</p>
          <p className="mt-1 text-sm text-[var(--dim)]">{cfg.address}</p>
          <p className="mt-1 text-sm text-[var(--dim)]">
            {strings.radius}: {cfg.radiusKm} km
          </p>
          <p className="mt-3 text-sm text-[var(--dim)]">{strings.unavailable}</p>
          {dir && (
            <a
              href={dir}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary mt-4 inline-block rounded-xl px-5 py-2.5 font-display text-sm font-black"
            >
              🧭 {strings.directions}
            </a>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="w-full overflow-hidden rounded-3xl border border-[var(--border)]"
      style={{ height: 380, background: "var(--surface2)" }}
      role="application"
      aria-label={`${cfg.name} — ${strings.radius}: ${cfg.radiusKm} km`}
    />
  );
}
