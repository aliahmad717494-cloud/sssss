PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "__drizzle_migrations" (
			id SERIAL PRIMARY KEY,
			hash text NOT NULL,
			created_at numeric
		);
INSERT INTO __drizzle_migrations VALUES(NULL,'f80c5bf6f7a9bf54eda650a2ac2fcc4390051e8c56a52d5be51e5cbf641b7ba9',1794134774393);
INSERT INTO __drizzle_migrations VALUES(NULL,'2c12dbb1d94a5ee2c336379591319c451c4656ef90e2b24c07d9363f709cec2f',1794134774393);
INSERT INTO __drizzle_migrations VALUES(NULL,'9f13ffaeca8330e9c4ae6b21ffe984a24bfe0c26f2dc9d76b112b4b0cf4ccb98',1794245976376);
INSERT INTO __drizzle_migrations VALUES(NULL,'06b8212d0d882ff959aafdb41e03de90b69f9e3c276b6c61a4ffc7c414619bff',1794250770076);
CREATE TABLE services (
  slug TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  name_it TEXT NOT NULL,
  name_en TEXT NOT NULL,
  sort INTEGER NOT NULL DEFAULT 0,
  published INTEGER NOT NULL DEFAULT 1,
  base_price_cents INTEGER
);
INSERT INTO services VALUES('residential-electrical-installation','electrical','Installazione Elettrica Residenziale','Residential Electrical Installation',0,1,NULL);
INSERT INTO services VALUES('commercial-electrical-systems','electrical','Impianti Elettrici Commerciali','Commercial Electrical Systems',1,1,NULL);
INSERT INTO services VALUES('industrial-electrical-installations','electrical','Installazioni Elettriche Industriali','Industrial Electrical Installations',2,1,NULL);
INSERT INTO services VALUES('electrical-repairs','electrical','Riparazioni Elettriche','Electrical Repairs',3,1,NULL);
INSERT INTO services VALUES('emergency-electrical-services','electrical','Servizi Elettrici di Emergenza','Emergency Electrical Services',4,1,NULL);
INSERT INTO services VALUES('electrical-panel-installation','electrical','Installazione Quadro Elettrico','Electrical Panel Installation',5,1,NULL);
INSERT INTO services VALUES('circuit-breaker-replacement','electrical','Sostituzione Interruttori Magnetotermici','Circuit Breaker Replacement',6,1,NULL);
INSERT INTO services VALUES('lighting-installation','electrical','Installazione Illuminazione','Lighting Installation',7,1,NULL);
INSERT INTO services VALUES('led-lighting-solutions','electrical','Soluzioni di Illuminazione LED','LED Lighting Solutions',8,1,NULL);
INSERT INTO services VALUES('indoor-outdoor-lighting','electrical','Illuminazione Interna ed Esterna','Indoor and Outdoor Lighting',9,1,NULL);
INSERT INTO services VALUES('wiring-rewiring','electrical','Cablaggio e Ricablaggio','Wiring and Rewiring',10,1,NULL);
INSERT INTO services VALUES('electrical-fault-detection','electrical','Ricerca Guasti Elettrici','Electrical Fault Detection',11,1,NULL);
INSERT INTO services VALUES('electrical-maintenance','electrical','Manutenzione Elettrica','Electrical Maintenance',12,1,NULL);
INSERT INTO services VALUES('smart-home-installation','electrical','Installazione Smart Home','Smart Home Installation',13,1,NULL);
INSERT INTO services VALUES('home-automation','electrical','Domotica e Automazione Domestica','Home Automation',14,1,NULL);
INSERT INTO services VALUES('security-cctv-installation','electrical','Installazione Sicurezza e Videosorveglianza','Security and CCTV Installation',15,1,NULL);
INSERT INTO services VALUES('solar-panel-installation','electrical','Installazione Pannelli Solari','Solar Panel Installation',16,1,NULL);
INSERT INTO services VALUES('ev-charger-installation','electrical','Installazione Caricatore per Veicoli Elettrici','EV Charger Installation',17,1,NULL);
INSERT INTO services VALUES('electrical-inspection','electrical','Ispezione e Verifica Elettrica','Electrical Inspection',18,1,NULL);
INSERT INTO services VALUES('energy-efficiency-solutions','electrical','Soluzioni di Efficienza Energetica','Energy Efficiency Solutions',19,1,NULL);
INSERT INTO services VALUES('residential-plumbing','plumbing','Idraulica Residenziale','Residential Plumbing',20,1,NULL);
INSERT INTO services VALUES('commercial-plumbing','plumbing','Idraulica Commerciale','Commercial Plumbing',21,1,NULL);
INSERT INTO services VALUES('industrial-plumbing','plumbing','Idraulica Industriale','Industrial Plumbing',22,1,NULL);
INSERT INTO services VALUES('emergency-plumbing','plumbing','Idraulica di Emergenza','Emergency Plumbing',23,1,NULL);
INSERT INTO services VALUES('water-leak-detection','plumbing','Ricerca Perdite d''Acqua','Water Leak Detection',24,1,NULL);
INSERT INTO services VALUES('pipe-installation','plumbing','Installazione Tubazioni','Pipe Installation',25,1,NULL);
INSERT INTO services VALUES('pipe-repair','plumbing','Riparazione Tubazioni','Pipe Repair',26,1,NULL);
INSERT INTO services VALUES('drain-cleaning','plumbing','Pulizia Scarichi','Drain Cleaning',27,1,NULL);
INSERT INTO services VALUES('blocked-drain-removal','plumbing','Disostruzione Scarichi','Blocked Drain Removal',28,1,NULL);
INSERT INTO services VALUES('bathroom-plumbing','plumbing','Idraulica Bagno','Bathroom Plumbing',29,1,NULL);
INSERT INTO services VALUES('kitchen-plumbing','plumbing','Idraulica Cucina','Kitchen Plumbing',30,1,NULL);
INSERT INTO services VALUES('bathroom-renovation','plumbing','Ristrutturazione Bagno','Bathroom Renovation',31,1,NULL);
INSERT INTO services VALUES('water-heater-installation','plumbing','Installazione Scaldabagno','Water Heater Installation',32,1,NULL);
INSERT INTO services VALUES('boiler-installation-maintenance','plumbing','Installazione e Manutenzione Caldaie','Boiler Installation and Maintenance',33,1,NULL);
INSERT INTO services VALUES('heating-systems','plumbing','Impianti di Riscaldamento','Heating Systems',34,1,NULL);
INSERT INTO services VALUES('water-pressure-problems','plumbing','Problemi di Pressione dell''Acqua','Water Pressure Problems',35,1,NULL);
INSERT INTO services VALUES('sanitary-installation','plumbing','Installazione Sanitari','Sanitary Installation',36,1,NULL);
INSERT INTO services VALUES('tap-faucet-installation','plumbing','Installazione Rubinetteria','Tap and Faucet Installation',37,1,NULL);
INSERT INTO services VALUES('toilet-repair-installation','plumbing','Riparazione e Installazione WC','Toilet Repair and Installation',38,1,NULL);
INSERT INTO services VALUES('water-supply-systems','plumbing','Impianti di Adduzione Idrica','Water Supply Systems',39,1,NULL);
INSERT INTO services VALUES('plumbing-inspection','plumbing','Ispezione Idraulica','Plumbing Inspection',40,1,NULL);
INSERT INTO services VALUES('preventive-maintenance','plumbing','Manutenzione Preventiva','Preventive Maintenance',41,1,NULL);
CREATE TABLE customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  language TEXT NOT NULL DEFAULT 'it',
  currency TEXT NOT NULL DEFAULT 'EUR',
  created_at INTEGER NOT NULL
, `password_hash` text DEFAULT '' NOT NULL);
CREATE TABLE technicians (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  specialty TEXT NOT NULL DEFAULT 'both',
  role TEXT NOT NULL DEFAULT 'technician',
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  service_slug TEXT NOT NULL,
  category TEXT NOT NULL,
  property_type TEXT NOT NULL DEFAULT 'residential',
  description TEXT NOT NULL DEFAULT '',
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  postal_code TEXT NOT NULL DEFAULT '',
  date TEXT NOT NULL DEFAULT '',
  slot TEXT NOT NULL DEFAULT '',
  language TEXT NOT NULL DEFAULT 'it',
  is_emergency INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'new',
  technician_id INTEGER,
  internal_notes TEXT NOT NULL DEFAULT '',
  work_notes TEXT NOT NULL DEFAULT '',
  photo_name TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE quote_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  service_slug TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  property_type TEXT NOT NULL DEFAULT 'residential',
  measurements TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL DEFAULT '',
  language TEXT NOT NULL DEFAULT 'it',
  status TEXT NOT NULL DEFAULT 'new',
  photo_name TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE quotations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  quote_request_id INTEGER,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  title TEXT NOT NULL,
  labour_cents INTEGER NOT NULL DEFAULT 0,
  materials_cents INTEGER NOT NULL DEFAULT 0,
  service_cents INTEGER NOT NULL DEFAULT 0,
  discount_cents INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'EUR',
  expiry_date TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft',
  created_at INTEGER NOT NULL
);
CREATE TABLE invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  quotation_id INTEGER,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  amount_cents INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'EUR',
  status TEXT NOT NULL DEFAULT 'unpaid',
  due_date TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE service_areas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  country TEXT NOT NULL,
  region TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL,
  postal_codes TEXT NOT NULL DEFAULT '',
  electrical INTEGER NOT NULL DEFAULT 1,
  plumbing INTEGER NOT NULL DEFAULT 1,
  emergency INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  surcharge_cents INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'electrical',
  location TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  is_demo INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT NOT NULL,
  service_slug TEXT NOT NULL DEFAULT '',
  rating REAL NOT NULL DEFAULT 5,
  body TEXT NOT NULL DEFAULT '',
  approved INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL DEFAULT 'contact',
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  subject TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  email TEXT,
  is_read INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
INSERT INTO settings VALUES('default_theme','electric');
INSERT INTO settings VALUES('default_language','it');
INSERT INTO settings VALUES('default_currency','EUR');
INSERT INTO settings VALUES('company_phone','');
INSERT INTO settings VALUES('company_whatsapp','');
INSERT INTO settings VALUES('company_email','');
INSERT INTO settings VALUES('company_address','');
INSERT INTO settings VALUES('emergency_enabled','');
INSERT INTO settings VALUES('emergency_note','');
INSERT INTO settings VALUES('hero_video_url','');
INSERT INTO settings VALUES('about_it','');
INSERT INTO settings VALUES('about_en','');
CREATE TABLE activity_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
INSERT INTO activity_log VALUES(1,'catalog.populate','42 services seeded',1794135084970);
INSERT INTO activity_log VALUES(2,'staff.bootstrap','494motors@gmail.com',1794254222517);
INSERT INTO activity_log VALUES(3,'staff.login','494motors@gmail.com (admin)',1794254952029);
CREATE TABLE `staff_users` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`password_hash` text NOT NULL,
	`role` text DEFAULT 'technician' NOT NULL,
	`technician_id` integer,
	`active` integer DEFAULT 1 NOT NULL,
	`created_at` integer NOT NULL
);
INSERT INTO staff_users VALUES(1,'ali','494motors@gmail.com','pbkdf2$210000$Qv6OcCE9O7/r3sI71/J3UQ==$NUo7xJzD2dd85W1ul0MrZ/IlTHflwigXWTPvlxNf9Gg=','admin',NULL,1,1794254222476);
CREATE TABLE `sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`email` text NOT NULL,
	`staff_id` integer,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL
);
INSERT INTO sessions VALUES('43dcca1dc5cda95d159f17674df8e0c5d82efe09c84f7d73e730ddd8fd08e1a5','staff','494motors@gmail.com',1,1796846222504,1794254222504);
INSERT INTO sessions VALUES('eaf1e475371015a33ff27e99861ac004fa43f8cde08dd1a8823c58ec36c9aa63','staff','494motors@gmail.com',1,1796846951990,1794254951991);
CREATE TABLE `offers` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`discount_type` text DEFAULT 'percent' NOT NULL,
	`discount_value` integer DEFAULT 0 NOT NULL,
	`scope` text DEFAULT 'public' NOT NULL,
	`service_slug` text DEFAULT '' NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`starts_at` text DEFAULT '' NOT NULL,
	`expires_at` text DEFAULT '' NOT NULL,
	`created_at` integer DEFAULT 0 NOT NULL
);
CREATE TABLE `offer_assignments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`offer_id` integer NOT NULL,
	`customer_email` text NOT NULL
);
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('activity_log',3);
INSERT INTO sqlite_sequence VALUES('staff_users',1);
CREATE UNIQUE INDEX `staff_users_email_unique` ON `staff_users` (`email`);
COMMIT;
