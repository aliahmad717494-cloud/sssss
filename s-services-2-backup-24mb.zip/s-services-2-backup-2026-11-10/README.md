# S SERVICES — Complete Project Backup

**Source:** Muse AI / Hatch fullstack artifact `s-services-2`
**Live version backed up:** v15 (build `09ebe19b-1fa6-4048-a815-846fab4acc3a`)
**Backup date:** 10 November 2026, 01:42 PKT (Asia/Karachi)
**Source-tree fingerprint (prior inspection):** `cf22d1df99dd6de610ff3ac2c6b91ec45a226556628b77e2d2ae1b7902e07afd`

## What this backup contains

A verbatim copy of the entire `s-services-2` project tree as it existed at backup
time, plus a database backup. Nothing in the original project was modified to
create this backup (read-only copy out).

- **Frontend source** — `client/src/` (App.tsx, admin.tsx, portal.tsx, api.ts,
  i18n.ts, service-i18n.ts, scrolly-i18n.ts, scrolly.tsx, upgrade-i18n.ts,
  theme.css, forms.tsx, catalog.ts, storage.ts, service-map.tsx,
  map-helpers.mjs, main.tsx, globals.d.ts), `client/index.html`,
  `client/build.mjs`, `client/tsconfig.json`, plus built output in
  `client/dist/`, `client/dist-cvm/`, `.space-build/` and `.space-build-cvm/`
  (with their manifests).
- **Backend source** — `server/src/actions.ts` (2,719 lines, all **45 server
  actions** — 45 `defineAction(` call sites verified in this file),
  `server/src/schema.ts` (Drizzle sqlite-core schema), `server/src/catalog.ts`,
  `server/tsconfig.json`, plus built output in `server/dist/`.
- **Database schema & migrations** — `drizzle/0001_initial.sql`,
  `0002_s_services_platform_tables.sql`, `0003_staff_and_customer_auth.sql`,
  `0004_offers_and_promotions.sql`, `drizzle/meta/_journal.json`.
- **Database backup** — `database/app.db` (byte-for-byte copy of the live
  SQLite file; SHA-256 matches the live file at backup time) and
  `database/app-dump.sql` (a `sqlite3 .dump` of that copy, 268 lines). The
  project-tree copy also contains the live `app.db` at the backup root; both
  copies have the identical SHA-256.
- **Assets** — `client/src/assets/`: 4 MP4s (hero-video-electrical 652 KB,
  hero-video-plumbing 736 KB, craft-electrical 963 KB, craft-plumbing 929 KB),
  posters/photos (JPG/WebP), `hatch-maps.bin` (1,301,613 B) and
  `hatch-maps-css.bin`, plus the media-generation JSON sidecars.
- **Configuration** — `package.json`, `bun.lock`, `bunfig.toml`, `space.json`,
  `tsconfig.base.json`, `AGENTS.md`, `DATA-PLAN.md`, `icon.webp`,
  `.xmds-icon`, `.harness/` (app map, audit/build metadata).

## Verified contents (measured on a restored scratch copy — see manifest)

| Table | Rows |
|---|---|
| services | 42 (20 electrical, 22 plumbing; all published; 42 distinct slugs) |
| settings | 12 |
| staff_users | 1 (admin, 494motors@gmail.com, active; password hash format `pbkdf2$210000$…` intact) |
| sessions | 2 (staff) |
| activity_log | 3 |
| customers, bookings, quote_requests, quotations, invoices, offers, offer_assignments, messages, notifications, projects, reviews, service_areas, technicians | 0 each |
| __drizzle_migrations | 4 |

Verification performed: `PRAGMA integrity_check` = ok on the copied DB;
`app-dump.sql` restored cleanly into a scratch SQLite file and opened;
row counts above were read from that restored copy and match the expected
original counts exactly. File inventory was diffed against the source tree:
no differences (see "Not included" below for the deliberate exclusions).

## How to restore and verify

1. Extract the backup to a directory of your choice.
2. **Database (option A — file copy):** use `database/app.db` directly as
   the SQLite database.
   **Database (option B — dump):** create a fresh SQLite file and load the
   dump: `sqlite3 fresh.db < database/app-dump.sql`. Or apply the Drizzle
   migrations in order (`drizzle/0001` → `0004`) to a fresh SQLite database
   and then import `database/app-dump.sql` (or the `app.db` copy) for the data.
3. **Verify:** run `sqlite3 <db> "PRAGMA integrity_check;"` (must print
   `ok`), then compare per-table `SELECT COUNT(*)` results against the table
   above and re-run the SHA-256 hashes in `BACKUP-MANIFEST.md` against the
   extracted files (`sha256sum -c` style check on the manifest's hash list).
4. **Run (Muse/Hatch only):** this is a Hatch-native project. It runs only
   inside the Muse/Hatch TypeScript space runtime: Bun 1.3.10,
   `@hatch/space-sdk` (a `file:/opt/hatch/skills/spaces/ts-runtime/dist/space-sdk.tgz`
   dependency — see "Not included"), `bun install`, then `bun run build`
   (`bun run build:server && bun run build:client`). Do **not** run
   `populateCatalog` on a restored copy that already contains the 42 services,
   and do **not** re-run `staffBootstrap` on a restored copy that already has
   a staff account (it is refused once any staff account exists).

## IMPORTANT — this backup will NOT run verbatim on Cloudflare or Lovable

This is a Muse/Hatch-native project, not a portable web app:

- The backend is 45 server actions using the Hatch SDK (`defineAction` /
  `Ctx`, `ctx.db()`, `ctx.invalidateQueries()`), called by the frontend via
  `createActionClient` POSTing `{action, args}` to `./actions`.
- `client/src/main.tsx` requires the Hatch host shell
  (`data-generated-space-root`, `spaceQueryClient`).
- The build is Bun-based (`client/build.mjs` calls `buildClient()` from the
  Hatch SDK); there is no plain Vite/npm build in this tree.
- The service-area map depends on the proprietary HatchMaps runtime
  (`hatch-maps.bin`) and a Meta static-map host.

Running it on Cloudflare Pages + Workers + D1 (or on Lovable) requires the
approved adapter: a Workers fetch handler + D1 binding replacing the Hatch
transport, a plain Vite/React build, Leaflet + OpenStreetMap replacing
HatchMaps, and a DB-level booking-conflict guard (partial unique index on
non-cancelled date+slot, emergency bypass preserved). The admin account's
PBKDF2 hash is preserved in this backup — no password reset is needed — but
210,000-iteration PBKDF2 login latency under the Workers free-tier 10 ms CPU
cap is still untested. No mail channel exists in this project (password
recovery is admin-assisted).

## Not included (deliberate exclusions)

- `node_modules/` (176 MB) — regenerable with `bun install` from
  `package.json` / `bun.lock`. Not needed for the backup to be complete.
- `.bun-cache/` (5 MB) — Bun build cache, regenerable.
- `audits/` (207 MB) — harness audit screenshots/evidence from prior rounds,
  not part of the project needed to restore or run it.
- **No `.env` or secrets file was found** in the project — none exists to back
  up. No API keys, gateway credentials or mail-provider credentials are stored
  in this project (that is why live payments and email verification are
  inactive).
- `@hatch/space-sdk` itself — it is a `file:` dependency pointing at
  `/opt/hatch/skills/spaces/ts-runtime/dist/space-sdk.tgz`, outside the
  project tree. The `package.json` reference is included; the SDK file itself
  is part of the Hatch runtime, not of this project.
- The live `app.db` has no `-wal`/`-shm` sidecar files; none were missed.

## Security note

This backup contains the live database, including the admin account's PBKDF2
password hash and SHA-256 session-token hashes. Treat the backup and the ZIP
as sensitive: store them privately, share only with people authorised to
administer the site, and never publish the database file or post hash values
in chat. The hash values themselves are recorded only as SHA-256 file hashes
in the manifest, never printed in reports.
